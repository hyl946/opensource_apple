/*
 * module to include the modules
 */

config_require(ip-mib/data_access/systemstats)
config_require(ip-mib/ipIfStatsTable/ipIfStatsTable)
config_require(ip-mib/ipIfStatsTable/ipIfStatsTable_interface)
config_require(ip-mib/ipIfStatsTable/ipIfStatsTable_data_access)
