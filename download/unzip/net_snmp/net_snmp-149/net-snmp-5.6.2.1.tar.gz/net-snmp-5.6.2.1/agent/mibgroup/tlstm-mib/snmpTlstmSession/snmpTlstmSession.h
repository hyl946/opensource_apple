#ifndef SNMPTLSTMSESSION_H
#define SNMPTLSTMSESSION_H

/** Initializes the snmpTlstmSession module */
void init_snmpTlstmSession(void);
void shutdown_snmpTlstmSession(void);

#endif /* SNMPTLSTMSESSION_H */

