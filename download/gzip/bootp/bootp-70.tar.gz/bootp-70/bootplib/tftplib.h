
char *	tftp_get(char * host, char * remote_file, off_t * len_p, int t);
