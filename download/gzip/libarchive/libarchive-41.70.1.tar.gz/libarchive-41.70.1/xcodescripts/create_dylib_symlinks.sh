#!/bin/sh

set -ex

ln -s libarchive.2.dylib ${DSTROOT}/usr/lib/libarchive.dylib

