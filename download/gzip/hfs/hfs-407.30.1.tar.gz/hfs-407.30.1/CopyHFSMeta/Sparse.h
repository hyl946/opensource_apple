#ifndef _SPARSE_H
# define _SPARSE_H

struct IOWrapper;

extern struct IOWrapper *InitSparseBundle(const char *, DeviceInfo_t*);

#endif /* _SPARSE_H */
