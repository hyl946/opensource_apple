/* Copyright © 2017 Apple Inc. All rights reserved.
 *
 *  livefiles_hfs_tester.h
 *  hfs
 *
 *  Created by Yakov Ben Zaken on 31/12/2017.
*/

#ifndef livefiles_hfs_tester_h
#define livefiles_hfs_tester_h

#include <stdio.h>

#endif /* livefiles_hfs_tester_h */
