/*
 * Default static playlist.
 */
static struct BC_playlist_entry BC_data[] = {};

static int BC_playlist_blocksize = 512;
