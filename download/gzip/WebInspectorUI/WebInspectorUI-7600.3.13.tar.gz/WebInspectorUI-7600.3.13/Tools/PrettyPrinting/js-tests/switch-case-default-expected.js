switch (x) {
case "abc":
    return 1;
case "def":
    return 2;
default:
    return 3;
}

switch (x) {
case "abc":
    return 1;
case "def":
    return 2;
default:
    return 3;
}

