#define LOCALEDIR "/usr/share/locale"
#ifndef DEFAULT_RMT_COMMAND
# define DEFAULT_RMT_COMMAND "/etc/rmt"
#endif
