// This file includes a derived source file from the build output tree.
// Since the location of the derived sources depends on which configuration
// we are building, we need to use the include path ( which can be
// different for each configuration ) to reference the derived source file.
#include <DerivedSources/grammar.cpp>
