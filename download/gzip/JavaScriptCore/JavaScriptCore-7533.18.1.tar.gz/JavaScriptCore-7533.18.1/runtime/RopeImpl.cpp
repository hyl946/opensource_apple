/*
 * Copyright (C) 2009 Apple Inc. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY APPLE INC. ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL APPLE INC. OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
 * OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */

#include "config.h"
#include "RopeImpl.h"

namespace JSC {

void RopeImpl::derefFibersNonRecursive(Vector<RopeImpl*, 32>& workQueue)
{
    unsigned fiberCount = this->fiberCount();
    for (unsigned i = 0; i < fiberCount; ++i) {
        Fiber& fiber = m_fibers[i];
        if (isRope(fiber)) {
            RopeImpl* nextRope = static_cast<RopeImpl*>(fiber);
            if (nextRope->hasOneRef())
                workQueue.append(nextRope);
            else
                nextRope->deref();
        } else
            static_cast<UStringImpl*>(fiber)->deref();
    }
}

void RopeImpl::destructNonRecursive()
{
    Vector<RopeImpl*, 32> workQueue;

    derefFibersNonRecursive(workQueue);
    delete this;

    while (!workQueue.isEmpty()) {
        RopeImpl* rope = workQueue.last();
        workQueue.removeLast();
        rope->derefFibersNonRecursive(workQueue);
        delete rope;
    }
}

} // namespace JSC
