// RegExp.input is a handy setter

var o = {};

for (var k = 0; k < 9; k++) {
    o = {__proto__ : o };
}

