(function (Thing){
    function Thing() {
    }
    function other() {
        Thing;
    }
    Thing();
})(2)
