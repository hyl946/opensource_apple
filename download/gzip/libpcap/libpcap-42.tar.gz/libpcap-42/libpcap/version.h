static const char pcap_version_string[] = "libpcap version 1.3.0 - Apple version 41";
