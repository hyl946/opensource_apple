static const char pcap_version_string[] = "libpcap version 1.5.3 - Apple version 54";
