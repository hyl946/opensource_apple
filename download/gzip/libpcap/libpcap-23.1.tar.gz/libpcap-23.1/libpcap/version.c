char pcap_version[] = "1.0.0";
