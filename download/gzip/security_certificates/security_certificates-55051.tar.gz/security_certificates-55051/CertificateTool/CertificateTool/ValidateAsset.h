//
//  ValidateAsset.h
//  CertificateTool
//
//  Copyright (c) 2012-2013 Apple Inc. All Rights Reserved.
//

#ifndef CertificateTool_ValidateAsset_h
#define CertificateTool_ValidateAsset_h

int ValidateAsset(const char* asset_dir_path, unsigned long current_version);


#endif
