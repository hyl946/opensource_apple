#include <IOKit/IOBundle.h>

CF_DEFINECONSTANTSTRING(kIOBundleInfoDictionaryVersionKey, "CFBundleInfoDictionaryVersion");
CF_DEFINECONSTANTSTRING(kIOBundleExecutableKey, "CFBundleExecutable");
CF_DEFINECONSTANTSTRING(kIOBundleIdentifierKey, "CFBundleIdentifier");
CF_DEFINECONSTANTSTRING(kIOBundleVersionKey, "CFBundleVersion");
CF_DEFINECONSTANTSTRING(kIOBundleDevelopmentRegionKey, "CFBundleDevelopmentRegion");
CF_DEFINECONSTANTSTRING(kIOBundleNameKey, "CFBundleName");
