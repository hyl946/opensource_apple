// Work around ProjectBuilderWO problem

#include <IOKit/cdb/IOCDBLib.h>
#include <IOKit/cdb/IOSCSILib.h>

__private_extern__
const char _IOKIT_CDB_IOCDBLIB_C_subproj_workaround[] = "_IOKIT_CDB_IOCDBLIB_C_";
