#include "ntp_types.h"

extern	void	getstartup	(int, char **);
extern	void	getCmdOpts	(int, char **);
