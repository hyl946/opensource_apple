/*
 * version file for ntpq
 */
#include <config.h>
const char * Version = "ntpq 4.2.6@1.2089-o Fri May 28 01:21:19 UTC 2010 (1)";
