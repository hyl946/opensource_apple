/*
 * version file for ntpd
 */
#include <config.h>
const char * Version = "ntpd 4.2.6@1.2089-o Fri May 28 01:20:53 UTC 2010 (1)";
