/*
 * version file for ntpdate
 */
#include <config.h>
#ifdef __RC__
const char * Version = "ntpdate 4.2.8p10@1.3728-o Tue Mar 21 14:36:42 UTC 2017 (" __RC__ ")";
#else
const char * Version = "ntpdate 4.2.8p10@1.3728-o Tue Mar 21 14:36:42 UTC 2017 (43)";
#endif
