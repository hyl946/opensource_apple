extern	void	getCmdOpts(int, char **);
