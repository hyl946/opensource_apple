/*
 * version file for ntp-keygen
 */
#include <config.h>
const char * Version = "ntp-keygen 4.2.8p10@1.3728-o Tue Mar 21 14:36:42 UTC 2017 (43)";
