/*
 * version file for ntpdate
 */
#include <config.h>
const char * Version = "ntpdate 4.2.6@1.2089-o Fri May 28 01:20:57 UTC 2010 (1)";
