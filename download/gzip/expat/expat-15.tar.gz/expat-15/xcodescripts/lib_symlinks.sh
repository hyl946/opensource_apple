#!/bin/sh

set -ex

ln -s libexpat.1.dylib ${DSTROOT}/usr/lib/libexpat.dylib
