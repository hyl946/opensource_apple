/*
 * $Id: autofs.c,v 1.2 2004/05/27 08:07:48 pwd Exp $
 */
#include <mach/mach_types.h>
