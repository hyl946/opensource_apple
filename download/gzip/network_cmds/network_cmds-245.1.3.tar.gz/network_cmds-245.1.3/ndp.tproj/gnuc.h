/* $FreeBSD: src/usr.sbin/ndp/gnuc.h,v 1.1 2000/01/06 12:40:40 shin Exp $ */
/* this is dummy to pacify gmt2local.c. */
