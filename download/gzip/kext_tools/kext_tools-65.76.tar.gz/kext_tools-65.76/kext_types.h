#ifndef __KEXT_TYPES_H__
#define __KEXT_TYPES_H__

// XXX not used anywhere; should be removed
// XXXX (the dreaded 4 Xs!) ... this header breaks MiG-generated header!

typedef int kext_result_t;
typedef char * kext_bundle_id_t;
typedef char * posix_path_t;

#endif __KEXT_TYPES_H__
