#ifndef __KEXT_TYPES_H__
#define __KEXT_TYPES_H__

typedef int kext_result_t;
typedef char * kext_bundle_id_t;
typedef char * posix_path_t;

#endif __KEXT_TYPES_H__
