#include "perf_index.h"
DECL_VALIDATE(no_validate) {
  return 1;
}
DECL_INIT(stress_general_init) {
}
DECL_TEST(stress_general_test) {
}
DECL_CLEANUP(stress_general_cleanup) {
}
