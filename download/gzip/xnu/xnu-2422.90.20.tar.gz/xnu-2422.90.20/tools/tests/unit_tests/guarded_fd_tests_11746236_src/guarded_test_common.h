/* 
 * Common file for Guarded fd Unit Tests 
 */

#ifndef _GUARDED_TEST_COMMON_H_
#define _GUARDED_TEST_COMMON_H_

/* Exception causing fd for test program */
#define TEST_FD 25

#endif /* _GUARDED_TEST_COMMON_H_ */
