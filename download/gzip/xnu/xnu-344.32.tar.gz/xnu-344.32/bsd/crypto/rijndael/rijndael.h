/*	$KAME: rijndael.h,v 1.2 2000/10/02 17:14:27 itojun Exp $	*/
/*	$FreeBSD: src/sys/crypto/rijndael/rijndael.h,v 1.1.1.1.2.1 2001/07/03 11:01:36 ume Exp $	*/

#include <crypto/rijndael/rijndael-api-fst.h>
