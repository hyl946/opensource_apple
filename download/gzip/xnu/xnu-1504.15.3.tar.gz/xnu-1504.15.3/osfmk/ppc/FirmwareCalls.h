/*
 * Copyright (c) 2000 Apple Computer, Inc. All rights reserved.
 *
 * @APPLE_OSREFERENCE_LICENSE_HEADER_START@
 * 
 * This file contains Original Code and/or Modifications of Original Code
 * as defined in and that are subject to the Apple Public Source License
 * Version 2.0 (the 'License'). You may not use this file except in
 * compliance with the License. The rights granted to you under the License
 * may not be used to create, or enable the creation or redistribution of,
 * unlawful or unlicensed copies of an Apple operating system, or to
 * circumvent, violate, or enable the circumvention or violation of, any
 * terms of an Apple operating system software license agreement.
 * 
 * Please obtain a copy of the License at
 * http://www.opensource.apple.com/apsl/ and read it before using this file.
 * 
 * The Original Code and all software distributed under the License are
 * distributed on an 'AS IS' basis, WITHOUT WARRANTY OF ANY KIND, EITHER
 * EXPRESS OR IMPLIED, AND APPLE HEREBY DISCLAIMS ALL SUCH WARRANTIES,
 * INCLUDING WITHOUT LIMITATION, ANY WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, QUIET ENJOYMENT OR NON-INFRINGEMENT.
 * Please see the License for the specific language governing rights and
 * limitations under the License.
 * 
 * @APPLE_OSREFERENCE_LICENSE_HEADER_END@
 */
/*
 * @OSF_FREE_COPYRIGHT@
 */
/*
 * @APPLE_FREE_COPYRIGHT@
 */
 
#ifdef ASSEMBLER

#ifdef _FIRMWARECALLS_H_
#error Hey! You can only include FirmwareCalls.h in one assembler file, dude. And it should be Firmware.s!
#else /* _FIRMWARECALLS_H_ */

/*
 *			Entries for all firmware calls are in here (except for call 0x80000000 - CutTrace
 */

#define _FIRMWARECALLS_H_

#define	fwCallEnt(name, entrypt) 									\
			.globl	name								__ASMNL__	\
 			.set	name,(.-EXT(FWtable))/4|0x80000000	__ASMNL__	\
			.long	EXT(entrypt)						__ASMNL__
			
/*
 *
 */
 
			fwCallEnt(dbgDispCall, dbgDispLL)				/* Write stuff to printer or modem port */
			fwCallEnt(dbgCkptCall, dbgCkptLL)				/* Save 128 bytes from r3 to 0x380 V=R mapping */
			fwCallEnt(StoreRealCall, StoreRealLL)			/* Save one word in real storage */
			fwCallEnt(ClearRealCall, ClearRealLL)			/* Clear physical pages */
			fwCallEnt(LoadDBATsCall, xLoadDBATsLL)			/* Load all DBATs */
			fwCallEnt(LoadIBATsCall, xLoadIBATsLL)			/* Load all IBATs */
			fwCallEnt(DoPreemptCall, DoPreemptLL)			/* Preempt if need be */
			fwCallEnt(CreateFakeIOCall, CreateFakeIOLL)		/* Make a fake I/O interruption */
			fwCallEnt(SwitchContextCall, SwitchContextLL)	/* Switch context */
			fwCallEnt(Choke, DoChokeLL)						/* Choke (system crash) */
			fwCallEnt(dbgRegsCall, dbgRegsLL)				/* Dumps all registers */
			fwCallEnt(CreateFakeDECCall, CreateFakeDECLL)	/* Make a fake decrementer interruption */
			fwCallEnt(CreateShutdownCTXCall, CreateShutdownCTXLL)	/* create a shutdown context */
			fwCallEnt(NullCall, NullLL)						/* Null Firmware call */
			fwCallEnt(iNullCall, iNullLL)					/* Instrumented null Firmware call */

#endif	/* _FIRMWARECALLS_H_ */

#else /* ASSEMBLER */
	
/*
 *			The firmware function headers
 */
extern void			CutTrace		(unsigned int item1, ...);

#endif /* ASSEMBLER */
