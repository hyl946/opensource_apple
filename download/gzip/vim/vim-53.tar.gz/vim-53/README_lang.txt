README_lang.txt for version 7.2 of Vim: Vi IMproved.

This file contains files for non-English languages:
- Translated messages.
- Translated menus.
