/*
 *  dtrace_dyld_types.h
 *  dtrace
 *
 *  Created by luser on 3/11/07.
 *  Copyright 2007 Apple Inc. All rights reserved.
 *
 */

#ifndef _DTRACE_DYLD_H_
#define _DTRACE_DYLD_H_

#include "rtld_db.h"

#define _DTRACE_DYLD_BOOTSTRAP_NAME "com.apple.dtrace_dyld"

#endif
