/*
 *  newphdr_ELF64.c
 *  DTrace
 *
 *  Created by luser on 10/28/05.
 *  Copyright 2005 Apple Inc. All rights reserved.
 *
 */

#define _ELF64
#include "newphdr.c"

