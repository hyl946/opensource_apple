#include "usdt_overhead_helper.h"
int main(void) {
	PROVIDER(0)
	return 0;
}
