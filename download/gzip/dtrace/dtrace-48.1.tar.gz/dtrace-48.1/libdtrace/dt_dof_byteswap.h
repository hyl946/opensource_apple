#ifndef	_DT_DOF_BYTESWAP_H
#define	_DT_DOF_BYTESWAP_H

#include <dtrace.h>

void dtrace_dof_byteswap(dof_hdr_t* hdr);

#endif