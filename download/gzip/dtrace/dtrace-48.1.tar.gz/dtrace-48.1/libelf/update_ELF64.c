/*
 *  update_master.c
 *  DTrace
 *
 *  Created by luser on 10/28/05.
 *  Copyright 2005 __MyCompanyName__. All rights reserved.
 *
 */

#define _ELF64
#include "update.c"

