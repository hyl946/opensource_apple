const char version[] = "4.7.3 -- Apple version 66";
