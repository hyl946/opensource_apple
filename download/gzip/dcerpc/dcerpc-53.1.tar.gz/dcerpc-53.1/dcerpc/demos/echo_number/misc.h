void  chk_dce_err(error_status_t, const char *, const char *, unsigned int);
