//
//  AWDMetricIds_IPMonitor.h
//  AppleWirelessDiagnostics
//
//  WARNING :: DO NOT MODIFY THIS FILE!
//
//     This file is auto-generated! Do not modify it or your changes will get overwritten!
//

#ifndef AWD_MetricId_HeaderGuard_IPMonitor
#define AWD_MetricId_HeaderGuard_IPMonitor

// Component Id:
// ---------------
//    Use this value for any API requesting the "component id" for your component.
enum {
    AWDComponentId_IPMonitor = 0x81
};


// Simple Metrics:
// ---------------
//    This component currently has no metrics compatible with the 'simple metric' API.


// General Metrics:
// ----------------
enum {
    AWDMetricId_IPMonitor_InterfaceAdvisoryReport = 0x810000
};

#endif  // AWD_MetricId_HeaderGuard_IPMonitor
