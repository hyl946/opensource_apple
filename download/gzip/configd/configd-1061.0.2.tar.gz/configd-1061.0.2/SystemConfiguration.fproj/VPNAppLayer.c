/*
 * Copyright (c) 2012-2018 Apple Inc.
 * All rights reserved.
 */

