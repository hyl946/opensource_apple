//
//  EventFactory.h
//  SystemConfigurationNetworkEventFactory
//
//  Created by Allan Nathanson on 11/15/17.
//
//

#import <EventFactory/EventFactory.h>

@interface EventFactory : EFEventFactory

@end
