char   *var_smtp_destination_concurrency_limit;
char   *var_smtp_destination_recipient_limit;
