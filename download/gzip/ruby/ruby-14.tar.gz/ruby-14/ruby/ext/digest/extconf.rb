# $RoughId: extconf.rb,v 1.6 2001/07/13 15:38:27 knu Exp $
# $Id: extconf.rb,v 1.1.1.2 2003/10/15 10:11:47 melville Exp $

require "mkmf"

create_makefile("digest")
