require 'mkmf'
create_makefile("tkutil")
