# $Id: extconf.rb,v 1.1.1.1 2003/10/15 10:11:47 melville Exp $

require 'mkmf'
create_makefile 'racc/cparse'
