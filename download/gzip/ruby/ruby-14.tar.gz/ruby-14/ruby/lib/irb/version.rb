#
#   irb/version.rb - irb version definition file
#   	$Release Version: 0.9$
#   	$Revision: 1.1.1.2 $
#   	$Date: 2003/10/15 10:11:49 $
#   	by Keiju ISHITSUKA(keiju@ishitsuka.com)
#
# --
#
#   
#

module IRB
  @RELEASE_VERSION = "0.9"
  @LAST_UPDATE_DATE = "02/07/03"
end
