module REXML
	module Encoding
		ISO_8859_1 = 'ISO-8859-1'
		claim( ISO_8859_1 )
	end
end
