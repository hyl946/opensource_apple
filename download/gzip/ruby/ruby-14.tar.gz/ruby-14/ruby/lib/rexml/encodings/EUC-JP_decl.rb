module REXML
	module Encoding
		EUC_JP = 'EUC-JP'
		claim( EUC_JP )
	end
end
