module REXML
	module Encoding
		US_ASCII = 'US-ASCII'
		claim( US_ASCII )
	end
end
