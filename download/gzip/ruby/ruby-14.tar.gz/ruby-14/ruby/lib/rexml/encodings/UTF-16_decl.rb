module REXML
	module Encoding
		UTF_16 = 'UTF-16'
		claim( UTF_16, /^\376\377/ )
	end
end
