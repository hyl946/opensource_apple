module REXML
	module Encoding
		UNILE = 'UNILE'
		claim( UNILE, /^\377\376/ )
	end
end
