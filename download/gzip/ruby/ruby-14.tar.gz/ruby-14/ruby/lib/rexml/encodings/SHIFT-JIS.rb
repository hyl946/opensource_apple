require 'rexml/encodings/SHIFT_JIS'
