module REXML
	module Encoding
		claim( 'Shift-JIS' )
		claim( 'Shift_JIS' )
	end
end
