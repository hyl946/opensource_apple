RAAServant.rb: based on the file which is generated with the following command;
  bin/wsdl2ruby.rb --wsdl raa.wsdl --servant_skelton --force

RAAService.rb: generated with the following command;
  bin/wsdl2ruby.rb --wsdl raa.wsdl --standalone_server_stub --force

RAA.rb: generated with the following command;
  bin/wsdl2ruby.rb --wsdl raa.wsdl --classdef --force
