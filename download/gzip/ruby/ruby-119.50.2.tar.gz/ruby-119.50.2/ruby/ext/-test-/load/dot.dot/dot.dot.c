void Init_dot(void) {}
