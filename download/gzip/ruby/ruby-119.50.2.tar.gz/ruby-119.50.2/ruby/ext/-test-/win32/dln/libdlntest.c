extern __declspec(dllexport) void
dlntest_ordinal(void)
{
}
