STDERR.reopen(STDOUT)
at_exit{Process.kill(:INT, $$)}
