create_makefile("-test-/wait_for_single_fd/wait_for_single_fd")
