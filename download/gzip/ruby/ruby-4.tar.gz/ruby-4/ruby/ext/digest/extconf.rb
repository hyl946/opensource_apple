# $RoughId: extconf.rb,v 1.6 2001/07/13 15:38:27 knu Exp $
# $Id: extconf.rb,v 1.1.1.1 2002/05/27 17:59:45 jkh Exp $

require "mkmf"

create_makefile("digest")
