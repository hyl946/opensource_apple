#
# telnet.rb
#

$stderr.puts 'Warning: telnet.rb is obsolete: use net/telnet'

require 'net/telnet'

Telnet = ::Net::Telnet
