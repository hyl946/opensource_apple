# $Id: final.rb,v 1.1.1.1 2002/05/27 17:59:48 jkh Exp $
# Copyright (C) 1998 Yukihiro Matsumoto. All rights reserved. 

# final.rb is integrated into ObjectSpace; no longer needed.
