// BlockTest.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"


extern int main(int argc, _TCHAR *argv[]);

int _tmain(int argc, _TCHAR* argv[])
{
    main(argc, argv);
	return 0;
}
