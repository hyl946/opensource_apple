/* colon.c, created from colon.def. */
#line 23 "colon.def"

#line 30 "colon.def"

#line 36 "colon.def"

#line 42 "colon.def"

/* Return a successful result. */
int
colon_builtin (ignore)
     char *ignore;
{
  return (0);
}

/* Return an unsuccessful result. */
int
false_builtin (ignore)
     char *ignore;
{
  return (1);
}
