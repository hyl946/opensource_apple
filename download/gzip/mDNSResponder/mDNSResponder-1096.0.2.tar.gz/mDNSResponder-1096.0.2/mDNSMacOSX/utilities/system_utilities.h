//
//  system_utilities.h
//  mDNSResponder
//
//  Copyright (c) 2019 Apple Inc. All rights reserved.
//

#ifndef SYSTEM_UTILITIES_H
#define SYSTEM_UTILITIES_H

mDNSexport mDNSBool IsAppleInternalBuild(void);

#endif /* SYSTEM_UTILITIES_H */
