//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by dnssd_NET.rc
