//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ExplorerPlugin.rc
//
#define IDS_NAME                        106
#define IDS_WEB_SITES                   107
#define IDS_FTP_SITES                   108
#define IDS_PRINTERS                    109
#define IDS_RENDEZVOUS_NOT_AVAILABLE    110
#define IDD_LOGIN                       145
#define IDC_LOGIN_USERNAME_TEXT         1182
#define IDC_LOGIN_PASSWORD_TEXT         1183

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        115
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
