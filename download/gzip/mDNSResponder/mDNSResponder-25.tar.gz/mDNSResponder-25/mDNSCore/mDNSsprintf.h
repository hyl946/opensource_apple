#ifdef	__cplusplus
	extern "C" {
#endif

extern int mDNS_sprintf(char *sbuffer, const char *fmt, ...);

#ifdef	__cplusplus
	}
#endif
