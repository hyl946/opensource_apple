//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ControlPanel.rc
//
#define IDR_APPLET                      131
#define IDR_APPLET_PAGE1                131
#define IDS_APPLET_DESCRIPTION          132
#define IDR_APPLET_PAGE2                132
#define IDR_SECRET                      133
#define IDR_APPLET_PAGE3                134
#define IDI_FAILURE                     140
#define IDI_SUCCESS                     141
#define IDD_ADD_BROWSE_DOMAIN           142
#define IDR_ADD_BROWSE_DOMAIN           142
#define IDC_EDIT1                       1000
#define IDC_BUTTON1                     1001
#define IDC_COMBO1                      1002
#define IDC_CHECK1                      1003
#define IDC_COMBO2                      1004
#define IDC_EDIT2                       1005
#define IDC_SECRET                      1005
#define IDC_COMBO3                      1007
#define IDC_FAILURE                     1008
#define IDC_SUCCESS                     1009
#define IDC_SECRET_NAME                 1010
#define IDC_NAME                        1010
#define IDC_KEY                         1010
#define IDC_LIST1                       1011
#define IDC_BROWSE_LIST                 1011
#define IDC_BUTTON2                     1012
#define IDC_REMOVE_BROWSE_DOMAIN        1012
#define IDC_ADD_BROWSE_DOMAIN           1013

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        143
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1014
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
