#ifdef	__cplusplus
	extern "C" {
#endif

extern int mDNS_vsprintf(char *sbuffer, const char *fmt, va_list arg);

#ifdef	__cplusplus
	}
#endif
