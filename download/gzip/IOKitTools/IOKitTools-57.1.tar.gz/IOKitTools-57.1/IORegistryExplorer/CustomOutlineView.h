/* CustomOutlineView.h created by epeyton on Wed 05-Jan-2000 */

#import <AppKit/AppKit.h>

@interface CustomOutlineView : NSOutlineView
{

    
}

@end
