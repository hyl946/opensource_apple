/* RExplorer-BrowserDelegate.h created by epeyton on Tue 11-Jan-2000 */

#import <AppKit/AppKit.h>
#import "RExplorer.h"

@interface RExplorer (BrowserDelegate)

@end
