#define	__FBSDID(s)	__IDSTRING(__CONCAT(__rcsid_,__LINE__),s)
