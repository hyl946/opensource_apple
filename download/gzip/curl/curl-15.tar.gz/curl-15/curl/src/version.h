#define CURL_NAME "curl"
#define CURL_VERSION "7.10.2"
#define CURL_ID CURL_NAME " " CURL_VERSION " (" OS ") "
