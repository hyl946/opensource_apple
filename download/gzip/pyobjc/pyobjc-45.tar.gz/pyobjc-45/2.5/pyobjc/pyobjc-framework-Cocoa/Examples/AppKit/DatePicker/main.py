from PyObjCTools import AppHelper

import MyWindowController

AppHelper.runEventLoop()
