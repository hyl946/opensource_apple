from PyObjCTools import AppHelper
import CGraphController

AppHelper.runEventLoop()
