from PyObjCTools import AppHelper

# import classes required to start application
import AppController

# start the event loop
AppHelper.runEventLoop()
