# This is statement is required by the build system to query build info
if __name__ == '__build__':
	raise Exception

