'''
Some simple tests to check that the framework is properly wrapped.
'''
import objc
from PyObjCTools.TestSupport import *
import CoreFoundation

class TestCoreFoundation (TestCase):
    pass



if __name__ == "__main__":
    main()
