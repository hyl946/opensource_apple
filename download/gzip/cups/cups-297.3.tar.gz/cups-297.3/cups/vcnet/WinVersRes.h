#ifndef WINRESVERS_H
#define WINRESVERS_H

#define MASTER_PROD_NAME	"AirPrint For Windows"

// Define the company name for Print Services
#define MASTER_COMPANY_NAME   "Apple Inc."

// Define the product version for Print Services
#define MASTER_PROD_VERS		1,0,0,42
#define MASTER_PROD_VERS_STR	"1.0.0.42"
#define MASTER_PROD_VERS_STR2	"1.0.0.42"

// Define the legal copyright
#define MASTER_LEGAL_COPYRIGHT "Copyright (C) 2010 Apple Inc."

#endif // WINRESVERS_H
