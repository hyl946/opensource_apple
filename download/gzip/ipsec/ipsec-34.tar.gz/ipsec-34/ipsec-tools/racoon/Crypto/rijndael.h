/*	$KAME: rijndael.h,v 1.2 2000/10/02 17:14:27 itojun Exp $	*/

#ifndef __RIJNDAEL_H__
#define __RIJNDAEL_H__

#include <rijndael-api-fst.h>


#endif /* __RIJNDAEL_H__ */

