#include <sys/cdefs.h>
__FBSDID("$FreeBSD$");

#define	MEMCOPY
#include "bcopy.c"
