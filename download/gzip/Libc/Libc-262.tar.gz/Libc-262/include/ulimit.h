#ifndef _ULIMIT_H
#define _ULIMIT_H

#define UL_GETFSIZE 1
#define UL_SETFSIZE 2

long int ulimit(int, ...);

#endif /* _ULIMIT_H */
