#include <sys/cdefs.h>
__FBSDID("$FreeBSD$");

#define	MEMMOVE
#include "bcopy.c"
