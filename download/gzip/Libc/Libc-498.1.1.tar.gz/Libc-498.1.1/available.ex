g/AvailabilityMacros\.h/s//available.h/
/Contains:/c
     Contains:   Double-underbar-prefixed availability macros, derived from
                 AvailabilityMacros.h
.
g/__AVAILABILITYMACROS__/s//_AVAILABLE_H_/
g/\<MAC_OS_X/s//__&/g
g/\<WEAK_IMPORT_ATTRIBUTE/s//__DARWIN_&/g
g/\<DEPRECATED_ATTRIBUTE/s//__DARWIN_&/g
g/\<UNAVAILABLE_ATTRIBUTE/s//__DARWIN_&/g
g/\<AVAILABLE_MAC_OS_X/s//__&/g
g/\<DEPRECATED_IN_MAC_OS_X/s//__&/g
w
