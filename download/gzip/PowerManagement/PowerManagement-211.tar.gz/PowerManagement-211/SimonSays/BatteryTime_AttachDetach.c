/*
 *  BatteryTime_AttachDetach.c
 *  SULeoGaia Verification
 *
 *  Created by Ethan Bold on 8/4/08.
 *  Copyright 2008 __MyCompanyName__. All rights reserved.
 *
 */


