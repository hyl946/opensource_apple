//
//  main.m
//  BatteryFaker
//
//  Created by Ethan Bold on 2/21/06.
//  Copyright Apple Computer 2006. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
