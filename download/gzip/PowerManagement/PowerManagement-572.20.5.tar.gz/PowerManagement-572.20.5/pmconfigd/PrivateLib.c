/*
 * Copyright (c) 2003 Apple Computer, Inc. All rights reserved.
 *
 * @APPLE_LICENSE_HEADER_START@
 * 
 * This file contains Original Code and/or Modifications of Original Code
 * as defined in and that are subject to the Apple Public Source License
 * Version 2.0 (the 'License'). You may not use this file except in
 * compliance with the License. Please obtain a copy of the License at
 * http://www.opensource.apple.com/apsl/ and read it before using this
 * file.
 * 
 * The Original Code and all software distributed under the License are
 * distributed on an 'AS IS' basis, WITHOUT WARRANTY OF ANY KIND, EITHER
 * EXPRESS OR IMPLIED, AND APPLE HEREBY DISCLAIMS ALL SUCH WARRANTIES,
 * INCLUDING WITHOUT LIMITATION, ANY WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, QUIET ENJOYMENT OR NON-INFRINGEMENT.
 * Please see the License for the specific language governing rights and
 * limitations under the License.
 * 
 * @APPLE_LICENSE_HEADER_END@
 */


#include <CoreFoundation/CoreFoundation.h>
#include <IOKit/IOHibernatePrivate.h>
#include <IOKit/hidsystem/IOHIDLib.h>
#include <IOKit/graphics/IOGraphicsTypes.h>
#include <IOKit/pwr_mgt/IOPMLibPrivate.h>
#include <IOKit/IOHibernatePrivate.h>
#if !TARGET_OS_EMBEDDED
#include <IOKit/platform/IOPlatformSupportPrivate.h>
#endif
#include <Security/SecTask.h>
#include <mach/mach.h>
#include <mach/mach_time.h>
#include <grp.h>
#include <pwd.h>
#include <syslog.h>
#include <unistd.h>
#include <asl.h>
#include <membership.h>
#include <sys/types.h>
#include <sys/sysctl.h>
#include <sys/stat.h>
#include <sys/fcntl.h>
#include <sys/mount.h>
#include <unistd.h>
#include <pthread.h>
#include <dispatch/dispatch.h>
#include <notify.h>

#include "Platform.h"
#include "PrivateLib.h"
#include "BatteryTimeRemaining.h"
#include "PMAssertions.h"
#include "PMSettings.h"
#include "PMAssertions.h"


#define kIntegerStringLen               15

#if !TARGET_OS_EMBEDDED
#include <IOKit/smc/SMCUserClient.h>
#include <systemstats/systemstats.h>

#else

#ifndef kIOPMPSRawExternalConnectedKey
#define kIOPMPSRawExternalConnectedKey        "AppleRawExternalConnected"
#endif

#endif /* TARGET_OS_EMBEDDED */

#ifndef kIOHIDIdleTimeKy
#define kIOHIDIdleTimeKey                               "HIDIdleTime"
#endif

#ifndef kIOPMMaintenanceScheduleImmediate
#define kIOPMMaintenanceScheduleImmediate               "MaintenanceImmediate"
#endif

// Duplicating the enum from IOServicePMPrivate.h
enum {
    kDriverCallInformPreChange,
    kDriverCallInformPostChange,
    kDriverCallSetPowerState,
    kRootDomainInformPreChange
};
enum
{
    PowerManagerScheduledShutdown = 1,
    PowerManagerScheduledSleep,
    PowerManagerScheduledRestart
};

/* If the battery doesn't specify an alternative time, we wait 16 seconds
   of ignoring the battery's (or our own) time remaining estimate.
*/
enum
{
    kInvalidWakeSecsDefault = 16
};


#define kPowerManagerActionNotificationName "com.apple.powermanager.action"
#define kPowerManagerActionKey "action"
#define kPowerManagerValueKey "value"

// Track real batteries
static CFMutableSetRef     physicalBatteriesSet = NULL;

static IOPMBattery         **physicalBatteriesArray = NULL;

static int sleepCntSinceBoot = 0;
static int sleepCntSinceFailure = -1;

__private_extern__ bool             isDisplayAsleep( );

// Cached data for LowCapRatio
static time_t               cachedLowCapRatioTime = 0;
static bool                 cachedKeyPresence = false;
static bool                 cachedHasLowCap = false;

// Frequency with which to write out FDR records, in secs
#define kFDRRegularInterval (10*60)
// How long to wait after a power event to write out first FDR record, in secs
// Power events include sleep, wake, AC change etc.
#define kFDRIntervalAfterPE (1*60)

#if !TARGET_OS_EMBEDDED
static uint64_t nextFDREventDue = 0;
#endif

typedef struct {
    CFStringRef     sleepReason;
    CFStringRef     platformWakeReason;
    CFStringRef     platformWakeType;
    CFArrayRef      claimedWakeEventsArray;
    CFStringRef     claimedWake;
    CFStringRef     interpretedWake;
} PowerEventReasons;

static PowerEventReasons     reasons = {
        CFSTR(""),
        CFSTR(""),
        CFSTR(""),
        NULL,
        NULL,
        NULL
        };

/******
 * Do not remove DUMMY macros
 *
 * The following DUMMY macros aren't used in the source code, they're
 * a placeholder for the 'genstrings' tool to read the strings we're using.
 * 'genstrings' will encode these strings in a Localizable.strings file.
 * Note: if you add to or modify these strings, you must re-run genstrings and
 * replace this project's Localizable.strings file with the output.
 ******/

#define DUMMY_UPS_HEADER(myBundle) CFCopyLocalizedStringWithDefaultValue( \
            CFSTR("WARNING!"), \
            CFSTR("Localizable"), \
            myBundle, \
            CFSTR("Warning!"), \
            NULL);

#define DUMMY_UPS_BODY(myBundle) CFCopyLocalizedStringWithDefaultValue( \
            CFSTR("YOUR COMPUTER IS NOW RUNNING ON UPS BACKUP BATTERY. SAVE YOUR DOCUMENTS AND SHUTDOWN SOON."), \
            CFSTR("Localizable"), \
            myBundle, \
            CFSTR("Your computer is now running on UPS backup battery power. Save your documents and shut down soon."), \
            NULL);


#define DUMMY_ASSERTION_STRING_TTY(myBundle) CFCopyLocalizedStringWithDefaultValue( \
            CFSTR("A remote user is connected. That prevents system sleep."), \
            CFSTR("Localizable"), \
            myBundle, \
            CFSTR("A remote user is connected. That prevents system sleep."), \
            NULL);

#define DUMMY_CAFFEINATE_REASON_STRING(myBundle) CFCopyLocalizedStringWithDefaultValue( \
            CFSTR("THE CAFFEINATE TOOL IS PREVENTING SLEEP."), \
            CFSTR("Localizable"), \
            myBundle, \
            CFSTR("The caffeinate tool is preventing sleep."), \
            NULL);


static void mt2PublishWakeReason(CFStringRef wakeTypeStr, CFStringRef claimedWakeStr);
static void logASLMessageHibernateStatistics(void);

// dynamicStoreNotifyCallBack is defined in pmconfigd.c
// is not defined in pmset! so we don't compile this code in pmset.

extern SCDynamicStoreRef                gSCDynamicStore;

__private_extern__ SCDynamicStoreRef _getSharedPMDynamicStore(void)
{
    return gSCDynamicStore;
}

__private_extern__ CFRunLoopRef         _getPMRunLoop(void)
{
    static CFRunLoopRef     pmRLS = NULL;

    if (!pmRLS) {
        pmRLS = CFRunLoopGetCurrent();
    }

    return pmRLS;
}

__private_extern__ dispatch_queue_t     _getPMDispatchQueue(void)
{
    static dispatch_queue_t pmQ = NULL;

    if (!pmQ) {
        pmQ = dispatch_queue_create("Power Management configd queue", NULL);
    }

    return pmQ;
}

static void initSleepCnt()
{
    int cnt = INT_MAX; // Init to a huge number in case of failure.
#if !TARGET_OS_EMBEDDED
    size_t msgCnt;
    asl_object_t cq = NULL;
    asl_object_t        msg, store, msgList = NULL;
    const char *str = NULL;

    if (sleepCntSinceFailure != -1) {
        return;
    }

    store = open_pm_asl_store();
    cq = asl_new(ASL_TYPE_QUERY);
    if (cq == NULL) {
        goto exit;
    }

    asl_set_query(cq, kPMASLDomainKey, kPMASLDomainHibernateStatistics, ASL_QUERY_OP_EQUAL);
    msgList = asl_search(store, cq);

    msgCnt = asl_count(msgList);
    if (msgCnt <= 0) {
        goto exit;
    }

    msg = asl_get_index(msgList, msgCnt-1);
    if ((str = asl_get(msg, kPMASLSleepCntSinceFailure))) {
        cnt = strtol(str, NULL, 0);
    }

exit:
    if (cq) {
        asl_release(cq);
    }
    if (store) {
        asl_release(store);
    }
    if (msgList) {
        asl_release(msgList);
    }
#endif
    sleepCntSinceFailure = cnt;
}

__private_extern__ void incrementSleepCnt()
{
    sleepCntSinceBoot++;
    if (sleepCntSinceFailure == -1) {
        initSleepCnt();
    }
    sleepCntSinceFailure++;
}

__private_extern__ bool auditTokenHasEntitlement(
                                     audit_token_t token,
                                     CFStringRef entitlement)
{
    SecTaskRef task = NULL;
    CFTypeRef val = NULL;
    bool caller_is_allowed = false;
    CFErrorRef      errorp = NULL;
    
    task = SecTaskCreateWithAuditToken(kCFAllocatorDefault, token);
    if (task) {
        val = SecTaskCopyValueForEntitlement(task, entitlement, &errorp);
        CFRelease(task);
        
        if (kCFBooleanTrue == val) {
            caller_is_allowed = true;
        }
        if (val) {
            CFRelease(val);
        }
    }
    return caller_is_allowed;
    
}

#define kIOPMSystemDefaultOverrideKey    "SystemPowerProfileOverrideDict"

__private_extern__ IOReturn
_setRootDomainProperty(
    CFStringRef                 key,
    CFTypeRef                   val)
{
    return IORegistryEntrySetCFProperty(getRootDomain(), key, val);
}

__private_extern__ CFTypeRef
_copyRootDomainProperty(
    CFStringRef                 key)
{
    return IORegistryEntryCreateCFProperty(getRootDomain(), key, kCFAllocatorDefault, 0);
}


__private_extern__ bool
_getUUIDString(
    char *buf,
    int buflen)
{
    bool            ret = false;
    CFStringRef     uuidString = NULL;

    uuidString = IOPMSleepWakeCopyUUID();

    if (uuidString) {
        if (!CFStringGetCString(uuidString, buf, buflen,
                                kCFStringEncodingUTF8))
        {
            goto exit;
        }

        ret = true;
    }
exit:
    if (uuidString) CFRelease(uuidString);
    return ret;
}

__private_extern__ CFStringRef _updateSleepReason( )
{
    io_service_t    iopm_rootdomain_ref = getRootDomain();

    if (reasons.sleepReason) CFRelease(reasons.sleepReason);

    reasons.sleepReason = IORegistryEntryCreateCFProperty(
                            iopm_rootdomain_ref,
                            CFSTR("Last Sleep Reason"),
                            kCFAllocatorDefault, 0);

    if (!isA_CFString(reasons.sleepReason))
        reasons.sleepReason = CFSTR("");

    return reasons.sleepReason;

}

__private_extern__ CFStringRef 
_getSleepReason()
{
    return (reasons.sleepReason);
}

static  bool
_getSleepReasonLogStr(
    char *buf,
    int buflen)
{
    bool            ret = false;
    io_service_t    iopm_rootdomain_ref = getRootDomain();
    CFNumberRef     sleepPID = NULL;
    char            reasonBuf[50];
    int             spid = -1;
    
    sleepPID = (CFNumberRef)IORegistryEntryCreateCFProperty(
                             iopm_rootdomain_ref,
                             CFSTR("SleepRequestedByPID"),
                             kCFAllocatorDefault, 0);
    if (sleepPID && isA_CFNumber(sleepPID)) {
        CFNumberGetValue(sleepPID, kCFNumberIntType, &spid);
    }
    if (reasons.sleepReason && isA_CFString(reasons.sleepReason))
    {
        if (CFStringGetCString(reasons.sleepReason, reasonBuf, sizeof(reasonBuf), kCFStringEncodingUTF8))
        {
            if (!strncmp(kIOPMSoftwareSleepKey, reasonBuf, strlen(kIOPMSoftwareSleepKey)))
            {
                snprintf(buf, buflen, "\'%s pid=%d\'", reasonBuf, spid);
            } else {
                snprintf(buf, buflen, "\'%s\'", reasonBuf);
            }
            ret = true;
        }
    }
    if (sleepPID) CFRelease(sleepPID);
    return ret;
}

__private_extern__ void _resetWakeReason( )
{
    if (reasons.platformWakeReason)         CFRelease(reasons.platformWakeReason);
    if (reasons.platformWakeType)           CFRelease(reasons.platformWakeType);
    if (reasons.claimedWake)        CFRelease(reasons.claimedWake);
    if (isA_CFArray(reasons.claimedWakeEventsArray))   CFRelease(reasons.claimedWakeEventsArray);

    reasons.interpretedWake         = NULL;
    reasons.claimedWake             = NULL;
    reasons.claimedWakeEventsArray  = NULL;
    reasons.platformWakeReason              = CFSTR("");
    reasons.platformWakeType                = CFSTR("");
}

#ifndef  kIOPMDriverWakeEventsKey
#define kIOPMDriverWakeEventsKey            "IOPMDriverWakeEvents"
#define kIOPMWakeEventTimeKey               "Time"
#define kIOPMWakeEventFlagsKey              "Flags"
#define kIOPMWakeEventReasonKey             "Reason"
#define kIOPMWakeEventDetailsKey            "Details"
#endif

#define kWakeEventWiFiPrefix          CFSTR("WiFi")
#define kWakeEventEnetPrefix          CFSTR("Enet")

static CFStringRef claimedReasonFromEventsArray(CFArrayRef wakeEvents)
{
    CFDictionaryRef     eachClaim = NULL;
    CFStringRef         eachReason = NULL;
    int i = 0;
    long  count = 0;

    if (!isA_CFArray(wakeEvents) ||
        !(count = CFArrayGetCount(wakeEvents))) {
        return NULL;
    }

    for (i=0; i<count; i++)
    {
        eachClaim = CFArrayGetValueAtIndex(wakeEvents,i);
        if (!isA_CFDictionary(eachClaim))
            continue;
        eachReason = CFDictionaryGetValue(eachClaim, CFSTR(kIOPMWakeEventReasonKey));
        if (!isA_CFString(eachReason))
            continue;
        if (CFStringHasPrefix(eachReason, kWakeEventWiFiPrefix)
            || CFStringHasPrefix(eachReason, kWakeEventEnetPrefix))
        {
            return CFRetain(eachReason);
        }
    }
    return NULL;
}


__private_extern__ void _updateWakeReason
    (CFStringRef *wakeReason, CFStringRef *wakeType)
{
    _resetWakeReason();

    // This property may not exist on all platforms.
    reasons.platformWakeReason = _copyRootDomainProperty(CFSTR(kIOPMRootDomainWakeReasonKey));
    if (!isA_CFString(reasons.platformWakeReason))
        reasons.platformWakeReason = CFSTR("");

    reasons.platformWakeType = _copyRootDomainProperty(CFSTR(kIOPMRootDomainWakeTypeKey));
    if (!isA_CFString(reasons.platformWakeType))
        reasons.platformWakeType = CFSTR("");

    reasons.claimedWakeEventsArray = _copyRootDomainProperty(CFSTR(kIOPMDriverWakeEventsKey));
    
    reasons.claimedWake = claimedReasonFromEventsArray(reasons.claimedWakeEventsArray);
    if (reasons.claimedWake) {
        reasons.interpretedWake = reasons.claimedWake;
        mt2PublishWakeReason(reasons.platformWakeType, reasons.claimedWake);
    } else {
        reasons.interpretedWake = reasons.platformWakeType;
        mt2PublishWakeReason(reasons.platformWakeType, reasons.platformWakeType);
    }

    getPlatformWakeReason(wakeReason, wakeType);
    return ;
}

__private_extern__ void getPlatformWakeReason
    (CFStringRef *wakeReason, CFStringRef *wakeType)
{

    if (!isA_CFString(reasons.platformWakeReason))
        reasons.platformWakeReason = CFSTR("");

    if (!isA_CFString(reasons.platformWakeType))
        reasons.platformWakeType = CFSTR("");

    if (wakeReason) *wakeReason = reasons.platformWakeReason;
    if (wakeType) *wakeType = reasons.platformWakeType;
    return ;

}
    

__private_extern__ bool
_getHibernateState(
    uint32_t *hibernateState)
{
    bool            ret = false;
    io_service_t    rootDomain = getRootDomain();
    CFDataRef       hibStateData = NULL;
    uint32_t        *hibStatePtr;

    // This property may not exist on all platforms.
    hibStateData = IORegistryEntryCreateCFProperty(
                        rootDomain,
                        CFSTR(kIOHibernateStateKey),
                        kCFAllocatorDefault, 0);

    if (isA_CFData(hibStateData) &&
        (CFDataGetLength(hibStateData) == sizeof(uint32_t)) &&
        (hibStatePtr = (uint32_t *)CFDataGetBytePtr(hibStateData)))
    {
        *hibernateState = *hibStatePtr;
        ret = true;
    }

    if (hibStateData) CFRelease(hibStateData);
    return ret;
}

__private_extern__
const char * getSleepTypeString(void)
{
    const char      *string = NULL;
#if !TARGET_OS_EMBEDDED
    io_service_t    rootDomain = getRootDomain();
    bool            isHibWake = false;
    CFNumberRef     sleepTypeNum;
    uint32_t        hibState;

    sleepTypeNum = IORegistryEntryCreateCFProperty(
                        rootDomain,
                        CFSTR(kIOPMSystemSleepTypeKey),
                        kCFAllocatorDefault, 0);

    if (_getHibernateState(&hibState) &&
        (hibState & kIOHibernateStateWakingFromHibernate))
    {
        isHibWake = true;
    }

    if (isA_CFNumber(sleepTypeNum))
    {
        int sleepType = kIOPMSleepTypeInvalid;

        CFNumberGetValue(sleepTypeNum, kCFNumberIntType, &sleepType);
        if (isHibWake)
        {
            // Hibernation types
            switch (sleepType)
            {
                case kIOPMSleepTypeSafeSleep:
                    string = "Safe Sleep";
                    break;
                case kIOPMSleepTypeHibernate:
                    string = "Hibernate";
                    break;
                case kIOPMSleepTypeStandby:
                    string = "Standby";
                    break;
                case kIOPMSleepTypePowerOff:
                    string = "AutoPowerOff";
                    break;
            }
        }
    }
    if (sleepTypeNum)
        CFRelease(sleepTypeNum);

#endif /* !TARGET_OS_EMBEDDED */
    return string;
}


static void sendNotification(int command)
{
#if !TARGET_OS_EMBEDDED
    CFMutableDictionaryRef   dict = NULL;
    int numberOfSeconds = 600;

    CFNumberRef secondsValue = CFNumberCreate( NULL, kCFNumberIntType, &numberOfSeconds );
    CFNumberRef commandValue = CFNumberCreate( NULL, kCFNumberIntType, &command );

    dict = CFDictionaryCreateMutable(kCFAllocatorDefault, 2,
                                    &kCFTypeDictionaryKeyCallBacks,
                                    &kCFTypeDictionaryValueCallBacks);

    CFDictionarySetValue(dict, CFSTR(kPowerManagerActionKey), commandValue);
    CFDictionarySetValue(dict, CFSTR(kPowerManagerValueKey), secondsValue);

    CFNotificationCenterPostNotificationWithOptions (
                        CFNotificationCenterGetDistributedCenter(),
                                            CFSTR(kPowerManagerActionNotificationName),
                                            NULL, dict,
                                            (kCFNotificationPostToAllSessions | kCFNotificationDeliverImmediately));
    CFRelease(dict);
    CFRelease(secondsValue);
    CFRelease(commandValue);
#endif
}


__private_extern__ void _askNicelyThenShutdownSystem(void)
{
    sendNotification( PowerManagerScheduledShutdown );
}

__private_extern__ void _askNicelyThenSleepSystem(void)
{
    sendNotification( PowerManagerScheduledSleep );
}

__private_extern__ void _askNicelyThenRestartSystem(void)
{
    sendNotification( PowerManagerScheduledRestart );
}




#define kIOPMAppName                "Power Management configd plugin"
#define kIOPMPrefsPath              "com.apple.PowerManagement.xml"

IOReturn _getLowCapRatioTime(CFStringRef batterySerialNumber,
                             boolean_t *hasLowCapRatio,
                             time_t *since)
{
    IOReturn                    ret         = kIOReturnError;
    
#if !TARGET_OS_EMBEDDED
    SCPreferencesRef            energyPrefs = NULL; // must release
    CFNumberRef                 num         = NULL; // must release
    CFPropertyListRef           plist       = NULL; // do not release
    if (!hasLowCapRatio || !since || !isA_CFString(batterySerialNumber)) {
        return ret;
    }
    
    *hasLowCapRatio = false;
    *since = 0;
    
    if (cachedKeyPresence) {
        *hasLowCapRatio = cachedHasLowCap;
        *since = cachedLowCapRatioTime;
        ret = kIOReturnSuccess;
        goto exit;
    }

    energyPrefs = SCPreferencesCreate(kCFAllocatorDefault,
                                      CFSTR(kIOPMAppName),
                                      CFSTR(kIOPMPrefsPath));

    if (kSCStatusNoConfigFile == SCError()) {
        cachedKeyPresence = true;
        cachedHasLowCap = false;
        cachedLowCapRatioTime = 0;
        ret = kIOReturnSuccess;
        goto exit;
    }

    if (!SCPreferencesLock(energyPrefs, true)) {
        ret = kIOReturnInternalError;
        goto exit;
    }

    plist = SCPreferencesGetValue(energyPrefs, CFSTR("BatteryWarn"));

    if (kSCStatusNoKey == SCError()) {
        cachedKeyPresence = true;
        cachedHasLowCap = false;
        cachedLowCapRatioTime = 0;
        ret = kIOReturnSuccess;
        goto exit;
    }

    if (!plist || CFGetTypeID(plist) != CFDictionaryGetTypeID()) {
        SCPreferencesUnlock(energyPrefs);
        goto exit;
    }
    
    SCPreferencesUnlock(energyPrefs);
    
    num = CFDictionaryGetValue(plist, batterySerialNumber);
    if (num && CFNumberGetTypeID() == CFGetTypeID(num)) {
        if (!CFNumberGetValue(num, CFNumberGetType(num), since)) {
            goto exit;
        }
        *hasLowCapRatio = true;
        cachedHasLowCap = true;
        cachedLowCapRatioTime = *since;
        // set the flag to indicate the file was read once successfully
        cachedKeyPresence = true;
    }
    
    ret = kIOReturnSuccess;
    
exit:
    if (energyPrefs) CFRelease(energyPrefs);
    
#endif
    return ret;
}

IOReturn _setLowCapRatioTime(CFStringRef batterySerialNumber,
                             boolean_t hasLowCapRatio,
                             time_t since)
{
    IOReturn                    ret         = kIOReturnError;
#if !TARGET_OS_EMBEDDED
    boolean_t                   contains    = false;
    boolean_t                   locked      = false;
    
    SCPreferencesRef            energyPrefs = NULL; // must release
    CFMutableDictionaryRef      dict        = NULL; // must release
    CFNumberRef                 num         = NULL; // must release
    CFPropertyListRef           plist       = NULL; // do not release
    
    if (!isA_CFString(batterySerialNumber))
        goto exit;

    // return early if the cached copy indicates the flag is already set
    if (cachedKeyPresence)  {
        if (hasLowCapRatio == cachedHasLowCap) {
            ret = kIOReturnSuccess;
            goto exit;
        }
    }

    energyPrefs = SCPreferencesCreate(kCFAllocatorDefault,
                                      CFSTR(kIOPMAppName),
                                      CFSTR(kIOPMPrefsPath));
    if (!energyPrefs) {
        goto exit;
    }
    
    if (!SCPreferencesLock(energyPrefs, true)) {
        ret = kIOReturnInternalError;
        goto exit;
    }
    
    locked = true;

    plist = SCPreferencesGetValue(energyPrefs, CFSTR("BatteryWarn"));
    
    if (!plist) {
        contains = false;
    }
    else {
        if (CFGetTypeID(plist) != CFDictionaryGetTypeID()) {
            goto exit;
        }
        contains = CFDictionaryContainsKey(plist, batterySerialNumber);
    }
    
    // need to make changes to the SCPreferencesRef
    if (!plist) {
        dict = CFDictionaryCreateMutable(kCFAllocatorDefault,
                                         0,
                                         &kCFTypeDictionaryKeyCallBacks,
                                         &kCFTypeDictionaryValueCallBacks);
        if (!dict) {
            goto exit;
        }
    }
    else {
        dict = CFDictionaryCreateMutableCopy(kCFAllocatorDefault,
                                             0,
                                             plist);
        if (!dict) {
            goto exit;
        }
    }
    
    if (hasLowCapRatio && !contains) {
        // need to add entry
        num = CFNumberCreate(kCFAllocatorDefault,
                             kCFNumberSInt64Type,
                             &since);
        CFDictionarySetValue(dict, batterySerialNumber, num);
        CFRelease(num);
    }
    
    if (!hasLowCapRatio && contains) {
        // need to remove entry
        CFDictionaryRemoveValue(dict, batterySerialNumber);
    }
    
    if (CFDictionaryGetCount(dict) == 0) {
        // if dictionary is empty, remove it from the SCPreferences.
        if (!SCPreferencesRemoveValue(energyPrefs, CFSTR("BatteryWarn"))) {
            goto exit;
        }
    }
    else {
        if (!SCPreferencesSetValue(energyPrefs,
                                   CFSTR("BatteryWarn"),
                                   dict)) {
            goto exit;
        }
    }
    
    if (!SCPreferencesCommitChanges(energyPrefs))
    {
        // handle error
        if (kSCStatusAccessError == SCError()) ret = kIOReturnNotPrivileged;
        else ret = kIOReturnError;
        goto exit;
    }
    
    if (!SCPreferencesApplyChanges(energyPrefs))
    {
        // handle error
        if (kSCStatusAccessError == SCError())
            ret = kIOReturnNotPrivileged;
        else
            ret = kIOReturnError;

        goto exit;
    } else {
        // update the cached status only when changes get applied
        if (contains) {
            // entry was removed
            cachedHasLowCap = false;
            cachedLowCapRatioTime = 0;
        } else {
            // entry was added
            cachedHasLowCap = true;
            cachedLowCapRatioTime = since;
        }

        if (!cachedKeyPresence)
            cachedKeyPresence = true;
    }

    ret = kIOReturnSuccess;
    
exit:
    if (locked)         SCPreferencesUnlock(energyPrefs);
    
    if (energyPrefs)    CFRelease(energyPrefs);
    if (dict)           CFRelease(dict);
    
#endif
    return ret;
}

static void _unpackBatteryState(IOPMBattery *b, CFDictionaryRef prop)
{
    CFBooleanRef    boo;
    CFNumberRef     n;

    if(!isA_CFDictionary(prop)) return;

    boo = CFDictionaryGetValue(prop, CFSTR(kIOPMPSExternalConnectedKey));
    b->externalConnected = (kCFBooleanTrue == boo);

    boo = CFDictionaryGetValue(prop, CFSTR(kIOPMPSExternalChargeCapableKey));
    b->externalChargeCapable = (kCFBooleanTrue == boo);

    boo = CFDictionaryGetValue(prop, CFSTR(kIOPMPSBatteryInstalledKey));
    b->isPresent = (kCFBooleanTrue == boo);

    boo = CFDictionaryGetValue(prop, CFSTR(kIOPMPSIsChargingKey));
    b->isCharging = (kCFBooleanTrue == boo);

#if TARGET_OS_EMBEDDED
    boo = CFDictionaryGetValue(prop, CFSTR(kIOPMPSRawExternalConnectedKey));
    b->rawExternalConnected = (kCFBooleanTrue == boo);

    boo = CFDictionaryGetValue(prop, CFSTR(kIOPMPSAtCriticalLevelKey));
    b->isCritical = (kCFBooleanTrue == boo);

    boo = CFDictionaryGetValue(prop, CFSTR(kIOPMPSRestrictedModeKey));
    b->isRestricted = (kCFBooleanTrue == boo);
#endif

    b->failureDetected = (CFStringRef)CFDictionaryGetValue(prop, CFSTR(kIOPMPSErrorConditionKey));

    b->batterySerialNumber = (CFStringRef)CFDictionaryGetValue(prop, CFSTR("BatterySerialNumber"));

    b->chargeStatus = (CFStringRef)CFDictionaryGetValue(prop, CFSTR(kIOPMPSBatteryChargeStatusKey));
    
    _getLowCapRatioTime(b->batterySerialNumber,
                        &(b->hasLowCapRatio),
                        &(b->lowCapRatioSinceTime));
    
    n = CFDictionaryGetValue(prop, CFSTR(kIOPMPSVoltageKey));
    if(n) {
        CFNumberGetValue(n, kCFNumberIntType, &b->voltage);
    }
    n = CFDictionaryGetValue(prop, CFSTR(kIOPMPSCurrentCapacityKey));
    if(n) {
        CFNumberGetValue(n, kCFNumberIntType, &b->currentCap);
    }
    n = CFDictionaryGetValue(prop, CFSTR(kIOPMPSMaxCapacityKey));
    if(n) {
        CFNumberGetValue(n, kCFNumberIntType, &b->maxCap);
    }
    n = CFDictionaryGetValue(prop, CFSTR(kIOPMPSDesignCapacityKey));
    if(n) {
        CFNumberGetValue(n, kCFNumberIntType, &b->designCap);
    }
    n = CFDictionaryGetValue(prop, CFSTR(kIOPMPSTimeRemainingKey));
    if(n) {
        CFNumberGetValue(n, kCFNumberIntType, &b->hwAverageTR);
    }


    n = CFDictionaryGetValue(prop, CFSTR("InstantAmperage"));
    if(n) {
        CFNumberGetValue(n, kCFNumberIntType, &b->instantAmperage);
    }
    n = CFDictionaryGetValue(prop, CFSTR(kIOPMPSAmperageKey));
    if(n) {
        CFNumberGetValue(n, kCFNumberIntType, &b->avgAmperage);
    }
    n = CFDictionaryGetValue(prop, CFSTR(kIOPMPSMaxErrKey));
    if(n) {
        CFNumberGetValue(n, kCFNumberIntType, &b->maxerr);
    }
    n = CFDictionaryGetValue(prop, CFSTR(kIOPMPSCycleCountKey));
    if(n) {
        CFNumberGetValue(n, kCFNumberIntType, &b->cycleCount);
    }
    n = CFDictionaryGetValue(prop, CFSTR(kIOPMPSLocationKey));
    if(n) {
        CFNumberGetValue(n, kCFNumberIntType, &b->location);
    }
    n = CFDictionaryGetValue(prop, CFSTR(kIOPMPSInvalidWakeSecondsKey));
    if(n) {
        CFNumberGetValue(n, kCFNumberIntType, &b->invalidWakeSecs);
    } else {
        b->invalidWakeSecs = kInvalidWakeSecsDefault;
    }
    n = CFDictionaryGetValue(prop, CFSTR("PermanentFailureStatus"));
    if (n) {
        CFNumberGetValue(n, kCFNumberIntType, &b->pfStatus);
    } else {
        b->pfStatus = 0;
    }

    return;
}

/*
 * _batteries
 */
__private_extern__ IOPMBattery **_batteries(void)
{
        return physicalBatteriesArray;
}


__private_extern__ IOPMBattery *_newBatteryFound(io_registry_entry_t where)
{
    IOPMBattery *new_battery = NULL;
    static int new_battery_index = 0;
    // Populate new battery in array
    new_battery = calloc(1, sizeof(IOPMBattery));
    new_battery->me = where;
    new_battery->name = CFStringCreateWithFormat(
                            kCFAllocatorDefault,
                            NULL,
                            CFSTR("InternalBattery-%d"),
                            new_battery_index);

    new_battery_index++;
    _batteryChanged(new_battery);

    /* Real, physical battery found */
    if (!physicalBatteriesSet) {
        physicalBatteriesSet = CFSetCreateMutable(0, 1, NULL);
    }
    CFSetAddValue(physicalBatteriesSet, new_battery);
    physicalBatteriesCount = CFSetGetCount(physicalBatteriesSet);
    if (physicalBatteriesArray) {
        free(physicalBatteriesArray);
        physicalBatteriesArray = NULL;
    }
    physicalBatteriesArray = (IOPMBattery **)calloc(physicalBatteriesCount, sizeof(IOPMBattery *));
    CFSetGetValues(physicalBatteriesSet, (const void **)physicalBatteriesArray);

    // TODO: We should really be posting this kIOPSNotifyAttach from
    // BatteryTimeRemaining.c, not right here.
    notify_post(kIOPSNotifyAttach);
    
    return new_battery;
}


__private_extern__ void _batteryChanged(IOPMBattery *changed_battery)
{
    kern_return_t       kr;

    if(!changed_battery) {
        // This is unexpected; we're not tracking this battery
        return;
    }

    // Free the last set of properties
    if(changed_battery->properties) {
        CFRelease(changed_battery->properties);
        changed_battery->properties = NULL;
    }

    kr = IORegistryEntryCreateCFProperties(
                            changed_battery->me,
                            &(changed_battery->properties),
                            kCFAllocatorDefault, 0);
    if(KERN_SUCCESS != kr) {
        changed_battery->properties = NULL;
        goto exit;
    }

    _unpackBatteryState(changed_battery, changed_battery->properties);
exit:
    return;
}

__private_extern__ bool _batteryHas(IOPMBattery *b, CFStringRef property)
{
    if(!property || !b->properties) return false;

    // If the battery's descriptior dictionary has an entry at all for the
    // given 'property' it is supported, i.e. the battery 'has' it.
    return CFDictionaryGetValue(b->properties, property) ? true : false;
}


#if HAVE_CF_USER_NOTIFICATION

__private_extern__ CFUserNotificationRef _copyUPSWarning(void)
{
    CFMutableDictionaryRef      alert_dict;
    SInt32                      error;
    CFUserNotificationRef       note_ref;
    CFBundleRef                 myBundle;
    CFStringRef                 header_unlocalized;
    CFStringRef                 message_unlocalized;
    CFURLRef                    bundle_url;

    myBundle = CFBundleGetBundleWithIdentifier(kPowerdBundleIdentifier);
    if (!myBundle)
        return NULL;

    alert_dict = CFDictionaryCreateMutable(kCFAllocatorDefault, 0,
                            &kCFTypeDictionaryKeyCallBacks, &kCFTypeDictionaryValueCallBacks);
    if(!alert_dict)
        return NULL;

    bundle_url = CFBundleCopyBundleURL(myBundle);
    CFDictionarySetValue(alert_dict, kCFUserNotificationLocalizationURLKey, bundle_url);
    CFRelease(bundle_url);

    header_unlocalized = CFSTR("WARNING!");
    message_unlocalized = CFSTR("YOUR COMPUTER IS NOW RUNNING ON UPS BACKUP BATTERY. SAVE YOUR DOCUMENTS AND SHUTDOWN SOON.");

    CFDictionaryAddValue(alert_dict, kCFUserNotificationAlertHeaderKey, header_unlocalized);
    CFDictionaryAddValue(alert_dict, kCFUserNotificationAlertMessageKey, message_unlocalized);

    note_ref = CFUserNotificationCreate(kCFAllocatorDefault, 0, 0, &error, alert_dict);
    CFRelease(alert_dict);

    asl_log(0, 0, ASL_LEVEL_ERR, "PowerManagement: UPS low power warning\n");

    return note_ref;
}

#endif

/***************************************************************************/
/***************************************************************************/
/***************************************************************************/
/*      AAAAAAAAAAAAAA      SSSSSSSSSSSSSS       LLLLLLLLLLLLLLLL          */
/***************************************************************************/
/***************************************************************************/
/***************************************************************************/

__private_extern__ bool getPowerState(PowerSources *source, uint32_t *percentage)
{
    IOPMBattery                                 **batteries;
    int                                         batteryCount = 0;
    uint32_t                                    capPercent = 0;
    int                                         i;

    batteryCount = _batteryCount();
    if (0 < batteryCount) {
        batteries = _batteries();
        for (i=0; i< batteryCount; i++) {
            if (batteries[i]->isPresent
                && (0 != batteries[i]->maxCap)) {
                capPercent += (batteries[i]->currentCap * 100) / batteries[i]->maxCap;
            }
        }
        *source = batteries[0]->externalConnected ? kACPowered : kBatteryPowered;
        *percentage = capPercent;
        return true;
    } else {
        *source = kACPowered;
        return false;
    }
}


static void printCapabilitiesToBuf(char *buf, int buf_size, IOPMCapabilityBits in_caps)
{
    uint64_t caps = (uint64_t)in_caps;

//    snprintf(buf, buf_size, "%s:%s%s%s%s%s%s%s",
//                             on_sleep_dark,
    snprintf(buf, buf_size, " [%s%s%s%s%s%s%s]",
                             (caps & kIOPMCapabilityCPU) ? "C":"<off> ",
                             (caps & kIOPMCapabilityDisk) ? "D":"",
                             (caps & kIOPMCapabilityNetwork) ? "N":"",
                             (caps & kIOPMCapabilityVideo) ? "V":"",
                             (caps & kIOPMCapabilityAudio) ? "A":"",
                             (caps & kIOPMCapabilityPushServiceTask) ? "P":"",
                             (caps & kIOPMCapabilityBackgroundTask) ? "B":"");
}


__private_extern__ aslmsg new_msg_pmset_log(void)
{
    aslmsg m = asl_new(ASL_TYPE_MSG);

    asl_set(m, ASL_KEY_LEVEL, ASL_STRING_NOTICE);
    asl_set(m, ASL_KEY_FACILITY, kPMFacility);

    return m;
}


__private_extern__ void logASLMessagePMStart(void)
{
    aslmsg                  m;
    char                    uuidString[150];

    m = new_msg_pmset_log();

    if (_getUUIDString(uuidString, sizeof(uuidString))) {
        asl_set(m, kPMASLUUIDKey, uuidString);
    }
    asl_set(m, kPMASLDomainKey, kPMASLDomainPMStart);
    asl_set(m, ASL_KEY_MSG, "powerd process is started\n");
    asl_send(NULL, m);
    asl_release(m);
}

#if TCPKEEPALIVE

static void attachTCPKeepAliveKeys(
                                   aslmsg m,
                                   char *tcpString,
                                   unsigned int tcpStringLen)

{
    CFTypeRef           platformSupport = NULL;
    char                keepAliveString[100];
    
    IOPlatformCopyFeatureDefault(kIOPlatformTCPKeepAliveDuringSleep, &platformSupport);
    if (kCFBooleanTrue == platformSupport)
    {
        asl_set(m, kPMASLTCPKeepAlive, "supported");
        
        getTCPKeepAliveState(keepAliveString, sizeof(keepAliveString));

        asl_set(m, kPMASLTCPKeepAliveExpired, keepAliveString);
        snprintf(tcpString, tcpStringLen, "TCPKeepAlive=%s", keepAliveString);
    }

    if (platformSupport){
        CFRelease(platformSupport);
    }
}

#endif

__private_extern__ void logASLMessageSleep(
    const char *sig,
    const char *uuidStr,
    const char *failureStr,
    int   sleepType
)
{
    aslmsg                  m;
    char                    uuidString[150];
    char                    source[10];
    uint32_t                percentage;
    char                    numbuf[15];
    bool                    success = true;
    char                    messageString[200];
    char                    reasonString[100];
    char                    tcpKeepAliveString[50];
    PowerSources            pwrSrc;

    m = new_msg_pmset_log();

    reasonString[0] = messageString[0] = tcpKeepAliveString[0] = source[0] =  0;
    
    _getSleepReasonLogStr(reasonString, sizeof(reasonString));
    
    if (!strncmp(sig, kPMASLSigSuccess, sizeof(kPMASLSigSuccess)))
    {
        success = true;
        if (sleepType == kIsS0Sleep) {
            snprintf(messageString, sizeof(messageString), "Entering Sleep state");
#if !TARGET_OS_EMBEDDED && TCPKEEPALIVE
            attachTCPKeepAliveKeys(m, tcpKeepAliveString, sizeof(tcpKeepAliveString));
#endif
        } else {
           snprintf(messageString, sizeof(messageString), "Entering DarkWake state");
        }

        if (reasonString[0] != 0) {
            snprintf(messageString, sizeof(messageString), "%s due to %s", messageString, reasonString);
        }
        
    } else {
        success = false;
        snprintf(messageString, sizeof(messageString), "Sleep Failure [code:%s]",
                failureStr);
    }

    if (success) {
        asl_set(m, kPMASLDomainKey, kPMASLDomainPMSleep);
        if (getPowerState(&pwrSrc, &percentage)) {
            snprintf(numbuf, 10, "%d", percentage);
            asl_set(m, kPMASLBatteryPercentageKey, numbuf);
        }
        asl_set(m, kPMASLPowerSourceKey, (pwrSrc == kACPowered) ? "AC" : "Batt");
    }
    else {
        asl_set(m, kPMASLDomainKey, kPMASLDomainSWFailure);
        sleepCntSinceFailure = 0;
    }

    // UUID
    if (uuidStr) {
        asl_set(m, kPMASLUUIDKey, uuidStr);  // Caller Provided
    } else if (_getUUIDString(uuidString, sizeof(uuidString))) {
        asl_set(m, kPMASLUUIDKey, uuidString);
    }
    
    snprintf(messageString, sizeof(messageString), "%s:%s",
            messageString, tcpKeepAliveString);
    
    asl_set(m, kPMASLSignatureKey, sig);
    asl_set(m, ASL_KEY_MSG, messageString);
    asl_send(NULL, m);
    asl_release(m);

    if (!success) {
        // Log stats to update sleepCntSinceFailure in asl
        logASLMessageHibernateStatistics( );
    }
}

/*****************************************************************************/
#pragma mark ASL

__private_extern__ void logASLMessageWake(
    const char *sig,
    const char *uuidStr,
    const char *failureStr,
    IOPMCapabilityBits in_capabilities,
    WakeTypeEnum dark_wake
)
{
    aslmsg                  m;
    int                     i = 0;
    CFStringRef             tmpStr = NULL;
    char                    buf[200];
    char                    source[10];
    uint32_t                percentage;
    char                    wakeReasonBuf[50];
    char                    cBuf[50];
    const char *            detailString = NULL;
    static int              darkWakeCnt = 0;
    char                    numbuf[15];
    static char             prev_uuid[50];
    CFStringRef             wakeType = NULL;
    const char *            sleepTypeString;
    bool                    success = true;
    PowerSources            pwrSrc;

    m = new_msg_pmset_log();

    asl_set(m, kPMASLSignatureKey, sig);
    if (_getUUIDString(buf, sizeof(buf))) {
        asl_set(m, kPMASLUUIDKey, buf);
        if (strncmp(buf, prev_uuid, sizeof(prev_uuid))) {
              // New sleep/wake cycle.
              snprintf(prev_uuid, sizeof(prev_uuid), "%s", buf);
              darkWakeCnt = 0;
        }
    }

    buf[0] = source[0] = 0;
    if (!strncmp(sig, kPMASLSigSuccess, sizeof(kPMASLSigSuccess)))
    {
        char  wakeTypeBuf[50];

        wakeReasonBuf[0] = wakeTypeBuf[0] = 0;
#if TARGET_OS_EMBEDDED
        size_t  size = sizeof(wakeReasonBuf);
        sysctlbyname("kern.wakereason", wakeReasonBuf, &size, NULL, 0);
#else
        if (isA_CFString(reasons.platformWakeReason)) {
            CFStringGetCString(reasons.platformWakeReason, wakeReasonBuf, sizeof(wakeReasonBuf), kCFStringEncodingUTF8);
        }
        if (isA_CFString(reasons.platformWakeType)) {
            CFStringGetCString(reasons.platformWakeType, wakeTypeBuf, sizeof(wakeTypeBuf), kCFStringEncodingUTF8);
        }
        snprintf(wakeReasonBuf, sizeof(wakeReasonBuf), "%s/%s", wakeReasonBuf, wakeTypeBuf);
#endif
        detailString = wakeReasonBuf;
        if (getPowerState(&pwrSrc, &percentage)) {
            snprintf(numbuf, 10, "%d", percentage);
            asl_set(m, kPMASLBatteryPercentageKey, numbuf);
        }
        asl_set(m, kPMASLPowerSourceKey, (pwrSrc == kACPowered) ? "AC" : "BATT");
    } else {
        detailString = failureStr;
        snprintf(buf, sizeof(buf), "%s during wake", 
                 (sig) ? sig : "");
        success = false;

        sleepCntSinceFailure = 0;
    }
    
    /* populate driver wake reasons */
    if (success && isA_CFArray(reasons.claimedWakeEventsArray))
    {
        int  keyIndex = 0;
        long    claimedCount = CFArrayGetCount(reasons.claimedWakeEventsArray);

        for (i=0; i<claimedCount; i++) {
            /* Legal requirement: 16513925 & 16544525
             * Limit the length of the reported string to 60 characters.
             */
            const int               kMaxClaimReportLen = 60;

            CFDictionaryRef         claimedEvent = NULL;
            char                    claimedReasonStr[kMaxClaimReportLen];
            char                    claimedDetailsStr[kMaxClaimReportLen];
            char                    claimed[255];
            char                    key[255];


            claimedReasonStr[0] = 0;
            claimedDetailsStr[0] = 0;
            
            claimedEvent = CFArrayGetValueAtIndex(reasons.claimedWakeEventsArray, i);
            if (!isA_CFDictionary(claimedEvent)) continue;
            
            tmpStr = CFDictionaryGetValue(claimedEvent,
                                          CFSTR(kIOPMWakeEventReasonKey));
            if (isA_CFString(tmpStr)) {
                CFStringGetCString(tmpStr, claimedReasonStr, sizeof(claimedReasonStr), kCFStringEncodingUTF8);
            }
            if (!claimedReasonStr[0]) continue;

            tmpStr = CFDictionaryGetValue(claimedEvent,
                                          CFSTR(kIOPMWakeEventDetailsKey));
            if (isA_CFString(tmpStr)) {
                CFStringGetCString(tmpStr, claimedDetailsStr, sizeof(claimedDetailsStr), kCFStringEncodingUTF8);
            }

            snprintf(claimed, sizeof(claimed), "DriverReason:%s - DriverDetails:%s",
                                                claimedReasonStr, claimedDetailsStr);
            
            snprintf(key, sizeof(key), "%s-%d", kPMASLClaimedEventKey, keyIndex);
            
            asl_set(m, key, claimed);
            keyIndex++;
        }
    
    }


    if (!success)
    {
        asl_set(m, kPMASLDomainKey, kPMASLDomainSWFailure);
    }
    else if (dark_wake == kIsDarkWake)
    {
        asl_set(m, kPMASLDomainKey, kPMASLDomainPMDarkWake);
        snprintf(buf, sizeof(buf), "%s", "DarkWake");
        darkWakeCnt++;
        snprintf(numbuf, sizeof(numbuf), "%d", darkWakeCnt);
        asl_set(m, kPMASLValueKey, numbuf);
    }
    else if (dark_wake == kIsDarkToFullWake)
    {
        wakeType = _copyRootDomainProperty(CFSTR(kIOPMRootDomainWakeTypeKey));
        if (isA_CFString(wakeType)) {
            CFStringGetCString(wakeType, wakeReasonBuf, sizeof(wakeReasonBuf), kCFStringEncodingUTF8);
        }
        if (wakeType) {
            CFRelease(wakeType);
        }
        asl_set(m, kPMASLDomainKey, kPMASLDomainPMWake);
        snprintf(buf, sizeof(buf), "%s", "DarkWake to FullWake");
    }
    else
    {
        asl_set(m, kPMASLDomainKey, kPMASLDomainPMWake);
        snprintf(buf, sizeof(buf), "%s", "Wake");
    }

    if (success)
    {
        if ((sleepTypeString = getSleepTypeString()))
        {
            snprintf(buf, sizeof(buf), "%s from %s", buf, sleepTypeString);
        }

        printCapabilitiesToBuf(cBuf, sizeof(cBuf), in_capabilities);
        strncat(buf, cBuf, sizeof(buf)-strlen(buf)-1);
    }

    snprintf(buf, sizeof(buf), "%s %s %s:\n", buf,
          detailString ? "due to" : "",
          detailString ? detailString : "");

    asl_set(m, ASL_KEY_MSG, buf);
    asl_send(NULL, m);
    asl_release(m);

    logASLMessageHibernateStatistics( );
}
/*****************************************************************************/

__private_extern__ void logASLAppWakeReason(
                                            const char * ident,
                                            const char * reason)
{
#define kPMASLDomainAppWakeReason   "AppWakeReason"

    aslmsg m = new_msg_pmset_log();

    asl_set(m, kPMASLDomainKey, kPMASLDomainAppWakeReason);
    if (ident) {
        asl_set(m, kPMASLSignatureKey, ident);
    }

    char msg[255];
    snprintf(msg, sizeof(msg), "AppWoke:%s Reason:%s", ident?ident:"--none--", reason?reason:"--none--");
    asl_set(m, ASL_KEY_MSG, msg);

    asl_send(NULL, m);
    asl_release(m);
}


/*****************************************************************************/

static void logASLMessageHibernateStatistics(void)
{
    aslmsg                  m = NULL;
    CFDataRef               statsData = NULL;
    PMStatsStruct           *stats = NULL;
    uint64_t                readHIBImageMS = 0;
    uint64_t                writeHIBImageMS = 0;
    CFNumberRef             hibernateModeNum = NULL;
    CFNumberRef             hibernateDelayNum = NULL;
    int                     hibernateMode = 0;
    char                    valuestring[25];
    int                     hibernateDelay = 0;
    char                    buf[100];
    char                    uuidString[150];

    if (sleepCntSinceFailure == -1) {
        initSleepCnt();
    }
    m = new_msg_pmset_log();

    asl_set(m, kPMASLDomainKey, kPMASLDomainHibernateStatistics);

    asl_set(m, ASL_KEY_LEVEL, ASL_STRING_NOTICE);

    if (_getUUIDString(uuidString, sizeof(uuidString))) {
        asl_set(m, kPMASLUUIDKey, uuidString);
    }

    snprintf(buf, sizeof(buf), "%d", sleepCntSinceBoot);
    asl_set(m, kPMASLSleepCntSinceBoot, buf);
    snprintf(buf, sizeof(buf), "%d", sleepCntSinceFailure);
    asl_set(m, kPMASLSleepCntSinceFailure, buf);

    hibernateModeNum = (CFNumberRef)_copyRootDomainProperty(CFSTR(kIOHibernateModeKey));
    if (!hibernateModeNum)
        goto exit;
    CFNumberGetValue(hibernateModeNum, kCFNumberIntType, &hibernateMode);
    CFRelease(hibernateModeNum);

    hibernateDelayNum= (CFNumberRef)_copyRootDomainProperty(CFSTR(kIOPMDeepSleepDelayKey));
    if (!hibernateDelayNum)
        goto exit;
    CFNumberGetValue(hibernateDelayNum, kCFNumberIntType, &hibernateDelay);
    CFRelease(hibernateDelayNum);

    statsData = (CFDataRef)_copyRootDomainProperty(CFSTR(kIOPMSleepStatisticsKey));
    if (!statsData || !(stats = (PMStatsStruct *)CFDataGetBytePtr(statsData)))
    {
        goto exit;
    } else {
        writeHIBImageMS = (stats->hibWrite.stop - stats->hibWrite.start)/1000000UL;

        readHIBImageMS =(stats->hibRead.stop - stats->hibRead.start)/1000000UL;

        /* Hibernate image is not generated on every sleep for some h/w */
        if ( !writeHIBImageMS && !readHIBImageMS)
            goto exit;
    }

    snprintf(valuestring, sizeof(valuestring), "hibernatemode=%d", hibernateMode);
    asl_set(m, kPMASLSignatureKey, valuestring);
    // If readHibImageMS == zero, that means we woke from the contents of memory
    // and did not read the hibernate image.
    if (writeHIBImageMS)
        snprintf(buf, sizeof(buf), "wr=%qd ms ", writeHIBImageMS);

    if (readHIBImageMS)
        snprintf(buf, sizeof(buf), "rd=%qd ms", readHIBImageMS);
    asl_set(m, kPMASLDelayKey, buf);

    snprintf(buf, sizeof(buf), "hibmode=%d standbydelay=%d", hibernateMode, hibernateDelay);
    asl_set(m, ASL_KEY_MSG, buf);

exit:
    if (m) {
        asl_send(NULL, m);
        asl_release(m);
    }
    if(statsData)
        CFRelease(statsData);
    return;
}

/*****************************************************************************/

__private_extern__ void logASLPMConnectionNotify(
    CFStringRef     appNameString,
    int             notificationBits
    )
{

    aslmsg m;
    char buf[128];
    char appName[100];


    m = new_msg_pmset_log();
    asl_set(m, kPMASLDomainKey, kPMASLDomainAppNotify);


    if (!CFStringGetCString(appNameString, appName, sizeof(appName), kCFStringEncodingUTF8))
       snprintf(appName, sizeof(appName), "Unknown app");


    asl_set(m, kPMASLSignatureKey, appName);

    // UUID
    if (_getUUIDString(buf, sizeof(buf))) {
        asl_set(m, kPMASLUUIDKey, buf);
    }

   snprintf(buf, sizeof(buf), "Notification sent to %s (powercaps:0x%x)",
         appName,notificationBits );

    asl_set(m, ASL_KEY_MSG, buf);
    asl_send(NULL, m);
    asl_release(m);
}

__private_extern__ void logASLDisplayStateChange()
{

#if !TARGET_OS_EMBEDDED
    aslmsg m;
    char buf[128];
    bool displayState = isDisplayAsleep();


    m = new_msg_pmset_log();
    asl_set(m, kPMASLDomainKey, kPMASLDomainAppNotify);

    // UUID
    if (_getUUIDString(buf, sizeof(buf))) {
        asl_set(m, kPMASLUUIDKey, buf);
    }

   snprintf(buf, sizeof(buf), "Display is turned %s",
        displayState ? "off" : "on");

    asl_set(m, ASL_KEY_MSG, buf);
    asl_send(NULL, m);
    asl_release(m);

    if (displayState) {
        /* Log all assertions when display goes off */
        CFRunLoopPerformBlock(_getPMRunLoop(), kCFRunLoopDefaultMode, ^{ logASLAllAssertions(); });
        CFRunLoopWakeUp(_getPMRunLoop());
    }
#endif
}

__private_extern__ void logASLPerforamceState(int perfState)
{
    aslmsg m;
    char buf[128];


    m = new_msg_pmset_log();
    asl_set(m, kPMASLDomainKey, kPMASLDomainPerformanceEvent);

    // UUID
    if (_getUUIDString(buf, sizeof(buf))) {
        asl_set(m, kPMASLUUIDKey, buf);
    }

   snprintf(buf, sizeof(buf), "Performance State is %d", perfState);

    asl_set(m, ASL_KEY_MSG, buf);
    asl_send(NULL, m);
    asl_release(m);


}

__private_extern__ void logASLThermalState(int thermalState)
{
    aslmsg m;
    char buf[128];


    m = new_msg_pmset_log();
    asl_set(m, kPMASLDomainKey, kPMASLDomainThermalEvent);

    // UUID
    if (_getUUIDString(buf, sizeof(buf))) {
        asl_set(m, kPMASLUUIDKey, buf);
    }

   snprintf(buf, sizeof(buf), "Thermal State is %d", thermalState);

    asl_set(m, ASL_KEY_MSG, buf);
    asl_send(NULL, m);
    asl_release(m);


}

__private_extern__ void logASLMessagePMConnectionResponse(
    CFStringRef     logSourceString,
    CFStringRef     appNameString,
    CFStringRef     responseTypeString,
    CFNumberRef     responseTime,
    int             notificationBits
)
{
    aslmsg                  m;
    char                    appName[128];
    char                    *appNamePtr = NULL;
    int                     time = 0;
    char                    buf[128];
    char                    qualifier[30];
    bool                    timeout = false;

    // String identifying the source of the log is required.
    if (!logSourceString)
        return;
    
    m = new_msg_pmset_log();

    if (responseTypeString && CFEqual(responseTypeString, CFSTR(kIOPMStatsResponseTimedOut)))
    {
        asl_set(m, kPMASLDomainKey, kPMASLDomainAppResponseTimedOut);
        snprintf(qualifier, sizeof(qualifier), "timed out");
        timeout = true;
    } else
        if (responseTypeString && CFEqual(responseTypeString, CFSTR(kIOPMStatsResponseCancel)))
    {
        asl_set(m, kPMASLDomainKey, kPMASLDomainAppResponseCancel);
        snprintf(qualifier, sizeof(qualifier), "is to cancel state change");
    } else
        if (responseTypeString && CFEqual(responseTypeString, CFSTR(kIOPMStatsResponseSlow)))
    {
        asl_set(m, kPMASLDomainKey, kPMASLDomainAppResponseSlow);
        snprintf(qualifier, sizeof(qualifier), "is slow");
    } else
        if (responseTypeString && CFEqual(responseTypeString, CFSTR(kPMASLDomainSleepServiceCapApp)))
    {
        asl_set(m, kPMASLDomainKey, kPMASLDomainSleepServiceCapApp);
        snprintf(qualifier, sizeof(qualifier), "exceeded SleepService cap");
    } else
        if (responseTypeString && CFEqual(responseTypeString, CFSTR(kPMASLDomainAppResponse)))
    {
        asl_set(m, kPMASLDomainKey, kPMASLDomainAppResponseReceived);
        snprintf(qualifier, sizeof(qualifier), "received");
    } else {
        asl_release(m);
        return;
    }

    // Message = Failing process name
    if (appNameString)
    {
        if (CFStringGetCString(appNameString, appName, sizeof(appName), kCFStringEncodingUTF8))
        {
                appNamePtr = &appName[0];
        }
    }
    if (!appNamePtr) {
        appNamePtr = "AppNameUnknown";
    }

    asl_set(m, kPMASLSignatureKey, appNamePtr);

    // UUID
    if (_getUUIDString(buf, sizeof(buf))) {
        asl_set(m, kPMASLUUIDKey, buf);
    }

    // Value == Time
    if (responseTime) {
        if (CFNumberGetValue(responseTime, kCFNumberIntType, &time)) {
            snprintf(buf, sizeof(buf), "%d", time);
            asl_set(m, kPMASLValueKey, buf);
        }
    }

    if (CFStringGetCString(logSourceString, buf, sizeof(buf), kCFStringEncodingUTF8)) {
        snprintf(buf, sizeof(buf), "%s: Response from %s %s",
              buf, appNamePtr, qualifier);
    } else {
        snprintf(buf, sizeof(buf), "Response from %s %s",
              appNamePtr, qualifier);
    }

    if (notificationBits != -1)
       snprintf(buf, sizeof(buf), "%s (powercaps:0x%x)", buf, notificationBits);

    asl_set(m, ASL_KEY_MSG, buf);

    if (time != 0) {
       snprintf(buf, sizeof(buf), "%d ms", time);
       asl_set(m, kPMASLDelayKey, buf);
    }

    asl_send(NULL, m);
    asl_release(m);

    if (timeout) {
        mt2RecordAppTimeouts(reasons.sleepReason, appNameString);
    }
}

/*****************************************************************************/

/* logASLMessageAppStats
 *
 * Logs ASL message for delays and timeouts in acknowledging power notifications
 *
 */
__private_extern__ void  logASLMessageAppStats(CFArrayRef appFailuresArray, char *domain)
{
    CFDictionaryRef         appFailures = NULL;
    CFStringRef             appNameString = NULL;
    CFStringRef             transString = NULL;
    CFNumberRef             numRef = NULL;
    CFStringRef             responseTypeString = NULL;
    long                    numElems = 0;
    int                     appCnt = 0;
    int                     i = 0;
    aslmsg                  m;
    char                    appName[128];
    char                    responseType[32];
    int                     num = 0;
    char                    key[128];
    char                    numStr[10];


    if (!isA_CFArray(appFailuresArray))
        return;

    numElems = CFArrayGetCount(appFailuresArray);
    if (numElems == 0)
        return;

    m = new_msg_pmset_log();
    asl_set(m, kPMASLDomainKey, domain);

    for (i = 0; i < numElems; i++)
    {
        appFailures = CFArrayGetValueAtIndex(appFailuresArray, i);
        if ( !isA_CFDictionary(appFailures)) {
            break;
        }


        appNameString = CFDictionaryGetValue(appFailures, CFSTR(kIOPMStatsNameKey));
        if (!isA_CFString(appNameString) || 
            (!CFStringGetCString(appNameString, appName, sizeof(appName), kCFStringEncodingUTF8))) {
            continue;
        }

        numRef = CFDictionaryGetValue(appFailures, CFSTR(kIOPMStatsTimeMSKey));
        if (!isA_CFNumber(numRef) || (!CFNumberGetValue(numRef, kCFNumberIntType, &num))) {
                continue;
        }
        numStr[0] = 0;
        snprintf(numStr, sizeof(numStr), "%d", num);

        responseTypeString  = CFDictionaryGetValue(appFailures, CFSTR(kIOPMStatsApplicationResponseTypeKey));
        if (!isA_CFString(responseTypeString) || 
            (!CFStringGetCString(responseTypeString, responseType, sizeof(responseType), kCFStringEncodingUTF8))) {
            continue;
        }

        if (!_getUUIDString(key, sizeof(key)))
            continue;
        asl_set(m, kPMASLUUIDKey, key);

        if (transString == NULL) {
            // Transition should be same for all apps listed in appFailuresArray.
            // So, set kPMASLResponseSystemTransition only once
            transString = CFDictionaryGetValue(appFailures, CFSTR(kIOPMStatsSystemTransitionKey));
            if (isA_CFString(transString)  && 
                (CFStringGetCString(transString, key, sizeof(key), kCFStringEncodingUTF8))) {
                    asl_set(m, kPMASLResponseSystemTransition, key);
            }
        }

        snprintf(key, sizeof(key), "%s%d",kPMASLResponseAppNamePrefix, appCnt);
        asl_set(m, key, appName);

        snprintf(key, sizeof(key), "%s%d", kPMASLResponseRespTypePrefix, appCnt);
        asl_set(m, key, responseType);

        snprintf(key, sizeof(key), "%s%d", kPMASLResponseDelayPrefix, appCnt);
        asl_set(m, key, numStr);

        numRef = CFDictionaryGetValue(appFailures, CFSTR(kIOPMStatsMessageTypeKey));
        if (isA_CFNumber(numRef) && (CFNumberGetValue(numRef, kCFNumberIntType, &num))) {

            snprintf(key, sizeof(key), "%s%d", kPMASLResponseMessagePrefix, appCnt);
            if (num == kDriverCallSetPowerState)
                asl_set(m, key, "SetState");
            else if (num == kDriverCallInformPreChange)
                asl_set(m, key, "WillChangeState");
            else 
                asl_set(m, key, "DidChangeState");
        }

        numRef = CFDictionaryGetValue(appFailures, CFSTR(kIOPMStatsPowerCapabilityKey));
        if (isA_CFNumber(numRef) && (CFNumberGetValue(numRef, kCFNumberIntType, &num))) {
            numStr[0] = 0;
            snprintf(numStr, sizeof(numStr), "%d", num);

            snprintf(key, sizeof(key), "%s%d", kPMASLResponsePSCapsPrefix, appCnt);
            asl_set(m, key, numStr);
        }

        appCnt++;

        if (CFEqual(responseTypeString, CFSTR(kIOPMStatsResponseTimedOut))) {
            mt2RecordAppTimeouts(reasons.sleepReason, appNameString);
        }
    }
    asl_send(NULL, m);
    asl_release(m);

}


__private_extern__ void logASLMessagePMConnectionScheduledWakeEvents(CFStringRef requestedMaintenancesString)
{
    aslmsg                  m;
    char                    buf[100];
    char                    requestors[500];
    CFMutableStringRef      messageString = NULL;

    messageString = CFStringCreateMutable(0, 0);
    if (!messageString)
        return;

    m = new_msg_pmset_log();

    if (_getUUIDString(buf, sizeof(buf))) {
        asl_set(m, kPMASLUUIDKey, buf);
    }

    CFStringAppendCString(messageString, "Clients requested wake events: ", kCFStringEncodingUTF8);
    if (requestedMaintenancesString && (0 < CFStringGetLength(requestedMaintenancesString))) {
        CFStringAppend(messageString, requestedMaintenancesString);
    } else {
        CFStringAppend(messageString, CFSTR("None"));
    }

    CFStringGetCString(messageString, requestors, sizeof(requestors), kCFStringEncodingUTF8);

    asl_set(m, kPMASLDomainKey, kPMASLDomainPMWakeRequests);
    asl_set(m, ASL_KEY_MSG, requestors);
    asl_send(NULL, m);
    asl_release(m);
    CFRelease(messageString);

}

__private_extern__ void logASLMessageExecutedWakeupEvent(CFStringRef requestedMaintenancesString)
{
    aslmsg                  m;
    char                    buf[100];
    char                    requestors[500];
    CFMutableStringRef      messageString = CFStringCreateMutable(0, 0);

    if (!messageString)
        return;

    m = new_msg_pmset_log();

    if (_getUUIDString(buf, sizeof(buf))) {
        asl_set(m, kPMASLUUIDKey, buf);
    }

    CFStringAppendCString(messageString, "PM scheduled RTC wake event: ", kCFStringEncodingUTF8);
    CFStringAppend(messageString, requestedMaintenancesString);

    CFStringGetCString(messageString, requestors, sizeof(requestors), kCFStringEncodingUTF8);

    asl_set(m, kPMASLDomainKey, kPMASLDomainPMWakeRequests);
    asl_set(m, ASL_KEY_MSG, requestors);
    asl_send(NULL, m);
    asl_release(m);
    CFRelease(messageString);
}

#if !TARGET_OS_EMBEDDED
__private_extern__ void logASLMessageIgnoredDWTEmergency(void)
{
    aslmsg      m;
    char        strbuf[125];
    char        tcpKeepAliveString[50];

    bzero(strbuf, sizeof(strbuf));
    bzero(tcpKeepAliveString, sizeof(tcpKeepAliveString));

    m = new_msg_pmset_log();
#if TCPKEEPALIVE
    attachTCPKeepAliveKeys(m, tcpKeepAliveString, sizeof(tcpKeepAliveString));
#endif
    
    asl_set(m, kPMASLDomainKey, kPMASLDomainThermalEvent);

    snprintf(
        strbuf,
        sizeof(strbuf),
        "Ignored DarkWake thermal emergency signal %s", tcpKeepAliveString);
    asl_set(m, ASL_KEY_MSG, strbuf);

    asl_send(NULL, m);
    asl_release(m);
}
#endif

__private_extern__ void logASLMessageSleepCanceledAtLastCall(
                               bool tcpka_active,
                               bool sys_active,
                               bool pending_wakes)
{
    aslmsg      m;
    char        strbuf[250];
    char        tcpKeepAliveString[50];

    bzero(strbuf, sizeof(strbuf));
    bzero(tcpKeepAliveString, sizeof(tcpKeepAliveString));

    m = new_msg_pmset_log();

#if TCPKEEPALIVE
    if (tcpka_active)
        attachTCPKeepAliveKeys(m, tcpKeepAliveString, sizeof(tcpKeepAliveString));
#endif

    asl_set(m, kPMASLDomainKey, kPMASLDomainSleepRevert);

    snprintf( strbuf, sizeof(strbuf),
        "Sleep in process aborted due to ");
    if (tcpka_active)
        snprintf(strbuf, sizeof(strbuf), "%s (TCP KeepAlive activity -- %s) ", strbuf, tcpKeepAliveString);
    if (sys_active)
        snprintf(strbuf, sizeof(strbuf), "%s (SystemIsActive assertions)", strbuf);
    if (pending_wakes)
        snprintf(strbuf, sizeof(strbuf), "%s (Pending system wake request)", strbuf);

    asl_set(m, ASL_KEY_MSG, strbuf);

    asl_send(NULL, m);
    asl_release(m);
}

__private_extern__ void logASLBatteryHealthChanged(const char *health,
                                                   const char *oldhealth,
                                                   const char *reason)
{
    aslmsg      m;
    char        strbuf[125];
    
    bzero(strbuf, sizeof(strbuf));
    
    m = new_msg_pmset_log();
    
    asl_set(m, kPMASLDomainKey, kPMASLDomainBattery);
    
    if (!strncmp(oldhealth, "", 5)) {
        snprintf(
                 strbuf,
                 sizeof(strbuf),
                 "Battery health: %s", health);
    } else if (!strncmp(reason, "", 5)){
        snprintf(
                 strbuf,
                 sizeof(strbuf),
                 "Battery health: %s; was: %s", health, oldhealth);
    } else {
        snprintf(
                 strbuf,
                 sizeof(strbuf),
                 "Battery health: %s; was: %s; reason %s", health, oldhealth, reason);
    }
    asl_set(m, ASL_KEY_MSG, strbuf);
    
    asl_send(NULL, m);
    asl_release(m);
}

__private_extern__ void logASLLowBatteryWarning(IOPSLowBatteryWarningLevel level,
                                                   int time, int ccap)
{
#if !TARGET_OS_EMBEDDED
    aslmsg      m;
    char        strbuf[125];
    
    bzero(strbuf, sizeof(strbuf));
    
    m = new_msg_pmset_log();
    
    asl_set(m, kPMASLDomainKey, kPMASLDomainBattery);
    
    snprintf(strbuf, sizeof(strbuf), "Warning level: %d time: %d cap: %d\n",
             level, time, ccap);
    asl_set(m, ASL_KEY_MSG, strbuf);
    
    asl_send(NULL, m);
    asl_release(m);
#endif
}

__private_extern__ void logASLSleepPreventers(int preventerType)
{
#if !TARGET_OS_EMBEDDED
    aslmsg      m;
    char        strbuf[125];
    CFArrayRef  preventers;
    IOReturn    ret;
    char        name[32];
    long        count = 0;
    size_t      len = 0;


    strbuf[0] = 0;

    ret = IOPMCopySleepPreventersList(preventerType, &preventers);
    if (ret != kIOReturnSuccess)
    {
        return;
    }
    if (isA_CFArray(preventers))
    {
        count = CFArrayGetCount(preventers);
    }

    m = new_msg_pmset_log();
    asl_set(m, kPMASLDomainKey, kPMASLDomainPMAssertions);

    snprintf(strbuf, sizeof(strbuf), "Kernel %s sleep preventers: ",
             (preventerType == kIOPMIdleSleepPreventers) ? "Idle" : "System");
    if (count == 0)
    {
        strlcat(strbuf, "-None-", sizeof(strbuf));
    }

    for (int i = 0; i < count; i++)
    {
        CFStringRef cfstr = CFArrayGetValueAtIndex(preventers, i);
        CFStringGetCString(cfstr, name, sizeof(name), kCFStringEncodingUTF8);

        if (i != 0) {
            strlcat(strbuf, ", ", sizeof(strbuf));
        }
        len = strlcat(strbuf, name, sizeof(strbuf));
        if (len >= sizeof(strbuf)) break;
    }
    if (len >= sizeof(strbuf)) {
        // Put '...' to indicate incomplete string
        strbuf[sizeof(strbuf)-4] = strbuf[sizeof(strbuf)-3] = strbuf[sizeof(strbuf)-2] = '.';
        strbuf[sizeof(strbuf)-1] = '\0';
    }
    asl_set(m, ASL_KEY_MSG, strbuf);

    asl_send(NULL, m);
    asl_release(m);

    if (preventers)
    {
        CFRelease(preventers);
    }
#endif
}
/*****************************************************************************/
/*****************************************************************************/


/***************************************************************************/
/***************************************************************************/
/***************************************************************************/
/***************************************************************************/
#pragma mark MT2 DarkWake

#if TARGET_OS_EMBEDDED
/* These are stubs of MT2 functions, so we can build for embedded, without this functionality. */
void initializeMT2Aggregator(void) {};
void mt2DarkWakeEnded(void) {};
void mt2EvaluateSystemSupport(void) {};
void mt2RecordWakeEvent(uint32_t description) {};
void mt2RecordThermalEvent(uint32_t description) {};
void mt2RecordAssertionEvent(assertionOps action, assertion_t *theAssertion) {};
void mt2PublishReports(void) {};
void mt2PublishSleepFailure(const char *failType, const char *pci_string) {};
void mt2PublishWakeFailure(const char *failType, const char *pci_string) {};
void mt2RecordAppTimeouts(CFStringRef sleepReason, CFStringRef procName) {};
static void mt2PublishWakeReason(CFStringRef wakeTypeStr, CFStringRef claimedWakeStr) {};
#else

/*
 * MessageTracer2 DarkWake Keys
 */

typedef struct {
    CFAbsoluteTime              startedPeriod;
    dispatch_source_t           nextFireSource;

    /* for domain com.apple.darkwake.capable */
    int                         SMCSupport:1;
    int                         PlatformSupport:1;
    int                         checkedforAC:1;
    int                         checkedforBatt:1;
    /* for domain com.apple.darkwake.wakes */
    uint16_t                    wakeEvents[kWakeStateCount];
    /* for domain com.apple.darkwake.thermal */
    uint16_t                    thermalEvents[kThermalStateCount];
    /* for domain com.apple.darkwake.backgroundtasks */
    CFMutableSetRef             alreadyRecordedBackground;
    CFMutableDictionaryRef      tookBackground;
    /* for domain com.apple.darkwake.pushservicetasks */
    CFMutableSetRef             alreadyRecordedPush;
    CFMutableDictionaryRef      tookPush;
    /* for domain com.apple.darkwake.pushservicetasktimeout */
    CFMutableSetRef             alreadyRecordedPushTimeouts;
    CFMutableDictionaryRef      timeoutPush;
    CFMutableDictionaryRef      idleSleepAppTimeouts;
    CFMutableDictionaryRef      demandSleepAppTimeouts;
    CFMutableDictionaryRef      darkwakeSleepAppTimeouts;
} MT2Aggregator;

static const uint64_t   kMT2CheckIntervalTimer = 4ULL*60ULL*60ULL*NSEC_PER_SEC;     /* Check every 4 hours */
static CFAbsoluteTime   kMT2SendReportsAtInterval = 7.0*24.0*60.0*60.0;             /* Publish reports every 7 days */
static const uint64_t   kBigLeeway = (30Ull * NSEC_PER_SEC);

static MT2Aggregator    *mt2 = NULL;

void initializeMT2Aggregator(void)
{
    if (mt2)
    {
        /* Zero out & recycle MT2Aggregator structure */
        if (mt2->nextFireSource) {
            dispatch_release(mt2->nextFireSource);
        }
        CFRelease(mt2->alreadyRecordedBackground);
        CFRelease(mt2->tookBackground);
        CFRelease(mt2->alreadyRecordedPush);
        CFRelease(mt2->tookPush);
        CFRelease(mt2->alreadyRecordedPushTimeouts);
        CFRelease(mt2->timeoutPush);
        CFRelease(mt2->idleSleepAppTimeouts);
        CFRelease(mt2->demandSleepAppTimeouts);
        CFRelease(mt2->darkwakeSleepAppTimeouts);

        bzero(mt2, sizeof(MT2Aggregator));
    } else {
        /* New datastructure */
        mt2 = calloc(1, sizeof(MT2Aggregator));
    }
    mt2->startedPeriod                      = CFAbsoluteTimeGetCurrent();
    mt2->alreadyRecordedBackground          = CFSetCreateMutable(0, 0, &kCFTypeSetCallBacks);
    mt2->alreadyRecordedPush                = CFSetCreateMutable(0, 0, &kCFTypeSetCallBacks);
    mt2->alreadyRecordedPushTimeouts        = CFSetCreateMutable(0, 0, &kCFTypeSetCallBacks);
    mt2->tookBackground                     = CFDictionaryCreateMutable(0, 0, &kCFTypeDictionaryKeyCallBacks, NULL);
    mt2->tookPush                           = CFDictionaryCreateMutable(0, 0, &kCFTypeDictionaryKeyCallBacks, NULL);
    mt2->timeoutPush                        = CFDictionaryCreateMutable(0, 0, &kCFTypeDictionaryKeyCallBacks, NULL);
    mt2->idleSleepAppTimeouts               = CFDictionaryCreateMutable(0, 0, &kCFTypeDictionaryKeyCallBacks, NULL);
    mt2->demandSleepAppTimeouts             = CFDictionaryCreateMutable(0, 0, &kCFTypeDictionaryKeyCallBacks, NULL);
    mt2->darkwakeSleepAppTimeouts           = CFDictionaryCreateMutable(0, 0, &kCFTypeDictionaryKeyCallBacks, NULL);

    mt2->nextFireSource = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, dispatch_get_main_queue());
    if (mt2->nextFireSource) {
        dispatch_source_set_event_handler(mt2->nextFireSource, ^(){ mt2PublishReports(); });
        dispatch_source_set_timer(mt2->nextFireSource, dispatch_time(DISPATCH_TIME_NOW, kMT2CheckIntervalTimer),
                                  kMT2CheckIntervalTimer, kBigLeeway);
        dispatch_resume(mt2->nextFireSource);
    }
    mt2EvaluateSystemSupport();
    return;
}



static int mt2PublishDomainCapable(void)
{
#define kMT2DomainDarkWakeCapable       "com.apple.darkwake.capable"
#define kMT2KeySupport                  "com.apple.message.hardware_support"
#define kMT2ValNoSupport                "none"
#define kMT2ValPlatformSupport          "platform_without_smc"
#define kMT2ValSMCSupport               "smc_without_platform"
#define kMT2ValFullDWSupport            "dark_wake_supported"
#define kMT2KeySettings                 "com.apple.message.settings"
#define kMT2ValSettingsNone             "none"
#define kMT2ValSettingsAC               "ac"
#define kMT2ValSettingsBatt             "battery"
#define kMT2ValSettingsACPlusBatt       "ac_and_battery"
    if (!mt2) {
        return 0;
    }

    aslmsg m = asl_new(ASL_TYPE_MSG);
    asl_set(m, "com.apple.message.domain", kMT2DomainDarkWakeCapable );
    if (mt2->SMCSupport && mt2->PlatformSupport) {
        asl_set(m, kMT2KeySupport, kMT2ValFullDWSupport);
    } else if (mt2->PlatformSupport) {
        asl_set(m, kMT2KeySupport, kMT2ValPlatformSupport);
    } else if (mt2->SMCSupport) {
        asl_set(m, kMT2KeySupport, kMT2ValSMCSupport);
    } else {
        asl_set(m, kMT2KeySupport, kMT2ValNoSupport);
    }

    if (mt2->checkedforAC && mt2->checkedforBatt) {
        asl_set(m, kMT2KeySettings, kMT2ValSettingsACPlusBatt);
    } else if (mt2->checkedforAC) {
        asl_set(m, kMT2KeySettings, kMT2ValSettingsAC);
    } else if (mt2->checkedforBatt) {
        asl_set(m, kMT2KeySettings, kMT2ValSettingsBatt);
    } else {
        asl_set(m, kMT2KeySettings, kMT2ValSettingsNone);
    }

    asl_log(NULL, m, ASL_LEVEL_ERR, "");
    asl_release(m);

    return 1;
}


static int mt2PublishDomainWakes(void)
{
#define kMT2DomainWakes                 "com.apple.darkwake.wakes"
#define kMT2KeyWakeType                 "com.apple.message.waketype"
#define kMT2ValWakeDark                 "dark"
#define kMT2ValWakeFull                 "full"
#define kMT2KeyPowerSource              "com.apple.message.powersource"
#define kMT2ValPowerAC                  "ac"
#define kMT2ValPowerBatt                "battery"
#define kMT2KeyLid                      "com.apple.message.lid"
#define kMT2ValLidOpen                  "open"
#define kMT2ValLidClosed                "closed"

    int     sentCount = 0;
    int     i = 0;
    char    buf[kIntegerStringLen];

    if (!mt2) {
        return 0;
    }
    for (i=0; i<kWakeStateCount; i++)
    {
        if (0 == mt2->wakeEvents[i]) {
            continue;
        }
        aslmsg m = asl_new(ASL_TYPE_MSG);
        asl_set(m, "com.apple.message.domain", kMT2DomainWakes);
        if (i & kWakeStateDark) {
            asl_set(m, kMT2KeyWakeType, kMT2ValWakeDark);
        } else {
            asl_set(m, kMT2KeyWakeType, kMT2ValWakeFull);
        }
        if (i & kWakeStateBattery) {
            asl_set(m, kMT2KeyPowerSource, kMT2ValPowerBatt);
        } else {
            asl_set(m, kMT2KeyPowerSource, kMT2ValPowerAC);
        }
        if (i & kWakeStateLidClosed) {
            asl_set(m, kMT2KeyLid, kMT2ValLidClosed);
        } else {
            asl_set(m, kMT2KeyLid, kMT2ValLidOpen);
        }

        snprintf(buf, sizeof(buf), "%d", mt2->wakeEvents[i]);
        asl_set(m, "com.apple.message.count", buf);
        asl_log(NULL, m, ASL_LEVEL_ERR, "");
        asl_release(m);
        sentCount++;
    }
    return sentCount;
}

static int mt2PublishDomainThermals(void)
{
#define kMT2DomainThermal               "com.apple.darkwake.thermalevent"
#define kMT2KeySleepRequest             "com.apple.message.sleeprequest"
#define kMT2KeyFansSpin                 "com.apple.message.fansspin"
#define kMT2ValTrue                     "true"
#define kMT2ValFalse                    "false"

    int     sentCount = 0;
    int     i = 0;
    char    buf[kIntegerStringLen];

    if (!mt2) {
        return 0;
    }

    for (i=0; i<kThermalStateCount; i++)
    {
        if (0 == mt2->thermalEvents[i]) {
            continue;
        }
        aslmsg m = asl_new(ASL_TYPE_MSG);
        asl_set(m, "com.apple.message.domain", kMT2DomainThermal );
        if (i & kThermalStateSleepRequest) {
            asl_set(m, kMT2KeySleepRequest, kMT2ValTrue);
        } else {
            asl_set(m, kMT2KeySleepRequest, kMT2ValFalse);
        }
        if (i & kThermalStateFansOn) {
            asl_set(m, kMT2KeyFansSpin, kMT2ValTrue);
        } else {
            asl_set(m, kMT2KeyFansSpin, kMT2ValFalse);
        }

        snprintf(buf, sizeof(buf), "%d", mt2->thermalEvents[i]);
        asl_set(m, "com.apple.message.count", buf);
        asl_log(NULL, m, ASL_LEVEL_ERR, "");
        asl_release(m);
        sentCount++;
    }
    return sentCount;
}

static int mt2PublishDomainProcess(const char *appdomain, CFDictionaryRef apps)
{
#define kMT2KeyApp                      "com.apple.message.process"

    CFStringRef         *keys;
    uintptr_t           *counts;
    char                buf[2*kProcNameBufLen];
    int                 sendCount = 0;
    int                 appcount = 0;
    int                 i = 0;

    if (!mt2 || !apps || (0 == (appcount = CFDictionaryGetCount(apps))))
    {
        return 0;
    }

    keys = (CFStringRef *)calloc(sizeof(CFStringRef), appcount);
    counts = (uintptr_t *)calloc(sizeof(uintptr_t), appcount);

    CFDictionaryGetKeysAndValues(apps, (const void **)keys, (const void **)counts);

    for (i=0; i<appcount; i++)
    {
        if (0 == counts[i]) {
            continue;
        }
        aslmsg m = asl_new(ASL_TYPE_MSG);
        asl_set(m, "com.apple.message.domain", appdomain);

        if (!CFStringGetCString(keys[i], buf, sizeof(buf), kCFStringEncodingUTF8)) {
            snprintf(buf, sizeof(buf), "com.apple.message.%s", "Unknown");
        }
        asl_set(m, kMT2KeyApp, buf);

        snprintf(buf, sizeof(buf), "%d", (int)counts[i]);
        asl_set(m, "com.apple.message.count", buf);

        asl_log(NULL, m, ASL_LEVEL_ERR,"");
        asl_release(m);
        sendCount++;

    }

    free(keys);
    free(counts);

    return sendCount;
}

void mt2PublishReports(void)
{
#define kMT2DomainPushTasks         "com.apple.darkwake.pushservicetasks"
#define kMT2DomainPushTimeouts      "com.apple.darkwake.pushservicetimeouts"
#define kMT2DomainBackgroundTasks   "com.apple.darkwake.backgroundtasks"
#define kMT2DomainIdleSlpAckTo      "com.apple.ackto.idlesleep"    /* Idle sleep ack timeouts */
#define kMT2DomainDemandSlpAckTo    "com.apple.ackto.demandsleep"  /* Demand sleep ack timeouts */
#define kMT2DomainDarkWkSlpAckTo    "com.apple.ackto.demandsleep"  /* Dark wake sleep ack timeouts */
#define kMT2DomainclaimedWakeEvents "com.apple.wake.claimedevents"

    if (!mt2) {
        return;
    }

    if ((mt2->startedPeriod + kMT2SendReportsAtInterval) < CFAbsoluteTimeGetCurrent())
    {
        /* mt2PublishReports should only publish a new batch of ASL no more
         * frequently than once every kMT2SendReportsAtInterval seconds.
         * If it's too soon to publish ASL keys, just return.
         */
        return;
    }

    mt2PublishDomainCapable();

    if (mt2->PlatformSupport && mt2->SMCSupport)
    {
        mt2PublishDomainWakes();
        mt2PublishDomainThermals();
        mt2PublishDomainProcess(kMT2DomainPushTasks, mt2->tookPush);
        mt2PublishDomainProcess(kMT2DomainPushTimeouts, mt2->timeoutPush);
        mt2PublishDomainProcess(kMT2DomainBackgroundTasks, mt2->tookBackground);
        mt2PublishDomainProcess(kMT2DomainIdleSlpAckTo, mt2->idleSleepAppTimeouts);
        mt2PublishDomainProcess(kMT2DomainDemandSlpAckTo, mt2->demandSleepAppTimeouts);
        mt2PublishDomainProcess(kMT2DomainDarkWkSlpAckTo, mt2->darkwakeSleepAppTimeouts);

        // Recyle the data structure for the next reporting.
        initializeMT2Aggregator();
    }

    // If the system lacks (PlatformSupport && SMC Support), this is where we stop scheduling MT2 reports.
    // If the system has PowerNap support, then we'll set a periodic timer in initializeMT2Aggregator() and
    // we'll keep publish messages on a schedule.

    return;
}

void mt2DarkWakeEnded(void)
{
    if (!mt2) {
        return;
    }
    CFSetRemoveAllValues(mt2->alreadyRecordedBackground);
    CFSetRemoveAllValues(mt2->alreadyRecordedPush);
    CFSetRemoveAllValues(mt2->alreadyRecordedPushTimeouts);
}

void mt2EvaluateSystemSupport(void)
{
    CFDictionaryRef     energySettings = NULL;
    CFDictionaryRef     per = NULL;
    CFNumberRef         num = NULL;
    int                 value = 0;

    if (!mt2) {
        return;
    }

    mt2->SMCSupport = smcSilentRunningSupport() ? 1:0;
    mt2->PlatformSupport = (_platformBackgroundTaskSupport || _platformSleepServiceSupport) ? 1:0;

    mt2->checkedforAC = 0;
    mt2->checkedforBatt = 0;
    if ((energySettings = IOPMCopyActivePMPreferences())) {
        per = CFDictionaryGetValue(energySettings, CFSTR(kIOPMACPowerKey));
        if (per) {
            num = CFDictionaryGetValue(per, CFSTR(kIOPMDarkWakeBackgroundTaskKey));
            if (num) {
                CFNumberGetValue(num, kCFNumberIntType, &value);
                mt2->checkedforAC = value ? 1:0;
            }
        }
        per = CFDictionaryGetValue(energySettings, CFSTR(kIOPMBatteryPowerKey));
        if (per) {
            num = CFDictionaryGetValue(per, CFSTR(kIOPMDarkWakeBackgroundTaskKey));
            if (num) {
                CFNumberGetValue(num, kCFNumberIntType, &value);
                mt2->checkedforBatt = value ? 1:0;
            }
        }

        CFRelease(energySettings);
    }
    return;
}

void mt2RecordWakeEvent(uint32_t description)
{
    CFStringRef     lidString = NULL; 
    CFBooleanRef    lidIsClosed = NULL;

    if (!mt2) {
        return;
    }

    if (kWakeStateFull & description) {
        /* The system just woke into FullWake.
         * To make sure that we publish mt2 reports in a timely manner,
         * we'll try now. It'll only actually happen if the PublishInterval has
         * elapsed since the last time we published.
         */
        mt2PublishReports();
    }

    lidString = CFStringCreateWithCString(0, kAppleClamshellStateKey, kCFStringEncodingUTF8);
    if (lidString) {
        lidIsClosed = _copyRootDomainProperty(lidString);
        CFRelease(lidString);
    }

    description |= ((_getPowerSource() == kBatteryPowered) ? kWakeStateBattery : kWakeStateAC)
                 | ((kCFBooleanTrue == lidIsClosed) ? kWakeStateLidClosed : kWakeStateLidOpen);

    if (lidIsClosed) {
        CFRelease(lidIsClosed);
    }

    mt2->wakeEvents[description]++;
    return;
}

void mt2RecordThermalEvent(uint32_t description)
{
    if (!mt2) {
        return;
    }
    description &= (kThermalStateFansOn | kThermalStateSleepRequest);
    mt2->thermalEvents[description]++;
    return;
}

/* PMConnection.c */
bool isA_DarkWakeState();

void mt2RecordAssertionEvent(assertionOps action, assertion_t *theAssertion)
{
    CFStringRef         processName;
    CFStringRef         assertionType;

    if (!mt2) {
        return;
    }

    if (!theAssertion || !theAssertion->props || !isA_DarkWakeState()) {
        return;
    }

    if (!(processName = processInfoGetName(theAssertion->pinfo->pid))) {
        processName = CFSTR("Unknown");
    }

    if (!(assertionType = CFDictionaryGetValue(theAssertion->props, kIOPMAssertionTypeKey))
        || (!CFEqual(assertionType, kIOPMAssertionTypeBackgroundTask)
         && !CFEqual(assertionType, kIOPMAssertionTypeApplePushServiceTask)))
    {
        return;
    }

    if (CFEqual(assertionType, kIOPMAssertionTypeBackgroundTask))
    {
        if (kAssertionOpRaise == action) {
            if (!CFSetContainsValue(mt2->alreadyRecordedBackground, processName)) {
                int x = (int)CFDictionaryGetValue(mt2->tookBackground, processName);
                x++;
                CFDictionarySetValue(mt2->tookBackground, processName, (uintptr_t)x);
                CFSetAddValue(mt2->alreadyRecordedBackground, processName);
            }
        }
    }
    else if (CFEqual(assertionType, kIOPMAssertionTypeApplePushServiceTask))
    {
        if (kAssertionOpRaise == action) {
            if (!CFSetContainsValue(mt2->alreadyRecordedPush, processName)) {
                int x = (int)CFDictionaryGetValue(mt2->tookPush, processName);
                x++;
                CFDictionarySetValue(mt2->tookPush, processName, (uintptr_t)x);
                CFSetAddValue(mt2->alreadyRecordedPush, processName);
            }
        }
        else if (kAssertionOpGlobalTimeout == action) {
            if (!CFSetContainsValue(mt2->alreadyRecordedPushTimeouts, processName)) {
                int x = (int)CFDictionaryGetValue(mt2->timeoutPush, processName);
                x++;
                CFDictionarySetValue(mt2->timeoutPush, (const void *)processName, (uintptr_t)x);
                CFSetAddValue(mt2->alreadyRecordedPushTimeouts, processName);
            }
        }
    }

    return;
}

void mt2RecordAppTimeouts(CFStringRef sleepReason, CFStringRef procName)
{
    CFMutableDictionaryRef dict;

    if ( !mt2 || !isA_CFString(procName)) return;

    if (CFStringCompare(sleepReason, CFSTR(kIOPMIdleSleepKey), 0) == kCFCompareEqualTo) {
        dict = mt2->idleSleepAppTimeouts;
    }
    else  if ((CFStringCompare(sleepReason, CFSTR(kIOPMClamshellSleepKey), 0) == kCFCompareEqualTo) ||
            (CFStringCompare(sleepReason, CFSTR(kIOPMPowerButtonSleepKey), 0) == kCFCompareEqualTo) ||
            (CFStringCompare(sleepReason, CFSTR(kIOPMSoftwareSleepKey), 0) == kCFCompareEqualTo)) {
        dict = mt2->demandSleepAppTimeouts;
    }
    else {
        dict = mt2->darkwakeSleepAppTimeouts;
    }

    int x = (int)CFDictionaryGetValue(dict, procName);
    x++;
    CFDictionarySetValue(dict, (const void *)procName, (uintptr_t)x);

}


#define kMT2DomainWakeReasons       "com.apple.iokit.wakereasons"
#define kMT2DomainSleepWakeFailure  "com.apple.sleepwake.failure"
#define kMT2DomainSleepFailure      "com.apple.sleep.failure"
#define kMT2DomainWakeFailure       "com.apple.wake.failure"
#define kMT2KeyFailPhase            "com.apple.message.signature"
#define kMT2KeyPCI                  "com.apple.message.signature2"
#define kMT2KeyFailType             "com.apple.message.signature3"
#define kMT2KeySuccessCount         "com.apple.message.value"


static void mt2PublishWakeReason(CFStringRef wakeTypeStr, CFStringRef claimedWakeStr)
{
    char wakeType[64];
    char claimedWake[64];
    tcpKeepAliveStates_et state = getTCPKeepAliveState(NULL, 0);
    

    if (!isA_CFString(wakeTypeStr)
        || !CFStringGetCString(wakeTypeStr, wakeType, sizeof(wakeType), kCFStringEncodingUTF8))
    {
        return;
    }

    if (!isA_CFString(claimedWakeStr)
        || !CFStringGetCString(claimedWakeStr, claimedWake, sizeof(claimedWake), kCFStringEncodingUTF8))
    {
        return;
    }
    
    aslmsg m = asl_new(ASL_TYPE_MSG);
    asl_set(m, "com.apple.message.domain", kMT2DomainWakeReasons);

    asl_set(m, "com.apple.message.signature", wakeType);
    if (state == kNotSupported) {
        asl_set(m, "com.apple.message.signature2", "unsupported");
    }
    else if (state == kActive) {
        asl_set(m, "com.apple.message.signature2", "active");
    }
    else {
        asl_set(m, "com.apple.message.signature2", "inactive");
    }
    asl_set(m, "com.apple.message.signature3", claimedWake);

    asl_set(m, "com.apple.message.summarize", "YES");
    asl_log(NULL, m, ASL_LEVEL_NOTICE, "");
    asl_release(m);

}
void mt2PublishSleepFailure(const char *phase, const char *pci_string)
{
    aslmsg m = asl_new(ASL_TYPE_MSG);
    asl_set(m, "com.apple.message.domain", kMT2DomainSleepFailure);
    asl_set(m, kMT2KeyFailPhase, phase);
    asl_set(m, kMT2KeyPCI, pci_string);
    asl_set(m, "com.apple.message.summarize", "YES");
    asl_log(NULL, m, ASL_LEVEL_NOTICE, "");
    asl_release(m);
}

void mt2PublishWakeFailure(const char *phase, const char *pci_string)
{
    aslmsg m = asl_new(ASL_TYPE_MSG);
    asl_set(m, "com.apple.message.domain", kMT2DomainWakeFailure);
    asl_set(m, kMT2KeyFailPhase, phase);
    asl_set(m, kMT2KeyPCI, pci_string);
    asl_set(m, "com.apple.message.summarize", "YES");
    asl_log(NULL, m, ASL_LEVEL_NOTICE, "");
    asl_release(m);
}


void mt2PublishSleepWakeFailure(const char *failType, const char *phase, const char *pci_string)
{
    char buf[8];

    if (sleepCntSinceFailure == -1) {
        initSleepCnt();
    }
    aslmsg m = asl_new(ASL_TYPE_MSG);
    asl_set(m, "com.apple.message.domain", kMT2DomainSleepWakeFailure);
    asl_set(m, kMT2KeyFailType, failType);
    asl_set(m, kMT2KeyFailPhase, phase);
    asl_set(m, kMT2KeyPCI, pci_string);
    snprintf(buf, sizeof(buf), "%d", sleepCntSinceFailure);
    asl_set(m, kMT2KeySuccessCount, buf);
    asl_set(m, "com.apple.message.summarize", "NO");
    asl_log(NULL, m, ASL_LEVEL_NOTICE, "");
    asl_release(m);

    if (!strncmp(failType, kPMASLSleepFailureType, strlen(failType))) {
        mt2PublishSleepFailure(phase, pci_string);
    }
    else if (!strncmp(failType, kPMASLWakeFailureType, strlen(failType))) {
        mt2PublishWakeFailure(phase, pci_string);
    } 
}
#endif      /* #endif for iOS */

#pragma mark FDR

/*************************
  FDR functionality
 *************************/
void recordFDREvent(int eventType, bool checkStandbyStatus,  IOPMBattery **batteries)
{
#if !TARGET_OS_EMBEDDED

    struct systemstats_sleep_s s;
    struct systemstats_wake_s w;
    struct systemstats_power_state_change_s psc;
    IOPMBattery *b;
    char wt[50];
    wt[0] = 0;

    switch(eventType) {
        case kFDRInit:
            systemstats_init(SYSTEMSTATS_WRITER_powerd, NULL);
            break;

        case kFDRACChanged:
            if(!batteries)
                return;

            b = batteries[0];

            bzero(&psc, sizeof(struct systemstats_power_state_change_s));
            psc.now_on_battery = !(b->externalConnected);
            psc.is_fully_charged = isFullyCharged(b);
            systemstats_write_power_state_change(&psc);
            nextFDREventDue = (uint64_t)kFDRIntervalAfterPE + getMonotonicTime();
            break;

        case kFDRSleepEvent:
            bzero(&s, sizeof(struct systemstats_sleep_s));
            s.reason = 0;
            systemstats_write_sleep(&s);
            nextFDREventDue = (uint64_t)kFDRRegularInterval + getMonotonicTime();
            break;

        case kFDRUserWakeEvent:
        case kFDRDarkWakeEvent:

            bzero(&w, sizeof(struct systemstats_wake_s));
            if (kFDRUserWakeEvent == eventType) {
                w.reason = 1;
            } else if (kFDRDarkWakeEvent == eventType) {
                w.reason = 2;
            }

            if (checkStandbyStatus) {
                const char *sleepTypeString = getSleepTypeString();
                if(sleepTypeString &&
                    (!strncmp(sleepTypeString, "Standby", 15) ||
                     !strncmp(sleepTypeString, "AutoPowerOff", 15))) {
                    w.wake_from_standby = true;
                }
            }

            if (isA_CFString(reasons.interpretedWake)) {
                if (CFStringGetCString(reasons.interpretedWake, wt, sizeof(wt),
                    kCFStringEncodingUTF8) && wt[0]) {
                    w.wake_type = wt;
                }
            }
            
            systemstats_write_wake(&w);
            nextFDREventDue = (uint64_t)kFDRIntervalAfterPE + getMonotonicTime();
            break;

        case kFDRBattEventPeriodic:
            // If last FDR event was < X mins ago, do nothing
            if(nextFDREventDue && getMonotonicTime() <= nextFDREventDue)  {
                break;
            }

            // Fall thru
        case kFDRBattEventAsync:
            if(!batteries)
                return;

            IOPMBattery *b = batteries[0];
            struct systemstats_battery_charge_level_s binfo;
            bzero(&binfo, sizeof(struct systemstats_battery_charge_level_s));

            binfo.charge = b->currentCap;
            binfo.max_charge = b->maxCap;
            binfo.cycle_count = b->cycleCount;
            binfo.instant_amperage = b->instantAmperage;
            binfo.instant_voltage = b->voltage;
            binfo.last_minute_wattage = ((abs(b->voltage))*(abs(b->avgAmperage)))/1000;
            binfo.estimated_time_remaining = b->hwAverageTR;
            binfo.smoothed_estimated_time_remaining = b->swCalculatedTR;
            binfo.is_fully_charged = isFullyCharged(b);

            systemstats_write_battery_charge_level(&binfo);
            nextFDREventDue = (uint64_t)kFDRRegularInterval + getMonotonicTime();
            break;

        default:
            return;
    }

#endif
}

#pragma mark SMC and Hardware
/************************* One off hack for AppleSMC
 *************************
 ************************* Send AppleSMC a kCFPropertyTrue
 ************************* on time discontinuities.
 *************************/
#if !TARGET_OS_EMBEDDED

static void setSMCProperty(void)
{
    static io_registry_entry_t     _smc = MACH_PORT_NULL;

    if(MACH_PORT_NULL == _smc) {
        _smc = IOServiceGetMatchingService( MACH_PORT_NULL,
                        IOServiceMatching("AppleSMCFamily"));
    }

    if(!_smc) {
        return;
    }

    // And simply AppleSMC with kCFBooleanTrue to let them know time is changed.
    // We don't pass any information down.
    IORegistryEntrySetCFProperty( _smc,
                        CFSTR("TheTimesAreAChangin"),
                        kCFBooleanTrue);
}

static void handleMachCalendarMessage(CFMachPortRef port, void *msg,
                                            CFIndex size, void *info)
{
    kern_return_t  result;
    mach_port_t    mport = CFMachPortGetPort(port);
    mach_port_t    host_port;

    // Re-register for notification
    host_port = mach_host_self();
    result = host_request_notification(host_port, HOST_NOTIFY_CALENDAR_CHANGE, mport);
    if (host_port) {
        mach_port_deallocate(mach_task_self(), host_port);
    }
    if (result != KERN_SUCCESS) {
        return;
    }

    setSMCProperty();
}

static void registerForCalendarChangedNotification(void)
{
    mach_port_t tport;
    mach_port_t host_port;
    kern_return_t result;
    CFRunLoopSourceRef rls;
    static CFMachPortRef        calChangeReceivePort = NULL;

    // allocate the mach port we'll be listening to
    result = mach_port_allocate(mach_task_self(),MACH_PORT_RIGHT_RECEIVE, &tport);
    if (result != KERN_SUCCESS) {
        return;
    }

    calChangeReceivePort = CFMachPortCreateWithPort(
            kCFAllocatorDefault,
            tport,
            (CFMachPortCallBack)handleMachCalendarMessage,
            NULL, /* context */
            false); /* shouldFreeInfo */
    if (calChangeReceivePort) {
        rls = CFMachPortCreateRunLoopSource(
                kCFAllocatorDefault,
                calChangeReceivePort,
                0); /* index Order */
        if (rls) {
            CFRunLoopAddSource(CFRunLoopGetCurrent(), rls, kCFRunLoopDefaultMode);
            CFRelease(rls);
        }
        CFRelease(calChangeReceivePort);
    }

    // register for notification
    host_port = mach_host_self();
    host_request_notification(host_port,HOST_NOTIFY_CALENDAR_CHANGE, tport);
    if (host_port) {
        mach_port_deallocate(mach_task_self(), host_port);
    }
}
#endif

/* Returns monotonic time in secs */
__private_extern__ uint64_t getMonotonicTime( )
{
    static mach_timebase_info_data_t    timebaseInfo;

    if (timebaseInfo.denom == 0)
        mach_timebase_info(&timebaseInfo);

    return ( (mach_absolute_time( ) * timebaseInfo.numer) / (timebaseInfo.denom * NSEC_PER_SEC));
}

__private_extern__ int callerIsRoot(int uid)
{
    return (0 == uid);
}

__private_extern__ int
callerIsAdmin(
    int uid,
    int gid
)
{
    int         ngroups = NGROUPS_MAX+1;
    int         group_list[NGROUPS_MAX+1];
    int         i;
    struct group    *adminGroup;
    struct passwd   *pw;


    pw = getpwuid(uid);
    if (!pw)
        return false;

    getgrouplist(pw->pw_name, pw->pw_gid, group_list, &ngroups);

    adminGroup = getgrnam("admin");
    if (adminGroup != NULL) {
        gid_t    adminGid = adminGroup->gr_gid;
        for(i=0; i<ngroups; i++)
        {
            if (group_list[i] == adminGid) {
                return TRUE;    // if a member of group "admin"
            }
        }
    }
    return false;

}

__private_extern__ int
callerIsConsole(
    int uid,
    int gid)
{
#if TARGET_OS_EMBEDDED
    return false;
#else
    CFStringRef                 user_name = NULL;
    uid_t                       console_uid;
    gid_t                       console_gid;

    user_name = (CFStringRef)SCDynamicStoreCopyConsoleUser(NULL,
                                    &console_uid, &console_gid);

    if(user_name) {
        CFRelease(user_name);
        return ((uid == console_uid) && (gid == console_gid));
    } else {
        // no data returned re: console user's uid or gid; return "false"
        return false;
    }
#endif /* !TARGET_OS_EMBEDDED */
}


void _oneOffHacksSetup(void)
{
#if !TARGET_OS_EMBEDDED
    registerForCalendarChangedNotification();
#endif
}

static const CFTimeInterval kTimeNSPerSec = 1000000000.0;

CFTimeInterval _getHIDIdleTime(void)
{
    static io_registry_entry_t hidsys = IO_OBJECT_NULL;
    CFNumberRef     hidsys_idlenum = NULL;
    CFTimeInterval  ret_time = 0.0;
    uint64_t        idle_nanos = 0;

    if (IO_OBJECT_NULL == hidsys) {
        hidsys = IOServiceGetMatchingService(kIOMasterPortDefault, IOServiceMatching("IOHIDSystem"));
    }
    if (!hidsys)
        goto exit;

    hidsys_idlenum = IORegistryEntryCreateCFProperty(hidsys, CFSTR(kIOHIDIdleTimeKey), 0, 0);

    if (!isA_CFNumber(hidsys_idlenum))
        goto exit;

    if (CFNumberGetValue(hidsys_idlenum, kCFNumberSInt64Type, &idle_nanos))
    {
        ret_time = ((CFTimeInterval)idle_nanos)/kTimeNSPerSec;
    }

exit:
    if (hidsys_idlenum)
        CFRelease(hidsys_idlenum);
    return ret_time;
}

/************************************************************************/
/************************************************************************/
/************************************************************************/
/************************************************************************/
/************************************************************************/

// Code to read AppleSMC

/************************************************************************/
/************************************************************************/
/************************************************************************/
/************************************************************************/
/************************************************************************/
// Forwards
#if !TARGET_OS_EMBEDDED
static IOReturn _smcWriteKey(
    uint32_t key,
    uint8_t *outBuf,
    uint8_t outBufMax);
static IOReturn _smcReadKey(
    uint32_t key,
    uint8_t *outBuf,
    uint8_t *outBufMax,
    bool byteSwap);

#endif

/* Legacy format */

#define kACCRCBit               56  // size 8
#define kACIDBit                44  // size 12
#define kACPowerBit             36  // size 8
#define kACRevisionBit          32  // size 4
#define kACSerialBit            8   // size 24
#define kACFamilyBit            0   // size 8

/* New format (intro'd in Jan 2012) */

//#define kACCRCBit             56   // 8 bits, same as in legacy
#define kACCurrentIdBit         48   // 8 bits
//#define kACCommEnableBit      45   // 1 bit; doesn't contain meaningful information
#define kACSourceIdBit          44   // 3 bits
//#define kACPowerBit           36   // 8 bits, same as in legacy
#define kACVoltageIDBit         33   // 3 bits
//#define kACSerialBit          8    // 25 bits
//#define kACFamilyBit          0    // 8 bits, same as in legacy

#define k3BitMask       0x7



#if !TARGET_OS_EMBEDDED
static void stuffInt32(CFMutableDictionaryRef d, CFStringRef k, uint32_t n)
{
    CFNumberRef stuffNum = NULL;
    if ((stuffNum = CFNumberCreate(0, kCFNumberSInt32Type, &n)))
    {
        CFDictionarySetValue(d, k, stuffNum);
        CFRelease(stuffNum);
    }
}

static void stuffString(CFMutableDictionaryRef d, CFStringRef k, char *str)
{
    CFStringRef  strRef = NULL;

    if ((strRef = CFStringCreateWithCString(0, str, kCFStringEncodingUTF8))) {
        CFDictionarySetValue(d, k, strRef);
        CFRelease(strRef);
    }

}

static IOReturn  populateAcidData(uint64_t acBits, CFMutableDictionaryRef acDict)
{
    int                             j = 0;

    struct AdapterAttributes{
        uint32_t        valCommEn;
        uint32_t        valVoltageID;
        uint32_t        valID;
        uint32_t        valPower;
        uint32_t        valRevision;
        uint32_t        valSerial;
        uint32_t        valFamily;
        uint32_t        valCurrent;
        uint32_t        valSource;
    } info;


    // Decode SMC key
    info.valID              = (acBits >> kACIDBit) & 0xFFF;
    info.valFamily          = (acBits >> kACFamilyBit) & 0xFF;
    info.valPower           = (acBits >> kACPowerBit) & 0xFF;
    if ( (info.valSource    = (acBits >> kACSourceIdBit) & k3BitMask))
    {
        // New format
        info.valSerial      = (acBits >> kACSerialBit) & 0x1FFFFFF;
        info.valCurrent     = ((acBits >> kACCurrentIdBit) & 0xFF) * 25;
        info.valVoltageID   = (acBits >> kACVoltageIDBit) & k3BitMask;
    } else {
        // Legacy format
        info.valSerial      = (acBits >> kACSerialBit) & 0xFFFFFF;
        info.valRevision    = (acBits >> kACRevisionBit) & 0xF;
    }

    // Publish values in dictionary

    if (info.valSource) {
        // New format
        stuffInt32(acDict, CFSTR(kIOPSPowerAdapterCurrentKey), info.valCurrent);
        stuffInt32(acDict, CFSTR(kIOPSPowerAdapterSourceKey), info.valSource);

    }
    else {
        // Legacy format
        stuffInt32(acDict, CFSTR(kIOPSPowerAdapterRevisionKey), info.valRevision);
    }

    if (0 != info.valPower) {
        stuffInt32(acDict, CFSTR(kIOPSPowerAdapterWattsKey), info.valPower);
    }

    stuffInt32(acDict, CFSTR(kIOPSPowerAdapterIDKey), info.valID);
    stuffInt32(acDict, CFSTR(kIOPSPowerAdapterSerialNumberKey), info.valSerial);
    stuffInt32(acDict, CFSTR(kIOPSPowerAdapterFamilyKey), info.valFamily);

    return kIOReturnSuccess;
}

#endif


/************************************************************************/
__private_extern__ CFDictionaryRef _copyACAdapterInfo(CFDictionaryRef oldACDict)
{
#if !TARGET_OS_EMBEDDED
    IOReturn ret;
    static bool supportsACID = false;


    uint64_t acBits;
    uint8_t readKeyLen;
    CFMutableDictionaryRef          acDict = NULL;

    if (supportsACID && oldACDict) {
        /* No need to re-read the data on ACID supported systems */
        return NULL;
    }

    readKeyLen = sizeof(acBits);
    ret =  _smcReadKey('ACID', (void *)&acBits, &readKeyLen, false);
    if (ret == kIOReturnSuccess) {
        supportsACID = true;
        acDict = CFDictionaryCreateMutable(kCFAllocatorDefault, 0,
                &kCFTypeDictionaryKeyCallBacks, &kCFTypeDictionaryValueCallBacks);
        if (!acDict) {
            return NULL;
        }
        populateAcidData(acBits, acDict);
    }
    else if (ret == kIOReturnNotFound) {
        supportsACID = false;

        bool readFromSMC = false;
        int32_t current, nominalV, minV, maxV, watts;
        char  str[33];

        current = nominalV = minV =  maxV = watts = 0;
        readKeyLen = sizeof(current);
        ret = _smcReadKey('D0IR', (void *)&current, &readKeyLen, true);
        if ((ret != kIOReturnSuccess) || (current == 0)) {

            asl_log(0,0,ASL_LEVEL_ERR, "Failed to read current rating(0x%x)\n", ret);
            return NULL;
        }
        _smcReadKey('D0VR', (void *)&nominalV, &readKeyLen, true);
        if ((ret != kIOReturnSuccess) || (nominalV == 0)) {

            asl_log(0,0,ASL_LEVEL_ERR, "Failed to read nominal Voltage rating(0x%x)\n", ret);
            return NULL;
        }

        do {
            int32_t prevCurrent, prevNominalV;
            CFNumberRef prevCurrentRef = NULL;
            CFNumberRef prevNominalVRef = NULL;

            if (!isA_CFDictionary(oldACDict)) {
                readFromSMC = true;
                break;
            }


            prevCurrentRef = CFDictionaryGetValue(oldACDict, CFSTR(kIOPSPowerAdapterCurrentKey));
            if ((!isA_CFNumber(prevCurrentRef)) ||
                (!CFNumberGetValue(prevCurrentRef, kCFNumberIntType, &prevCurrent)) ||
                 (current != prevCurrent)
               ) {
                readFromSMC = true;
                break;
            }

            prevNominalVRef = CFDictionaryGetValue(oldACDict, CFSTR(kIOPSVoltageKey));
            if ((!isA_CFNumber(prevCurrentRef)) ||
                (!CFNumberGetValue(prevNominalVRef, kCFNumberIntType, &prevNominalV)) ||
                 (nominalV != prevNominalV)
               ) {
                readFromSMC = true;
                break;
            }

            if (
                (!CFDictionaryContainsKey(oldACDict, CFSTR(kIOPSPowerAdapterSerialStringKey))) ||
                (!CFDictionaryContainsKey(oldACDict, CFSTR(kIOPSPowerAdapterIDKey))) ||
                (!CFDictionaryContainsKey(oldACDict, CFSTR(kIOPSPowerAdapterManufacturerIDKey))) ||
                (!CFDictionaryContainsKey(oldACDict, CFSTR(kIOPSPowerAdapterFirmwareVersionKey))) ||
                (!CFDictionaryContainsKey(oldACDict, CFSTR(kIOPSPowerAdapterHardwareVersionKey))) ||
                (!CFDictionaryContainsKey(oldACDict, CFSTR(kIOPSPowerAdapterNameKey)))
               ) {
                readFromSMC = true;
                break;
            }

        } while (0);

        if (!readFromSMC) 
            return NULL;

        acDict = CFDictionaryCreateMutable(kCFAllocatorDefault, 0,
                &kCFTypeDictionaryKeyCallBacks, &kCFTypeDictionaryValueCallBacks);
        if (!acDict) {
            return NULL;
        }
        stuffInt32(acDict, CFSTR(kIOPSPowerAdapterCurrentKey), current);

        _smcReadKey('D0VM', (void *)&minV, &readKeyLen, true);
        _smcReadKey('D0VX', (void *)&maxV, &readKeyLen, true);
        if ((nominalV == minV) && (maxV != 0)) {
            watts = (current * maxV)/(1000*1000);
            stuffInt32(acDict, CFSTR(kIOPSVoltageKey), maxV);
        }
        else if (nominalV != 0) {
            watts = (current * nominalV)/(1000*1000);
            stuffInt32(acDict, CFSTR(kIOPSVoltageKey), nominalV);
        }

        if (watts) {
            stuffInt32(acDict, CFSTR(kIOPSPowerAdapterWattsKey), watts);
        }


        readKeyLen = sizeof(str);
        bzero(str, sizeof(str));
        ret = _smcReadKey('D0is', (void *)&str, &readKeyLen, false);
        if ((ret == kIOReturnSuccess) && (str[0] != 0))  {
            stuffString(acDict, CFSTR(kIOPSPowerAdapterSerialStringKey), str);
        }

        readKeyLen = sizeof(str);
        bzero(str, sizeof(str));
        ret = _smcReadKey('D0if', (void *)&str, &readKeyLen, false);
        if ((ret == kIOReturnSuccess) && (str[0] != 0)) {
            stuffString(acDict, CFSTR(kIOPSPowerAdapterFirmwareVersionKey), str);
        }

        readKeyLen = sizeof(str);
        bzero(str, sizeof(str));
        ret = _smcReadKey('D0ih', (void *)&str, &readKeyLen, false);
        if ((ret == kIOReturnSuccess) && (str[0] != 0)) {
            stuffString(acDict, CFSTR(kIOPSPowerAdapterHardwareVersionKey), str);
        }

        readKeyLen = sizeof(str);
        bzero(str, sizeof(str));
        ret = _smcReadKey('D0ii', (void *)&str, &readKeyLen, false);
        if ((ret == kIOReturnSuccess) && (str[0] != 0)) {
            uint32_t id = 0;
            id = strtol(str, 0, 0);
            if (id != 0) {
                stuffInt32(acDict, CFSTR(kIOPSPowerAdapterIDKey), id);
            }

        }

        readKeyLen = sizeof(str);
        bzero(str, sizeof(str));
        ret = _smcReadKey('D0im', (void *)&str, &readKeyLen, false);
        if ((ret == kIOReturnSuccess) && (str[0] != 0)) {
            stuffString(acDict, CFSTR(kIOPSPowerAdapterManufacturerIDKey), str);
        }

        readKeyLen = sizeof(str);
        bzero(str, sizeof(str));
        ret = _smcReadKey('D0in', (void *)&str, &readKeyLen, false);
        if ((ret == kIOReturnSuccess) && (str[0] != 0)) {
            stuffString(acDict, CFSTR(kIOPSPowerAdapterNameKey), str);
        }

    }
    return acDict;

#else
    return NULL;
#endif
}
/************************************************************************/
__private_extern__ PowerSources _getPowerSource(void)
{
#if !TARGET_OS_EMBEDDED
   IOPMBattery      **batteries;

   if (_batteryCount() && (batteries = _batteries())
            && (!batteries[0]->externalConnected) )
      return kBatteryPowered;
   else
      return kACPowered;
#else
    return kBatteryPowered;
#endif
}


#if !TARGET_OS_EMBEDDED
/************************************************************************/
__private_extern__ IOReturn _smcWakeTimerPrimer(void)
{
    uint8_t  buf[2];

    buf[0] = 0;
    buf[1] = 1;
    return _smcWriteKey('CLWK', buf, 2);
}

/************************************************************************/
__private_extern__ IOReturn _smcWakeTimerGetResults(uint16_t *mSec)
{
    uint8_t     size = 2;
    uint8_t     buf[2];
    IOReturn    ret;
    ret = _smcReadKey('CLWK', buf, &size, true);

    if (kIOReturnSuccess == ret) {
        *mSec = buf[0] | (buf[1] << 8);
    }

    return ret;
}

bool smcSilentRunningSupport(void)
{
    uint8_t     size = 1;
    uint8_t     buf[1];
    static IOReturn    ret = kIOReturnInvalid;

    if (ret != kIOReturnSuccess) {
       ret = _smcReadKey('WKTP', buf, &size, true);
    }

    if (kIOReturnSuccess == ret) {
        return true;
    }
    return false;
}



/************************************************************************/
/************************************************************************/

static IOReturn callSMCFunction(
    int which,
    SMCParamStruct *inputValues,
    SMCParamStruct *outputValues);

/************************************************************************/
// Methods
static IOReturn _smcWriteKey(
    uint32_t key,
    uint8_t *outBuf,
    uint8_t outBufMax)
{
    SMCParamStruct  stuffMeIn;
    SMCParamStruct  stuffMeOut;
    IOReturn        ret;
    int             i;

    if (key == 0)
        return kIOReturnCannotWire;

    bzero(&stuffMeIn, sizeof(SMCParamStruct));
    bzero(&stuffMeOut, sizeof(SMCParamStruct));

    // Determine key's data size
    stuffMeIn.data8             = kSMCGetKeyInfo;
    stuffMeIn.key               = key;

    ret = callSMCFunction(kSMCHandleYPCEvent, &stuffMeIn, &stuffMeOut);
    if (kIOReturnSuccess != ret) {
        goto exit;
    }

    if (stuffMeOut.result == kSMCKeyNotFound) {
        ret = kIOReturnNotFound;
        goto exit;
    } else if (stuffMeOut.result != kSMCSuccess) {
        ret = kIOReturnInternalError;
        goto exit;
    }

    // Write Key
    stuffMeIn.data8             = kSMCWriteKey;
    stuffMeIn.key               = key;
    stuffMeIn.keyInfo.dataSize  = stuffMeOut.keyInfo.dataSize;
    if (outBuf) {
        if (outBufMax > 32) outBufMax = 32;
        for (i=0; i<outBufMax; i++) {
            stuffMeIn.bytes[i] = outBuf[i];
        }
    }
    bzero(&stuffMeOut, sizeof(SMCParamStruct));
    ret = callSMCFunction(kSMCHandleYPCEvent, &stuffMeIn, &stuffMeOut);

    if (stuffMeOut.result != kSMCSuccess) {
        ret = kIOReturnInternalError;
        goto exit;
    }

exit:
    return ret;
}

static IOReturn _smcReadKey(
    uint32_t key,
    uint8_t *outBuf,
    uint8_t *outBufMax, 
    bool byteSwap)
{
    SMCParamStruct  stuffMeIn;
    SMCParamStruct  stuffMeOut;
    IOReturn        ret;
    int             i;

    if (key == 0 || outBuf == NULL)
        return kIOReturnCannotWire;

    // Determine key's data size
    bzero(outBuf, *outBufMax);
    bzero(&stuffMeIn, sizeof(SMCParamStruct));
    bzero(&stuffMeOut, sizeof(SMCParamStruct));
    stuffMeIn.data8 = kSMCGetKeyInfo;
    stuffMeIn.key = key;

    ret = callSMCFunction(kSMCHandleYPCEvent, &stuffMeIn, &stuffMeOut);
    if (kIOReturnSuccess != ret) {
        goto exit;
    }

    if (stuffMeOut.result == kSMCKeyNotFound) {
        ret = kIOReturnNotFound;
        goto exit;
    } else if (stuffMeOut.result != kSMCSuccess) {
        ret = kIOReturnInternalError;
        goto exit;
    }

    // Get Key Value
    stuffMeIn.data8 = kSMCReadKey;
    stuffMeIn.key = key;
    stuffMeIn.keyInfo.dataSize = stuffMeOut.keyInfo.dataSize;
    bzero(&stuffMeOut, sizeof(SMCParamStruct));
    ret = callSMCFunction(kSMCHandleYPCEvent, &stuffMeIn, &stuffMeOut);
    if (stuffMeOut.result == kSMCKeyNotFound) {
        ret = kIOReturnNotFound;
        goto exit;
    } else if (stuffMeOut.result != kSMCSuccess) {
        ret = kIOReturnInternalError;
        goto exit;
    }

    if (*outBufMax > stuffMeIn.keyInfo.dataSize)
        *outBufMax = stuffMeIn.keyInfo.dataSize;

    // Byte-swap data returning from the SMC.
    // The data at key 'ACID' are not provided by the SMC and do
    // NOT need to be byte-swapped.
    for (i=0; i<*outBufMax; i++)
    {
        if (!byteSwap)
        {
            // Do not byte swap
            outBuf[i] = stuffMeOut.bytes[i];
        } else {
            // Byte swap
            outBuf[i] = stuffMeOut.bytes[*outBufMax - (i + 1)];
        }
    }
exit:
    return ret;
}

static IOReturn callSMCFunction(
    int which,
    SMCParamStruct *inputValues,
    SMCParamStruct *outputValues)
{
    IOReturn result = kIOReturnError;

    size_t         inStructSize = sizeof(SMCParamStruct);
    size_t         outStructSize = sizeof(SMCParamStruct);

    io_connect_t    _SMCConnect = IO_OBJECT_NULL;
    io_service_t    smc = IO_OBJECT_NULL;

    smc = IOServiceGetMatchingService(
        kIOMasterPortDefault,
        IOServiceMatching("AppleSMC"));
    if (IO_OBJECT_NULL == smc) {
        return kIOReturnNotFound;
    }

    result = IOServiceOpen(smc, mach_task_self(), 1, &_SMCConnect);
    if (result != kIOReturnSuccess ||
        IO_OBJECT_NULL == _SMCConnect) {
        _SMCConnect = IO_OBJECT_NULL;
        goto exit;
    }

    result = IOConnectCallMethod(_SMCConnect, kSMCUserClientOpen,
                    NULL, 0, NULL, 0, NULL, NULL, NULL, NULL);
    if (result != kIOReturnSuccess) {
        goto exit;
    }

    result = IOConnectCallStructMethod(_SMCConnect, which,
                        inputValues, inStructSize,
                        outputValues, &outStructSize);

exit:
    if (IO_OBJECT_NULL != _SMCConnect) {
        IOConnectCallMethod(_SMCConnect, kSMCUserClientClose,
                    NULL, 0, NULL, 0, NULL, NULL, NULL, NULL);
        IOServiceClose(_SMCConnect);
    }

    return result;
}

#else
bool smcSilentRunningSupport(void)
{
   return false;
}
#endif /* TARGET_OS_EMBEDDED */

/*****************************************************************************/
/*****************************************************************************/

__private_extern__ IOReturn getNvramArgInt(char *key, int *value)
{
    io_registry_entry_t optionsRef;
    IOReturn ret = kIOReturnError;
    CFDataRef   dataRef = NULL;
    int *dataPtr = NULL;
    kern_return_t       kr;
    CFMutableDictionaryRef dict = NULL;
    CFStringRef keyRef = NULL;


    optionsRef = IORegistryEntryFromPath(kIOMasterPortDefault, "IODeviceTree:/options");
    if (optionsRef == 0)
        return kIOReturnError;

    kr = IORegistryEntryCreateCFProperties(optionsRef, &dict, 0, 0);
    if (kr != KERN_SUCCESS)
        goto exit;

    keyRef = CFStringCreateWithCStringNoCopy(0, key, kCFStringEncodingUTF8, kCFAllocatorNull);
    if (!isA_CFString(keyRef))
        goto exit;
    dataRef = CFDictionaryGetValue(dict, keyRef);

    if (!dataRef)
        goto exit;

    dataPtr = (int*)CFDataGetBytePtr(dataRef);
    *value = *dataPtr;

    ret = kIOReturnSuccess;

exit:
    if (keyRef) CFRelease(keyRef);
    if (dict) CFRelease(dict);
    IOObjectRelease(optionsRef);
    return ret;
}

__private_extern__ IOReturn getNvramArgStr(char *key, char *buf, size_t bufSize)
{
    io_registry_entry_t optionsRef;
    IOReturn ret = kIOReturnError;
    CFStringRef   dataRef = NULL;
    kern_return_t       kr;
    CFMutableDictionaryRef dict = NULL;
    CFStringRef keyRef = NULL;


    optionsRef = IORegistryEntryFromPath(kIOMasterPortDefault, "IODeviceTree:/options");
    if (optionsRef == 0)
        return kIOReturnError;

    kr = IORegistryEntryCreateCFProperties(optionsRef, &dict, 0, 0);
    if (kr != KERN_SUCCESS)
        goto exit;

    keyRef = CFStringCreateWithCStringNoCopy(0, key, kCFStringEncodingUTF8, kCFAllocatorNull);
    if (!isA_CFString(keyRef))
        goto exit;
    dataRef = CFDictionaryGetValue(dict, keyRef);

    if (!isA_CFString(dataRef))
        goto exit;

    if (CFStringGetCString(dataRef, buf, bufSize, kCFStringEncodingUTF8)) {
        ret = kIOReturnSuccess;
    }
    else {
        ret = kIOReturnNoSpace;
    }


exit:
    if (keyRef) CFRelease(keyRef);
    if (dict) CFRelease(dict);
    IOObjectRelease(optionsRef);
    return ret;
}
