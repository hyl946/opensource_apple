//
//  UtilPrettyPrinting.h
//  CPPUtil
//
//  Created by James McIlree on 9/8/13.
//  Copyright (c) 2013 Apple. All rights reserved.
//

#ifndef __CPPUtil__UtilPrettyPrinting__
#define __CPPUtil__UtilPrettyPrinting__

std::string formated_byte_size(uint64_t bytes);

#endif /* defined(__CPPUtil__UtilPrettyPrinting__) */
