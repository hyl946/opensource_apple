//
//  UtilNanoInterval.h
//  CPPUtil
//
//  Created by James McIlree on 4/14/13.
//  Copyright (c) 2013 Apple. All rights reserved.
//

#ifndef __CPPUtil__UtilNanoInterval__
#define __CPPUtil__UtilNanoInterval__

typedef TRange<NanoTime> NanoInterval;

#endif /* defined(__CPPUtil__UtilNanoInterval__) */
