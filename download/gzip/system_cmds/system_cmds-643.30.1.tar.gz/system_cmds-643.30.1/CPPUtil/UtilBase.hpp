//
//  UtilBase.hpp
//  CPPUtil
//
//  Created by James McIlree on 4/7/13.
//  Copyright (c) 2013 Apple. All rights reserved.
//

#ifndef CPPUtil_UtilBase_hpp
#define CPPUtil_UtilBase_hpp

#define BEGIN_UTIL_NAMESPACE namespace util {
#define END_UTIL_NAMESPACE }

#endif
