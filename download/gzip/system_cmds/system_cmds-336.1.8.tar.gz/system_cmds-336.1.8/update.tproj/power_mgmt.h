int on_battery_power( void );
int is_disk_awake( void );