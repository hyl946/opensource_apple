/*cc -o /tmp/blowedid blowedid.c -framework IOKit -framework ApplicationServices -Wall -g -arch i386
*/

