/*
 * Copyright (c) 1998-2000 Apple Computer, Inc. All rights reserved.
 *
 * @APPLE_LICENSE_HEADER_START@
 * 
 * The contents of this file constitute Original Code as defined in and
 * are subject to the Apple Public Source License Version 1.1 (the
 * "License").  You may not use this file except in compliance with the
 * License.  Please obtain a copy of the License at
 * http://www.apple.com/publicsource and read it before using this file.
 * 
 * This Original Code and all software distributed under the License are
 * distributed on an "AS IS" basis, WITHOUT WARRANTY OF ANY KIND, EITHER
 * EXPRESS OR IMPLIED, AND APPLE HEREBY DISCLAIMS ALL SUCH WARRANTIES,
 * INCLUDING WITHOUT LIMITATION, ANY WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT.  Please see the
 * License for the specific language governing rights and limitations
 * under the License.
 * 
 * @APPLE_LICENSE_HEADER_END@
 */


#include <sys/kdebug.h>
#include <sys/proc.h>

#include <IOKit/assert.h>
#include <IOKit/IOLib.h>
#include <IOKit/IOKitKeys.h>
#include <IOKit/IOPlatformExpert.h>
#include <IOKit/pwr_mgt/RootDomain.h>
#include <IOKit/IOTimerEventSource.h>
#include <IOKit/IOUserClient.h>
#include <IOKit/IOHibernatePrivate.h>

#include <IOKit/graphics/IOGraphicsPrivate.h>
#include <IOKit/graphics/IOGraphicsTypesPrivate.h>

#include "IODisplayWrangler.h"

#include "IOGraphicsKTrace.h"

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

enum {
    kIODisplayWranglerNumPowerStates = kIODisplayNumPowerStates + 1,
    kIODisplayWranglerMaxPowerState = kIODisplayWranglerNumPowerStates - 1,
};

enum
{ 
	// seconds
	kDimInterval          = 15,
	kAnnoyanceWithin      = 20,
	kMaxAnnoyanceInterval = 10 * 60,
};

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

#undef super
#define super IOService

OSDefineMetaClassAndStructors(IODisplayConnect, IOService)

bool IODisplayConnect::initWithConnection( IOIndex _connection )
{
    IODC_START(initWithConnection,0,0,0);
    char        name[ 12 ];

    if (!super::init())
    {
        IODC_END(initWithConnection,false,0,0);
        return (false);
    }

    connection = _connection;

    snprintf( name, sizeof(name), "display%d", (int)connection);

    setName( name);

    IODC_END(initWithConnection,true,0,0);
    return (true);
}

IOFramebuffer * IODisplayConnect::getFramebuffer( void )
{
    IODC_START(initWithConnection,0,0,0);
    IOFramebuffer * fb = (IOFramebuffer *) getProvider();
    IODC_END(initWithConnection,0,0,0);
    return (fb);
}

IOIndex IODisplayConnect::getConnection( void )
{
    IODC_START(initWithConnection,0,0,0);
    IODC_END(initWithConnection,0,0,0);
    return (connection);
}

IOReturn IODisplayConnect::getAttributeForConnection( IOSelect selector, uintptr_t * value )
{
    IODC_START(initWithConnection,selector,0,0);
    if (!getProvider())
    {
        IODC_END(initWithConnection,kIOReturnNotReady,0,0);
        return (kIOReturnNotReady);
    }

    FB_START(getAttributeForConnection,selector,__LINE__,0);
    IOReturn err = ((IOFramebuffer *) getProvider())->getAttributeForConnection(connection, selector, value);
    FB_END(getAttributeForConnection,err,__LINE__,0);
    IODC_END(initWithConnection,err,0,0);
    return (err);
}

IOReturn  IODisplayConnect::setAttributeForConnection( IOSelect selector, uintptr_t value )
{
    IODC_START(initWithConnection,selector,value,0);
    if (!getProvider())
    {
        IODC_END(initWithConnection,kIOReturnNotReady,0,0);
        return (kIOReturnNotReady);
    }
    FB_START(setAttributeForConnection,selector,__LINE__,value);
    IOReturn err = ((IOFramebuffer *) getProvider())->setAttributeForConnection(connection,  selector, value);
    FB_END(setAttributeForConnection,err,__LINE__,0);
    IODC_END(initWithConnection,err,0,0);
    return (err);
}

// joinPMtree
//
// The policy-maker in the display driver calls here when initializing.
// We attach it into the power management hierarchy as a child of our
// frame buffer.

void IODisplayConnect::joinPMtree ( IOService * driver )
{
    IODC_START(initWithConnection,0,0,0);
    getProvider()->addPowerChild(driver);
    IODC_END(initWithConnection,0,0,0);
}

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

#define super IOService
OSDefineMetaClassAndStructors(IODisplayWrangler, IOService);

IODisplayWrangler *     gIODisplayWrangler;

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

bool IODisplayWrangler::serverStart(void)
{
    IODW_START(serverStart,0,0,0);
    mach_timespec_t timeout = { 120, 0 };

    if (!gIODisplayWrangler)
        waitForService(serviceMatching("IODisplayWrangler"), &timeout);

    if (!gIODisplayWrangler) IOLog("IODisplayWrangler not started, IOResources hung\n");
    else
    {
        gIODisplayWrangler->fOpen = true;
        if (gIODisplayWrangler->fMinutesToDim) gIODisplayWrangler->setIdleTimerPeriod(60);
        gIODisplayWrangler->activityTickle(0, 0);
    }

    IODW_END(serverStart,gIODisplayWrangler != 0,0,0);
    return (gIODisplayWrangler != 0);
}

bool IODisplayWrangler::start( IOService * provider )
{
    IODW_START(start,0,0,0);

    if (!super::start(provider))
    {
        IODW_END(start,false,0,0);
        return (false);
    }

    assert( gIODisplayWrangler == 0 );

    setProperty(kIOUserClientClassKey, "IOAccelerationUserClient");

	clock_interval_to_absolutetime_interval(kDimInterval, kSecondScale, &fDimInterval);

    gIODisplayWrangler = this;

    // initialize power managment
    gIODisplayWrangler->initForPM();
    getPMRootDomain()->publishFeature("AdaptiveDimming");

    IODW_END(start,true,0,0);
    return (true);
}

bool IODisplayWrangler::makeDisplayConnects( IOFramebuffer * fb )
{
    IODW_START(makeDisplayConnects,0,0,0);
    IODisplayConnect *  connect;
    IOItemCount         i;

    for (i = 0; i < 1 /*fb->getConnectionCount()*/; i++)
    {
        connect = new IODisplayConnect;
        if (0 == connect)
            continue;

        if ((connect->initWithConnection(i))
                && (connect->attach(fb)))
        {
            connect->registerService( kIOServiceSynchronous );
        }
        connect->release();
    }

    IODW_END(makeDisplayConnects,true,0,0);
    return (true);
}

void IODisplayWrangler::destroyDisplayConnects( IOFramebuffer * fb )
{
    IODW_START(destroyDisplayConnects,0,0,0);
    OSIterator *        iter;
    OSObject *          next;
    IODisplayConnect *  connect;
    IODisplay *         display;

    fb->removeProperty(kIOFBBuiltInKey);

    iter = fb->getClientIterator();
    if (iter)
    {
        while ((next = iter->getNextObject()))
        {
            if ((connect = OSDynamicCast(IODisplayConnect, next)))
            {
                if (connect->isInactive())
                    continue;
                display = OSDynamicCast( IODisplay, connect->getClient());
                if (display)
                {
                    display->PMstop();
                }
                connect->terminate( kIOServiceSynchronous );
            }
        }
        iter->release();
    }
    IODW_END(destroyDisplayConnects,0,0,0);
}

void IODisplayWrangler::activityChange( IOFramebuffer * fb )
{
    IODW_START(activityChange,0,0,0);
    DEBG1("W", " activityChange\n");
    gIODisplayWrangler->activityTickle(0,0);
    IODW_END(activityChange,0,0,0);
}

IODisplayConnect * IODisplayWrangler::getDisplayConnect(
    IOFramebuffer * fb, IOIndex connect )
{
    IODW_START(getDisplayConnect,connect,0,0);
    OSIterator  *       iter;
    OSObject    *       next;
    IODisplayConnect *  connection = 0;

    iter = fb->getClientIterator();
    if (iter)
    {
        while ((next = iter->getNextObject()))
        {
            connection = OSDynamicCast( IODisplayConnect, next);
            if (connection)
            {
                if (connection->isInactive())
                    continue;
                if (0 == (connect--))
                    break;
            }
        }
        iter->release();
    }
    IODW_END(getDisplayConnect,0,0,0);
    return (connection);
}

IOReturn IODisplayWrangler::getConnectFlagsForDisplayMode(
    IODisplayConnect * connect,
    IODisplayModeID mode, UInt32 * flags )
{
    IODW_START(getConnectFlagsForDisplayMode,mode,0,0);
    IOReturn            err = kIOReturnUnsupported;
    IODisplay *         display;

    display = OSDynamicCast( IODisplay, connect->getClient());
    if (display)
        err = display->getConnectFlagsForDisplayMode( mode, flags );
    else
    {
        FB_START(connectFlags,mode,__LINE__,0);
        err = connect->getFramebuffer()->connectFlags(
                  connect->getConnection(), mode, flags );
        FB_END(connectFlags,err,__LINE__,*flags);
    }

    IODW_END(getConnectFlagsForDisplayMode,err,0,0);
    return (err);
}

IOReturn IODisplayWrangler::getFlagsForDisplayMode(
    IOFramebuffer * fb,
    IODisplayModeID mode, UInt32 * flags )
{
    IODW_START(getFlagsForDisplayMode,mode,0,0);
    IOReturn            err;
    IODisplayConnect    * connect;

    do {
    // should look at all connections
    connect = gIODisplayWrangler->getDisplayConnect( fb, 0 );
    if (!connect)
    {
        FB_START(connectFlags,mode,__LINE__,0);
        err = (fb->connectFlags(0, mode, flags));
        FB_END(connectFlags,err,__LINE__,*flags);
        break;
    }

    err = (gIODisplayWrangler->
            getConnectFlagsForDisplayMode(connect, mode, flags));
    } while(0);

    IODW_END(getFlagsForDisplayMode,err,0,0);
    return (err);
}

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

static IOPMPowerState ourPowerStates[kIODisplayWranglerNumPowerStates] = {
            // version,
            //   capabilityFlags, outputPowerCharacter, inputPowerRequirement,
            { 1, 0,                                      0, 0,           0,0,0,0,0,0,0,0 },
            { 1, 0,                                      0, IOPMPowerOn, 0,0,0,0,0,0,0,0 },
            { 1, 0,                                      0, IOPMPowerOn, 0,0,0,0,0,0,0,0 },
            { 1, IOPMDeviceUsable | kIOPMPreventIdleSleep, 0, IOPMPowerOn, 0,0,0,0,0,0,0,0 },
            { 1, IOPMDeviceUsable | kIOPMPreventIdleSleep, 0, IOPMPowerOn, 0,0,0,0,0,0,0,0 }
            // staticPower, unbudgetedPower, powerToAttain, timeToAttain, settleUpTime,
            // timeToLower, settleDownTime, powerDomainBudget
        };


/*
    This is the Power Management policy-maker for the displays.  It senses when
    the display is idle and lowers power accordingly.  It raises power back up
    when the display becomes un-idle.
 
    It senses idleness with a combination of an idle timer and the "activityTickle"
    method call.  "activityTickle" is called by objects which sense keyboard activity,
    mouse activity, or other button activity (display contrast, display brightness,
    PCMCIA eject).  The method sets a "displayInUse" flag.  When the timer expires,
    this flag is checked.  If it is on, the display is judged "in use".  The flag is
    cleared and the timer is restarted.
    
    If the flag is off when the timer expires, then there has been no user activity
    since the last timer expiration, and the display is judged idle and its power is
    lowered.
    
    The period of the timer is a function of the current value of Power Management
    aggressiveness.  As that factor varies from 1 to 999, the timer period varies
    from 1004 seconds to 6 seconds.  Above 1000, the system is in a very aggressive
    power management condition, and the timer period is 5 seconds.  (In this case,
    the display dims between five and ten seconds after the last user activity).
    
    This driver calls the drivers for each display and has them move their display
    between various power states. When the display is idle, its power is dropped
    state by state until it is in the lowest state.  When it becomes un-idle it is
    powered back up to the state where it was last being used.
    
    In times of very high power management aggressiveness, the display will not be
    operated above the lowest power state which is marked "usable".
    
    When Power Management is turned off (aggressiveness = 0), the display is never
    judged idle and never dimmed.
    
    We register with Power Management only so that we can be informed of changes in
    the Power Management aggressiveness factor.  We don't really have a device with
    power states so we implement the absolute minimum. The display drivers themselves
    are part of the Power Management hierarchy under their respective frame buffers.
*/

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
// initForPM
//

void IODisplayWrangler::initForPM(void )
{
    IODW_START(initForPM,0,0,0);
    // initialize superclass variables
    PMinit();

    // attach into the power management hierarchy
    joinPMtree( this );

    // register ourselves with policy-maker (us)
    registerPowerDriver( this, ourPowerStates, kIODisplayWranglerNumPowerStates );
    makeUsable();

    // HID system is waiting for this
    registerService();
    IODW_END(initForPM,0,0,0);
}

unsigned long IODisplayWrangler::initialPowerStateForDomainState( IOPMPowerFlags domainState )
{
    IODW_START(initialPowerStateForDomainState,domainState,0,0);
    unsigned long   ret = 0;

    if (domainState & IOPMPowerOn)
        ret = (kIODisplayWranglerMaxPowerState);

    IODW_END(initialPowerStateForDomainState,ret,0,0);
    return (ret);
}

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
// setAggressiveness
//
// We are informed by our power domain parent of a new level of "power management
// aggressiveness" which we use as a factor in our judgement of when we are idle.
// This change implies a change in our idle timer period, so restart that timer.
// timer.

IOReturn IODisplayWrangler::setAggressiveness( unsigned long type, unsigned long newLevel )
{
    IODW_START(setAggressiveness,type,newLevel,0);
    switch (type)
    {

      case kIOFBCaptureAggressiveness:

        if (fDimCaptured && !newLevel)
            activityTickle(0,0);

        fDimCaptured = (0 != newLevel);
        setProperty("DimCaptured", fDimCaptured);

        /* fall thru */

      case kPMMinutesToDim:
        // minutes to dim received
        if (kPMMinutesToDim == type)
        {
            // Display will always dim at least kMinDimTime seconds before
            // display sleep kicks in.
            fMinutesToDim = static_cast<UInt32>(newLevel);
			clock_interval_to_absolutetime_interval(fMinutesToDim * 60, kSecondScale, &fOffInterval[0]);

			uint32_t annoyedInterval = fMinutesToDim * 60 * 2;
			if (annoyedInterval > kMaxAnnoyanceInterval) annoyedInterval = kMaxAnnoyanceInterval;
			if (annoyedInterval < (fMinutesToDim * 60))  annoyedInterval = (fMinutesToDim * 60);
			clock_interval_to_absolutetime_interval(annoyedInterval, kSecondScale, &fOffInterval[1]);
			AbsoluteTime_to_scalar(&fSettingsChanged) = mach_absolute_time();

			DEBG2("W", " fMinutesToDim %ld, annoyed %d\n", newLevel, annoyedInterval);
        }

        newLevel = fDimCaptured ? 0 : fMinutesToDim;

            IOG_KTRACE(DBG_IOG_SET_TIMER_PERIOD,
                       DBG_FUNC_NONE,
                       0, DBG_IOG_SOURCE_SET_AGGRESSIVENESS,
                       0, newLevel * 30,
                       0, 0,
                       0, 0);

            setIdleTimerPeriod(newLevel * 30);
        break;

      default:
        break;
    }
    super::setAggressiveness(type, newLevel);

    IODW_END(setAggressiveness,IOPMNoErr,0,0);
    return (IOPMNoErr);
}


/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
// setPowerState
//
// The vanilla policy-maker in the superclass is changing our power state.
// If it's down, inform the displays to lower one state, too.  If it's up,
// the idle displays are made usable.

IOReturn IODisplayWrangler::setPowerState( unsigned long powerStateOrdinal, IOService * whatDevice )
{
    IOG_KTRACE(DBG_IOG_SET_POWER_STATE,
               DBG_FUNC_NONE,
               kGMETRICS_DOMAIN_DISPLAYWRANGLER
                   | kGMETRICS_DOMAIN_POWER
                   | (powerStateOrdinal < getPowerState() ? kGMETRICS_DOMAIN_SLEEP
                                                          : kGMETRICS_DOMAIN_WAKE),
               powerStateOrdinal,
               0, DBG_IOG_SOURCE_IODISPLAYWRANGLER,
               0, 0,
               0, 0);
    IODW_START(setPowerState,powerStateOrdinal,0,0);

    fPendingPowerState = powerStateOrdinal;

	fPowerStateChangeTime = mach_absolute_time();

    DEBG2("W", " (%ld), pwr %d open %d\n", 
                powerStateOrdinal, gIOGraphicsSystemPower, fOpen);

    if (powerStateOrdinal == 0)
    {
        // system is going to sleep
        // keep displays off on wake till UI brings them up

        IOG_KTRACE(DBG_IOG_CHANGE_POWER_STATE_PRIV,
                   DBG_FUNC_NONE,
                   kGMETRICS_DOMAIN_DISPLAYWRANGLER
                       | kGMETRICS_DOMAIN_POWER
                       | kGMETRICS_DOMAIN_SLEEP,
                   DBG_IOG_SOURCE_IODISPLAYWRANGLER,
                   0, 0,
                   0, 0,
                   0, 0);

        changePowerStateToPriv(0);
        IODW_END(setPowerState,IOPMNoErr,0,0);
        return (IOPMNoErr);
    }

    if (!gIOGraphicsSystemPower || !fOpen)
    {
        IODW_END(setPowerState,IOPMNoErr,0,0);
        return (IOPMNoErr);
    }
    else if (powerStateOrdinal < getPowerState())
    {
        // HI is idle, drop power
        if (kIODisplayWranglerMaxPowerState == getPowerState())
        {
			clock_interval_to_deadline(kAnnoyanceWithin, kSecondScale, &fAnnoyanceUntil);
        }

		if (powerStateOrdinal < 3) fAnnoyed = false;

        IOFramebuffer::updateDisplaysPowerState();
    }
    else if (powerStateOrdinal == kIODisplayWranglerMaxPowerState)
    {
        // there is activity, raise power
        IOFramebuffer::updateDisplaysPowerState();

		start_PM_idle_timer();
    }

    IODW_END(setPowerState,IOPMNoErr,0,0);
    return (IOPMNoErr);
}

unsigned long IODisplayWrangler::getDisplaysPowerState(void)
{
    IODW_START(getDisplaysPowerState,0,0,0);
    unsigned long state = gIODisplayWrangler
                                ? gIODisplayWrangler->fPendingPowerState
                                : kIODisplayWranglerMaxPowerState;
    IODW_END(getDisplaysPowerState,state,0,0);
    return (state);
}

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
// nextIdleTimeout
//
// Virtual member function of IOService
// overridden here to provide custom power-down behavior for dimming displays.
// - Transition from 4->3 (to dim on built-in LCDs)
// - Transition from 3->2 (to full display sleep on all machines)
//   will occur at exactly N minutes from last user activity, where N
//   is the value chosen by the user and set via setAggressiveness().

SInt32 IODisplayWrangler::nextIdleTimeout(
    AbsoluteTime currentTime,
    AbsoluteTime lastActivity, 
    unsigned int powerState)
{
    IODW_START(nextIdleTimeout,currentTime,lastActivity,powerState);
	AbsoluteTime deadline;
	uint64_t delayNS = 0;
	SInt32   delaySecs = 0;

    if (!fOpen)
    {
        enum { kWindowServerStartTime = 24 * 60 * 60 };
        IODW_END(nextIdleTimeout,kWindowServerStartTime,0,0);
        return (kWindowServerStartTime);
    }

	if (CMP_ABSOLUTETIME(&fSettingsChanged, &lastActivity) > 0) lastActivity = fSettingsChanged;

    switch (fPendingPowerState) 
    {
        case 4:
            // The system is currently in its 'on' state
            // The transition into the next 'display sleep' state must occur
            // fMinutesToDim after last UI activity
			deadline = lastActivity;
			ADD_ABSOLUTETIME(&deadline, &fOffInterval[fAnnoyed]);
			//if (4 == fPendingPowerState) 
			SUB_ABSOLUTETIME(&deadline, &fDimInterval);
			if (CMP_ABSOLUTETIME(&deadline, &currentTime) > 0)
			{
				SUB_ABSOLUTETIME(&deadline, &currentTime);
				absolutetime_to_nanoseconds(deadline, &delayNS);
				delaySecs = static_cast<SInt32>(delayNS / kSecondScale);
			}
            break;

        case 3:
            // The system is currently in its 'dim' state
			deadline = fPowerStateChangeTime;
			ADD_ABSOLUTETIME(&deadline, &fDimInterval);
			if (CMP_ABSOLUTETIME(&deadline, &currentTime) > 0)
			{
				SUB_ABSOLUTETIME(&deadline, &currentTime);
				absolutetime_to_nanoseconds(deadline, &delayNS);
				delaySecs = static_cast<SInt32>(delayNS / kSecondScale);
            } else {
                IOG_KTRACE(DBG_IOG_CHANGE_POWER_STATE_PRIV,
                           DBG_FUNC_NONE,
                           kGMETRICS_DOMAIN_DISPLAYWRANGLER
                               | kGMETRICS_DOMAIN_POWER
                               | kGMETRICS_DOMAIN_WAKE,
                           DBG_IOG_SOURCE_IODISPLAYWRANGLER,
                           0, 2,
                           0, 0,
                           0, 0);
                changePowerStateToPriv(2);
            }
            break;

        case 2:
        case 1:
            delaySecs = fMinutesToDim * 30;
            break;
        case 0:
        default:
            // error
            delaySecs = 60;
            break;
    }

	DEBG2("W", " %ld, %d, annoyed %d, now %lld, last %lld\n", 
				fPendingPowerState, (int) delaySecs, fAnnoyed,
				AbsoluteTime_to_scalar(&currentTime),
				AbsoluteTime_to_scalar(&lastActivity));

    if (!delaySecs) delaySecs = 1;
	
    IODW_END(nextIdleTimeout,delaySecs,0,0);
    return (delaySecs);
}

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
// activityTickle
//
// This is called by the HID system and calls the superclass in turn.

bool IODisplayWrangler::activityTickle( unsigned long x, unsigned long y )
{
    IODW_START(activityTickle,x,y,0);
    AbsoluteTime now;

    if (!fOpen)
    {
        IODW_END(activityTickle,true,0,0);
        return (true);
    }

    AbsoluteTime_to_scalar(&now) = mach_absolute_time();
    if (AbsoluteTime_to_scalar(&fIdleUntil))
    {
        if (CMP_ABSOLUTETIME(&now, &fIdleUntil) < 0)
        {
            IODW_END(activityTickle,true,0,0);
            return (true);
        }
        AbsoluteTime_to_scalar(&fIdleUntil) = 0;
    }

    // Record if this was an annoyance.
    if (AbsoluteTime_to_scalar(&fAnnoyanceUntil))
	{
		DEBG2("W", " now %lld, annoyed until %lld\n", 
				AbsoluteTime_to_scalar(&now),
				AbsoluteTime_to_scalar(&fAnnoyanceUntil));

        if (CMP_ABSOLUTETIME(&now, &fAnnoyanceUntil) < 0)
            fAnnoyed = true;
        AbsoluteTime_to_scalar(&fAnnoyanceUntil) = 0;
	}

    if (super::activityTickle(kIOPMSuperclassPolicy1,
                kIODisplayWranglerMaxPowerState) )
    {
        IODW_END(activityTickle,true,0,0);
        return (true);
    }

    IOG_KTRACE(DBG_IOG_WAKE_FROM_DOZE,
               DBG_FUNC_NONE,
               kGMETRICS_DOMAIN_DISPLAYWRANGLER | kGMETRICS_DOMAIN_DOZE,
               x,
               0, y,
               0, 0,
               0, 0);

    getPMRootDomain()->wakeFromDoze();

    IODW_END(activityTickle,false,0,0);
    return (false);
}

OSObject * IODisplayWrangler::copyProperty( const char * aKey ) const
{
    IODW_START(copyProperty,0,0,0);

    OSObject * obj = NULL;
    const bool userPrefs = !strcmp(aKey, kIOGraphicsPrefsKey);

    if (userPrefs)
    {
        obj = IOFramebuffer::copyPreferences();
    }
    else
    {
        obj = super::copyProperty(aKey);
    }

    IODW_END(copyProperty,userPrefs,0,0);
    return (obj);
}

IOReturn IODisplayWrangler::setProperties( OSObject * properties )
{
    IODW_START(setProperties,0,0,0);
    IOReturn        err;
    OSDictionary * dict;
    OSDictionary * prefs;
    OSObject *     obj;
    OSNumber *     num;
    uint32_t       idleFor = 0;
    enum { kIODisplayRequestDefaultIdleFor = 1000,
            kIODisplayRequestMaxIdleFor    = 15000 };

    if (!(dict = OSDynamicCast(OSDictionary, properties)))
    {
        IODW_END(setProperties,kIOReturnBadArgument,0,0);
        return (kIOReturnBadArgument);
    }

    if ((prefs = OSDynamicCast(OSDictionary,
                              dict->getObject(kIOGraphicsPrefsKey))))
    {
        err = IOFramebuffer::setPreferences(this, prefs);
        IODW_END(setProperties,err,0,0);
        return (err);
    }

    obj = dict->getObject(kIORequestIdleKey);
    if (kOSBooleanTrue == obj)
    {
        idleFor = kIODisplayRequestDefaultIdleFor;
    }
    else if (kOSBooleanFalse == obj)
    {
        AbsoluteTime_to_scalar(&fIdleUntil) = 0;
        activityTickle(0, 0);
    }
    else if ((num = OSDynamicCast(OSNumber, obj)))
    {
        idleFor = num->unsigned32BitValue();
        if (idleFor > kIODisplayRequestMaxIdleFor)
            idleFor = kIODisplayRequestMaxIdleFor;
    }

    if (idleFor)
    {
        const auto currentPower = getPowerState();
        char procName[32]; proc_selfname(procName, sizeof(procName));

        DEBG1("W", " requested idleFor %s%dms by process '%s' from %d\n",
              (2 == gIODisplayFadeStyle)? "with fade " : "",
              idleFor, procName, currentPower);
        IOLog("DW forced idle %sfor %dms by process '%s' from %d\n",
              (2 == gIODisplayFadeStyle)? "with fade " : "",
              idleFor, procName, currentPower);
        clock_interval_to_deadline(idleFor, kMillisecondScale, &fIdleUntil);
		if (2 == gIODisplayFadeStyle)
		{
			if (currentPower > 3)
			{
                IOG_KTRACE(DBG_IOG_CHANGE_POWER_STATE_PRIV,
                           DBG_FUNC_NONE,
                           kGMETRICS_DOMAIN_DISPLAYWRANGLER
                               | kGMETRICS_DOMAIN_POWER,
                           DBG_IOG_SOURCE_IODISPLAYWRANGLER,
                           0, 3,
                           0, 0,
                           0, 0);

                changePowerStateToPriv(3);

                IOG_KTRACE(DBG_IOG_SET_TIMER_PERIOD,
                           DBG_FUNC_NONE,
                           0, DBG_IOG_SOURCE_IODISPLAYWRANGLER,
                           0, 60,
                           0, 0,
                           0, 0);

				setIdleTimerPeriod(60);
			}
		}
		else if (currentPower > 1)
        {
            IOG_KTRACE(DBG_IOG_CHANGE_POWER_STATE_PRIV,
                       DBG_FUNC_NONE,
                       kGMETRICS_DOMAIN_DISPLAYWRANGLER
                           | kGMETRICS_DOMAIN_POWER
                           | kGMETRICS_DOMAIN_DOZE,
                       DBG_IOG_SOURCE_IODISPLAYWRANGLER,
                       0, 1,
                       0, 0,
                       0, 0);

            changePowerStateToPriv(1);
        }
    }

    IODW_END(setProperties,kIOReturnSuccess,0,0);
    return (kIOReturnSuccess);
}
