//
//  IOBacklightDisplayTrace.hpp
//  IOGraphics
//
//  Created by Godfrey van der Linden on 19-8-8.
//

#ifndef _IOKIT_GRAPHICS_IOBACKLIGHTDISPLAYTRACE_H
#define _IOKIT_GRAPHICS_IOBACKLIGHTDISPLAYTRACE_H

#include <IOKit/graphics/GTraceTypes.hpp>


#endif // _IOKIT_GRAPHICS_IOBACKLIGHTDISPLAYTRACE_H
