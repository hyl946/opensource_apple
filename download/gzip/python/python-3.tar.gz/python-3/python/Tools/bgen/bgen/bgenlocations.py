#
# Local customizations
#

# Where to find the Universal Header include files:
MWERKSDIR="Macintosh HD:SWDev:Codewarrior Pro 5:Metrowerks CodeWarrior:"
INCLUDEDIR=MWERKSDIR + "MacOS Support:Universal:Interfaces:CIncludes:"

# Where to put the python definitions file:
TOOLBOXDIR="Macintosh HD:SWDev:Jack:Python:Mac:Lib:lib-toolbox:"

# Creator for C files:
CREATOR="CWIE"
