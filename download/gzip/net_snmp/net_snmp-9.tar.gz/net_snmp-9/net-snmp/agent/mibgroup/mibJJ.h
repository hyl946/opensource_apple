/* module to include the modules relavent to the mib-JJ mib(s) */

config_require(mibJJ/system_mib)
config_require(mibJJ/sysORTable)
config_require(mibJJ/interfaces)
config_require(mibJJ/snmp_mib)
config_require(mibJJ/tcp)
config_require(mibJJ/icmp)
config_require(mibJJ/ip)
config_require(mibJJ/udp)
config_require(mibJJ/vacm_vars)
