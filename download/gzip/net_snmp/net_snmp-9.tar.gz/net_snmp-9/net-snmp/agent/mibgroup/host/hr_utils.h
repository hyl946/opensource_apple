/*
 *  Host Resources MIB - utility functions interface - hr_utils.h
 *
 */

u_char * date_n_time (time_t * , size_t * );
time_t ctime_to_timet (char* );
