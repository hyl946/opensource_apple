/*
 *  vmstat mib groups
 *
 */
#ifndef _MIBGROUP_VMSTAT_NETBSD1_H
#define _MIBGROUP_VMSTAT_NETBSD1_H

#include "mibdefs.h"

void            init_vmstat_netbsd1(void);

#endif                          /* _MIBGROUP_VMSTAT_NETBSD1_H */
