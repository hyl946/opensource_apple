/*
 * module to include the modules
 */

config_require(ip-forward-mib/ipCidrRouteTable);
config_require(ip-forward-mib/inetCidrRouteTable);
