/*
 * module to include the modules
 */

config_require(ip-mib/data_access/arp);
config_require(ip-mib/inetNetToMediaTable/inetNetToMediaTable);
config_require(ip-mib/inetNetToMediaTable/inetNetToMediaTable_interface);
config_require(ip-mib/inetNetToMediaTable/inetNetToMediaTable_data_access);
