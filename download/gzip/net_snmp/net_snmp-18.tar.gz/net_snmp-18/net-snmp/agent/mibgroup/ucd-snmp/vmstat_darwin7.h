/*
 *  vmstat mib groups
 *
 */
#ifndef _MIBGROUP_VMSTAT_DARWIN7_H
#define _MIBGROUP_VMSTAT_DARWIN7_H

#include "mibdefs.h"

void            init_vmstat_darwin7(void);

#endif                          /* _MIBGROUP_VMSTAT_DARWIN7_H */
