config_require(target/snmpTargetAddrEntry)
config_require(target/snmpTargetParamsEntry)
config_require(target/target)
config_add_mib(SNMP-TARGET-MIB)
