#include "generic.h"

#undef HAVE_WINSOCK_H
#undef bsdlike
#undef MBSTAT_SYMBOL
#undef TOTAL_MEMORY_SYMBOL

