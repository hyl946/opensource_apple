config_require(agent/nsTransactionTable)
config_require(agent/nsModuleTable)
config_add_mib(NET-SNMP-AGENT-MIB)
