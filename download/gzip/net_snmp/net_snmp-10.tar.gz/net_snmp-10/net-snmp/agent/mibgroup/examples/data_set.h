#ifndef DATA_SET_H
#define DATA_SET_H

void            init_data_set(void);

#endif                          /* DATA_SET_H */
