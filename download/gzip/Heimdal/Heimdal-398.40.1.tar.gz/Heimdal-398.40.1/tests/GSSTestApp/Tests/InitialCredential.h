//
//  InitialCredential.h
//  GSSTestApp
//
//  Created by Love Hörnquist Åstrand on 2013-06-07.
//  Copyright (c) 2013 Apple, Inc. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>
#import "SenTestCase+GSS.h"

@interface InitialCredential : SenTestCase

@end
