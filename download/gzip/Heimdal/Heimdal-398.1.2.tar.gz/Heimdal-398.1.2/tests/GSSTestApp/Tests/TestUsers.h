//
//  TestUsers.h
//  GSSTestApp
//
//  Created by Love Hörnquist Åstrand on 2014-02-16.
//  Copyright (c) 2014 Apple, Inc. All rights reserved.
//


extern NSString *passwordKtestuserQAD;