//
//  ViewController.h
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController {
    dispatch_queue_t _queue;
}

- (IBAction)addCredential:(id)sender;

@end
