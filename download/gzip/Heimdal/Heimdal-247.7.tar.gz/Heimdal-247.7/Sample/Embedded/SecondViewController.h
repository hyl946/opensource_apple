//
//  SecondViewController.h
//  GSSEmbeddedSample
//
//  Created by Love Hörnquist Åstrand on 2011-03-15.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface SecondViewController : UIViewController {
    
}

- (IBAction)authenticate:(id)sender;

@end
