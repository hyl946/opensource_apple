#ifndef VERSION_HIDDEN
#define VERSION_HIDDEN
#endif
VERSION_HIDDEN const char *heimdal_version = "Heimdal 1.4.1apple1";
