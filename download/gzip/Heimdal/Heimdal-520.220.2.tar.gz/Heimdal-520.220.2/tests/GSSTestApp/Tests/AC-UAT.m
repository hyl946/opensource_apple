//
//  AC-UAT.m
//  GSSTestApp
//
//  Created by Love Hörnquist Åstrand on 2014-08-20.
//  Copyright (c) 2014 Apple, Inc. All rights reserved.
//

#import "FakeXCTest.h"
#import "XCTestCase+GSS.h"

#if 0 // disabled since we no longer have a test account in UAT

@interface AC_UAT : XCTestCase

@end

@implementation AC_UAT


@end

#endif
