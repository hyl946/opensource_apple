//
//  expirationDateTransformer.h
//  GSSTestApp
//
//  Created by Love Hörnquist Åstrand on 2013-07-03.
//  Copyright (c) 2013 Apple, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface expirationDateTransformer : NSValueTransformer

@end
