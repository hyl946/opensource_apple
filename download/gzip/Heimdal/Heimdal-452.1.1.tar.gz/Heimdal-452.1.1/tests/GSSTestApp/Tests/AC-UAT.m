//
//  AC-UAT.m
//  GSSTestApp
//
//  Created by Love Hörnquist Åstrand on 2014-08-20.
//  Copyright (c) 2014 Apple, Inc. All rights reserved.
//

#import "FakeXCTest.h"
#import "XCTestCase+GSS.h"

@interface AC_UAT : XCTestCase

@end

@implementation AC_UAT


@end
