#!/bin/sh

tool=${FULL_PRODUCT_NAME}

