This directory contains implementations of core AES routines (the actual
encryption, decryption, and key expansion) for the i386 (IA-32) and x86_64
(EMT64) architectures.  These routines are intended to be called by routines
in the parent directory.
