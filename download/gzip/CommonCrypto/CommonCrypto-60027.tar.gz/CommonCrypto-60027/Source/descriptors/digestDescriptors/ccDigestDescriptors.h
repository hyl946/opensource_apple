#include "ccDescriptors.h"

#ifndef _CC_DIGESTDESCRIPTORS_H
#define _CC_DIGESTDESCRIPTORS_H

#define CCCTX_SIZE(DI) ((DI)->state_size + sizeof(uint64_t) + (DI)->block_size + sizeof(int))



#endif /* _CC_DIGESTDESCRIPTORS_H */
