#ifndef _EAP8021X_DESSUPPORT_H
#define _EAP8021X_DESSupport_H

void DesEncrypt(const unsigned char * clear, const unsigned char * key, 
		unsigned char * cipher);

#endif _EAP8021X_DESSUPPORT_H
