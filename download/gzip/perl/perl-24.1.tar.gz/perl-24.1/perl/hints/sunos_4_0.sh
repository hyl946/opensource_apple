ccflags="$ccflags -DFPUTS_BOTCH"
i_unistd=$undef
