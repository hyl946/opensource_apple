$self->{CCFLAGS} = $Config{ccflags} . ' -D_POSIX_SOURCE' ;
