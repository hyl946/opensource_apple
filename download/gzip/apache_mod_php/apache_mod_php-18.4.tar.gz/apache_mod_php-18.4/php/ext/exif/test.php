<?php
	include 'test.txt';
?>