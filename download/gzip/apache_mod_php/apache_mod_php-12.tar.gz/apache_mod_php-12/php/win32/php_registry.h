#ifndef PHP_REGISTRY_H
#define PHP_REGISTRY_H


void UpdateIniFromRegistry(char *path TSRMLS_DC);

#endif /* PHP_REGISTRY_H */
