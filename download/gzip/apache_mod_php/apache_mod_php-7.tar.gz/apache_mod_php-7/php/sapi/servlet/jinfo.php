<?

  phpinfo();

?>
