Check out IRCG 4 which works with Apache and other popular web servers.

	http://schumann.cx/ircg/

Support for IRCG 2 has been terminated.

About IRCG

IRCG is a socket server for commodity web servers like Apache and thttpd,
tieing into a vast network of IRC components.
