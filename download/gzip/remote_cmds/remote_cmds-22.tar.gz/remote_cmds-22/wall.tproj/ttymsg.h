/* $FreeBSD: src/usr.bin/wall/ttymsg.h,v 1.1 2001/09/09 14:23:31 dd Exp $ */

const char	*ttymsg(struct iovec *, int, const char *, int);
