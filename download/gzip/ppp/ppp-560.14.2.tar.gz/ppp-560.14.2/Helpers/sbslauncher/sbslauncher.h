/*
 * Copyright (c) 2009-2011 Apple Computer, Inc. All rights reserved.
 */


#define SBSLAUNCHER_TYPE_PROFILE_JANITOR "sbslauncher_type_profile_janitor"


