/* $Id: vpn_control_var.h,v 1.7 2004/12/30 00:08:30 manubsd Exp $ */

/*
 * Copyright (c) 2009-2011 Apple Computer, Inc. All rights reserved.
 */

