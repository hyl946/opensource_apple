/* $Id: patchlevel.h,v 1.4 2001/05/09 17:52:32 callie Exp $ */
#define	PATCHLEVEL	0

#define VERSION		"2.4"
#define IMPLEMENTATION	""
#define DATE		"1 August 2000"
