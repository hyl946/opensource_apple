/*
 * Copyright (c) 2012 Apple Inc.
 * All rights reserved.
 */

#ifndef __BEHAVIORS_CHECK_ASSET_H__
#define __BEHAVIORS_CHECK_ASSET_H__

int behaviors_start_asset_check(int argc, const char *argv[]);

#endif /* __BEHAVIORS_CHECK_ASSET_H__ */
