/*
 * Copyright (c) 2013 Apple Inc.
 * All rights reserved.
 */

#ifndef __SNHELPER_LAUNCH_SERVICES_H__
#define __SNHELPER_LAUNCH_SERVICES_H__

void handle_get_uuid_for_app(xpc_connection_t connection, xpc_object_t message);

#endif /* __SNHELPER_LAUNCH_SERVICES_H__ */
