/*
 * Copyright (c) 2009-2011 Apple Computer, Inc. All rights reserved.
 */


#define SBSLAUNCHER_TYPE_PROFILE_JANITOR "sbslauncher_type_profile_janitor"


#define SBSLAUNCHER_TYPE_PROBE_SERVER "sbslauncher_type_probe_server"

#define SBSLAUNCHER_TYPE_DETECT_DNS_REDIRECT "sbslauncher_type_detect_dns_redirect"

#define SBSLAUNCHER_TYPE_SETUP_ENV "sbslauncher_type_setup_env"
