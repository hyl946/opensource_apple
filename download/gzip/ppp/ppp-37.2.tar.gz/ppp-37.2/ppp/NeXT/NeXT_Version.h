/*
* ppp-2.3 port to the NeXT
* version_string 0.5.1
*
* $Id: NeXT_Version.h,v 1.3 2001/01/20 03:35:31 callie Exp $
*/
#define PPPVERSION "0.5.1"
