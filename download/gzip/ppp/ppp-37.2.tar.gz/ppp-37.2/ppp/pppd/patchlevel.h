/* $Id: patchlevel.h,v 1.3 2001/01/20 03:35:46 callie Exp $ */
#define	PATCHLEVEL	11

#define VERSION		"2.3"
#define IMPLEMENTATION	""
#define DATE		"23 December 1999"
