/* $Id: patchlevel.h,v 1.2 2002/03/13 22:44:57 callie Exp $ */
#define	PATCHLEVEL	0

#define VERSION		"2.4"
#define IMPLEMENTATION	""
#define DATE		"1 August 2000"
