#include <unicode/uregex.h>
#include <unicode/ustring.h>
int main(int argc, char *argv[]) {
	return 0;
}
