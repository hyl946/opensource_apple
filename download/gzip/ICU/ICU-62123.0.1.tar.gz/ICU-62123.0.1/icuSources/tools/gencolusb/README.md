Unsafe-Backward Collator Data
===

This directory contains tools to build the `source/i18n/collunsafe.h`
precomputed data.

See [Makefile](./Makefile) for more details.

* Copyright (C) 2016 and later: Unicode, Inc. and others. License & terms of use: http://www.unicode.org/copyright.html
* Copyright (c) 2015, International Business Machines Corporation and others. All Rights Reserved.
