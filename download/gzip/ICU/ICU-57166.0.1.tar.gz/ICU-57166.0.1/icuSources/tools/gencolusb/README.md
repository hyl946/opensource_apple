Unsafe-Backward Collator Data
===

This directory contains tools to build the `source/i18n/collunsafe.h`
precomputed data.

See [Makefile](./Makefile) for more details.

* Copyright (c) 2015, International Business Machines Corporation and others. All Rights Reserved.
