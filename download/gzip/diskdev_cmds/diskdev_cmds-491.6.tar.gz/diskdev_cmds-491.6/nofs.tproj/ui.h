/*
 * Copyright (c) 2009 Apple Inc. All rights reserved.
 */

#ifndef UI_H
#define UI_H

extern SInt32 AlertCoreStorageNotInstalled(void);

#endif
