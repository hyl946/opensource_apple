
sudo ./build/Release/top -stats pid,command,cpu,time,th,wq,ports,mreg,rprvt,rshrd,rsize,vsize,vprvt,pgrp,ppid,state,uid,faults,cow,msgsent,msgrecv,sysbsd,sysmach,csw,pageins,user,pid
