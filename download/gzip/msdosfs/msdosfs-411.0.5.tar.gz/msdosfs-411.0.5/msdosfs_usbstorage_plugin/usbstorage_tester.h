/* Copyright © 2017 Apple Inc. All rights reserved.
 *
 *  usbstorage_tester.h
 *  usbstorage_plugin
 *
 */

#ifndef usbstorage_tester_h
#define usbstorage_tester_h

#include <stdio.h>

#endif /* usbstorage_tester_h */
