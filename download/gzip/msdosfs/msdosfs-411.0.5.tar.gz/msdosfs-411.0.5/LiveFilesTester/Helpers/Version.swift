let FATTESTER_VERSION = 1.09
let BUILD_DATE_TIME : String = "\(String(cString:getBuildDate()))  \(String(cString:getBuildTime()))"
