g/\<p_long\>/s//p_int/g
g/\<p_ulong\>/s//p_uint/g
wq
