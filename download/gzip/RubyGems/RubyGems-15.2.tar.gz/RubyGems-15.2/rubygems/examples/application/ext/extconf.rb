require 'mkmf'
create_makefile("foo")

