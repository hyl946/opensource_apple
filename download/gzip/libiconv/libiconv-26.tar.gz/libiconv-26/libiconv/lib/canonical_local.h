  (int)(long)&((struct stringpool_t *)0)->stringpool_str28,
  (int)(long)&((struct stringpool_t *)0)->stringpool_str460,
