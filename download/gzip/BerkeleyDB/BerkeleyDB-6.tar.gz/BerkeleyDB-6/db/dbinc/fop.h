/*-
 * See the file LICENSE for redistribution information.
 *
 * Copyright (c) 2001-2002
 *	Sleepycat Software.  All rights reserved.
 *
 * $Id: fop.h,v 1.1.1.1 2003/02/15 04:55:42 zarzycki Exp $
 */

#ifndef	_FOP_H_
#define	_FOP_H_

#include "dbinc_auto/fileops_auto.h"
#include "dbinc_auto/fileops_ext.h"

#endif /* !_FOP_H_ */
