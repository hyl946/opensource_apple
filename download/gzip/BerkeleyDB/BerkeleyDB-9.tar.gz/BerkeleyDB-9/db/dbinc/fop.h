/*-
 * See the file LICENSE for redistribution information.
 *
 * Copyright (c) 2001-2003
 *	Sleepycat Software.  All rights reserved.
 *
 * $Id: fop.h,v 1.2 2004/03/30 01:21:28 jtownsen Exp $
 */

#ifndef	_FOP_H_
#define	_FOP_H_

#include "dbinc_auto/fileops_auto.h"
#include "dbinc_auto/fileops_ext.h"

#endif /* !_FOP_H_ */
