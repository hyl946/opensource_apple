/* $OpenBSD: version.h,v 1.80 2017/09/30 22:26:33 djm Exp $ */

#define SSH_VERSION	"OpenSSH_7.6"

#define SSH_PORTABLE	"p1"
#define SSH_RELEASE	SSH_VERSION SSH_PORTABLE
