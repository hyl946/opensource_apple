/* $OpenBSD: version.h,v 1.45 2005/08/31 09:28:42 markus Exp $ */

#define SSH_VERSION	"OpenSSH_4.2"

#define SSH_PORTABLE	"p1"
#define SSH_RELEASE	SSH_VERSION SSH_PORTABLE
