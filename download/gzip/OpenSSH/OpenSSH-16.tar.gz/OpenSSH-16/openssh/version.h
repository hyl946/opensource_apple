/* $OpenBSD: version.h,v 1.28 2002/03/06 00:25:55 markus Exp $ */

#define SSH_VERSION	"OpenSSH_3.1p1"

