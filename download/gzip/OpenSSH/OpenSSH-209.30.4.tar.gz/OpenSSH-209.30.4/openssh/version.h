/* $OpenBSD: version.h,v 1.77 2016/07/24 11:45:36 djm Exp $ */

#define SSH_VERSION	"OpenSSH_7.3"

#define SSH_PORTABLE	"p1"
#define SSH_RELEASE	SSH_VERSION SSH_PORTABLE
