/* $OpenBSD: version.h,v 1.54 2008/07/21 08:19:07 djm Exp $ */

#define SSH_VERSION	"OpenSSH_5.1"

#define SSH_PORTABLE	"p1"
#define SSH_RELEASE	SSH_VERSION SSH_PORTABLE
