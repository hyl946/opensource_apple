/* $OpenBSD: version.h,v 1.34 2002/06/26 13:56:27 markus Exp $ */

#define SSH_VERSION	"OpenSSH_3.4p1+CAN-2003-0693"
