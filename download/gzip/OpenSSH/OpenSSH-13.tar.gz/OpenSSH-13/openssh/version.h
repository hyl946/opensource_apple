/* $OpenBSD: version.h,v 1.25 2001/10/15 16:10:50 deraadt Exp $ */

#define SSH_VERSION	"OpenSSH_3.0.2p1"
