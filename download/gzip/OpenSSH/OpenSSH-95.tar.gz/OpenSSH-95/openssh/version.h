/* $OpenBSD: version.h,v 1.50 2007/08/15 08:16:49 markus Exp $ */

#define SSH_VERSION	"OpenSSH_4.7"

#define SSH_PORTABLE	"p1"
#define SSH_RELEASE	SSH_VERSION SSH_PORTABLE
