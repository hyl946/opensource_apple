/* $Id: strmode.h,v 1.1.1.2 2001/11/03 18:14:20 bbraun Exp $ */

#ifndef HAVE_STRMODE

void strmode(register mode_t mode, register char *p);

#endif
