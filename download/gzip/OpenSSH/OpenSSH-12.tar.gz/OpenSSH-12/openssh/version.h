/* $OpenBSD: version.h,v 1.23 2001/04/24 16:43:16 markus Exp $ */

#define SSH_VERSION	"OpenSSH_2.9p2"
