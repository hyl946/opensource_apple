/* $Id: strmode.h,v 1.1.1.1 2001/02/25 20:54:31 zarzycki Exp $ */

#ifndef HAVE_STRMODE

void strmode( register mode_t mode, register char *p);

#endif
