int foo(void)
{
	return 10;
}
