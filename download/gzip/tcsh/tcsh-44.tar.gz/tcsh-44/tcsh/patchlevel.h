/* $Header: /cvs/root/tcsh/tcsh/patchlevel.h,v 1.1.1.3 2003/01/17 03:41:10 nicolai Exp $ */
/*
 * patchlevel.h: Our life story.
 */
#ifndef _h_patchlevel
#define _h_patchlevel

#define ORIGIN "Astron"
#define REV 6
#define VERS 12
#define PATCHLEVEL 00
#define DATE "2002-07-23"

#endif /* _h_patchlevel */
