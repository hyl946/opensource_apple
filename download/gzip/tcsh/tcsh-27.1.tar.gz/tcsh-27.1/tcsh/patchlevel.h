/* $Header: /cvs/Darwin/Commands/Other/tcsh/tcsh/patchlevel.h,v 1.1.1.2 2001/06/28 23:10:49 bbraun Exp $ */
/*
 * patchlevel.h: Our life story.
 */
#ifndef _h_patchlevel
#define _h_patchlevel

#define ORIGIN "Astron"
#define REV 6
#define VERS 10
#define PATCHLEVEL 0
#define DATE "2000-11-19"

#endif /* _h_patchlevel */
