/* $Header: /src/pub/tcsh/patchlevel.h,v 3.151 2005/03/25 17:36:08 kim Exp $ */
/*
 * patchlevel.h: Our life story.
 */
#ifndef _h_patchlevel
#define _h_patchlevel

#define ORIGIN "Astron"
#define REV 6
#define VERS 14
#define PATCHLEVEL 0
#define DATE "2005-03-25"

#endif /* _h_patchlevel */
