========================================================================
       DYNAMIC LINK LIBRARY : saslSCRAM
========================================================================

-*- UNTESTED -*- UNTESTED -*- UNTESTED -*- UNTESTED -*- UNTESTED -*- UNTESTED -*-

SASL Authentication Module: SCRAM

Modifications made to project settings:

* Include path 
- Added main sasl include directory

* Precompiled header
- Turned off.

* Libraries for linking
- Added winsock2 (ws2_32.lib)
- Added sasl (libsasl.lib)

-*- UNTESTED -*- UNTESTED -*- UNTESTED -*- UNTESTED -*- UNTESTED -*- UNTESTED -*-
