========================================================================
       DYNAMIC LINK LIBRARY : saslCRAM
========================================================================

-*- UNTESTED -*- UNTESTED -*- UNTESTED -*- UNTESTED -*- UNTESTED -*- UNTESTED -*-

SASL Authentication Module: CRAM

Modifications made to project settings:

* Include path 
- Added main sasl include directory

* Precompiled header
- Turned off.


-*- UNTESTED -*- UNTESTED -*- UNTESTED -*- UNTESTED -*- UNTESTED -*- UNTESTED -*-
