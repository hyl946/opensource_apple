
package javax.security.auth.callback;

/**
All Known Implementing Classes:
ConfirmationCallback, LanguageCallback, NameCallback, PasswordCallback,
TextInputCallback, TextOutputCallback, ChoiceCallback
*/

public abstract interface Callback
{
    /* nothing. just use as a base */
}
