========================================================================
       DYNAMIC LINK LIBRARY : saslLOGIN
========================================================================

SASL Authentication Module: LOGIN

This module was created by using the SASL authentication module PLAIN
as a template.


February 14, 2000.
Geir A. Myrestrand, geir@sendmail.com
Sendmail, Inc.
