========================================================================
       DYNAMIC LINK LIBRARY : saslPLAIN
========================================================================

SASL Authentication Module: PLAIN

Modifications made to project settings:

* Include path 
- Added main sasl include directory

* Precompiled header
- Turned off.
