/*
 *  IOFWBufferFillIsochPort.h
 *  IOFireWireFamily
 *
 *  Created by Niels on Mon Sep 09 2002.
 *  Copyright (c) 2002 Apple Computer, Inc. All rights reserved.
 *
 * $Log: IOFWBufferFillIsochPort.h,v $
 * Revision 1.5  2007/10/16 16:50:21  ayanowit
 * Removed existing "work-in-progress" support for buffer-fill isoch.
 *
 *
 */

// Deprecated