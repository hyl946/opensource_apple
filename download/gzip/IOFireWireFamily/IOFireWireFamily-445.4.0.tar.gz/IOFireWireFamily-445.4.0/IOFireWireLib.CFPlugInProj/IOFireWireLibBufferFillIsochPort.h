/*
 *  IOFireWireLibBufferFillIsochPort.h
 *  IOFireWireFamily
 *
 *  Created by Niels on Fri Feb 21 2003.
 *  Copyright (c) 2003 Apple Computer, Inc. All rights reserved.
 *
 *	$Log: IOFireWireLibBufferFillIsochPort.h,v $
 *	Revision 1.4  2007/10/16 16:50:21  ayanowit
 *	Removed existing "work-in-progress" support for buffer-fill isoch.
 *
 *	
 */

// Deprecated