/*
 *  IOFireWireLibBufferFillIsochPort.cpp
 *  IOFireWireFamily
 *
 *  Created by Niels on Fri Feb 21 2003.
 *  Copyright (c) 2003 __MyCompanyName__. All rights reserved.
 *
 *	$ Log:IOFireWireLibBufferFillIsochPort.cpp,v $
 */

// Deprecated

