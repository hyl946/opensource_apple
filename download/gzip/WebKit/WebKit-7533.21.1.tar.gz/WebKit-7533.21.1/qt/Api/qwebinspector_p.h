/*
    Copyright (C) 2008, 2009 Nokia Corporation and/or its subsidiary(-ies)

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Library General Public
    License as published by the Free Software Foundation; either
    version 2 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Library General Public License for more details.

    You should have received a copy of the GNU Library General Public License
    along with this library; see the file COPYING.LIB.  If not, write to
    the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
    Boston, MA 02110-1301, USA.
*/

#ifndef QWEBINSPECTOR_P_H
#define QWEBINSPECTOR_P_H

QT_BEGIN_NAMESPACE
class QSize;
class QWidget;
QT_END_NAMESPACE
class QWebInspector;
class QWebPage;

class QWebInspectorPrivate {
public:
    QWebInspectorPrivate(QWebInspector* qq)
    : q(qq)
    , page(0)
    , frontend(0)
    {}

    void setFrontend(QWidget* newFrontend);
    void adjustFrontendSize(const QSize& size);

    QWebInspector* q;
    QWebPage* page;
    QWidget* frontend;
};

#endif
