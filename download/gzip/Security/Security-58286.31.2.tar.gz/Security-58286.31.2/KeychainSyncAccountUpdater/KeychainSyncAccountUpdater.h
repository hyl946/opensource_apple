#import <UAUPlugin/UAUSession.h>

@interface KeychainSyncAccountUpdater : NSObject <UserAccountUpdaterProtocol>

@end
