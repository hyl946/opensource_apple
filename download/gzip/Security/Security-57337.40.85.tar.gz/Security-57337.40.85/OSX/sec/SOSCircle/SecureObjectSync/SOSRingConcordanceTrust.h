//
//  SOSRingConcordanceTrust.h
//  sec
//
//  Created by Richard Murphy on 3/15/15.
//
//

#ifndef _sec_SOSRingConcordanceTrust_
#define _sec_SOSRingConcordanceTrust_

#include <stdio.h>

#endif /* defined(_sec_SOSRingConcordanceTrust_) */
