This is the os_log preference plist for com.apple.securityd subsystem.  The plist is installed by

iOS - the securityd target build phase
OSX - the OSX subproject - secd target build phase

