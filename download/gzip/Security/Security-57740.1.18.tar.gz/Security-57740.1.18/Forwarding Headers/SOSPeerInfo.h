//
// Forward to the proper location
// This header is temporary until deprecation can be accomplished
//
// SOSPeerInfo.h was erroneously put directly in PrivateHeaders.
// This header forwards for clients who adopted that location.
//
// Warning and removing this file left to the future
//

#include <Security/SecureObjectSync/SOSPeerInfo.h>
