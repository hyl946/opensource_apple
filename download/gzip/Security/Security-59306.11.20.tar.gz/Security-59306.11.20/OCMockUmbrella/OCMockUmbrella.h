
#import <Foundation/Foundation.h>

//! Project version number for OCMockUmbrella.
FOUNDATION_EXPORT double OCMockUmbrellaVersionNumber;

//! Project version string for OCMockUmbrella.
FOUNDATION_EXPORT const unsigned char OCMockUmbrellaVersionString[];
