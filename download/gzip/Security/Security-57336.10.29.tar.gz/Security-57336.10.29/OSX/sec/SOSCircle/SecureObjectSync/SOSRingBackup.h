//
//  SOSRingBackup.h
//  sec
//
//  Created by Richard Murphy on 4/24/15.
//
//

#ifndef _sec_SOSRingBackup_
#define _sec_SOSRingBackup_

#include "SOSRingTypes.h"

extern ringFuncStruct backup;


#endif /* defined(_sec_SOSRingBackup_) */
