/*
 * Copyright (c) 2000-2001 Apple Computer, Inc. All Rights Reserved.
 * 
 * The contents of this file constitute Original Code as defined in and are
 * subject to the Apple Public Source License Version 1.2 (the 'License').
 * You may not use this file except in compliance with the License. Please obtain
 * a copy of the License at http://www.apple.com/publicsource and read it before
 * using this file.
 * 
 * This Original Code and all software distributed under the License are
 * distributed on an 'AS IS' basis, WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS
 * OR IMPLIED, AND APPLE HEREBY DISCLAIMS ALL SUCH WARRANTIES, INCLUDING WITHOUT
 * LIMITATION, ANY WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, QUIET ENJOYMENT OR NON-INFRINGEMENT. Please see the License for the
 * specific language governing rights and limitations under the License.
 */


//
//  builtin_modules.cpp
//  Security
//
//  Created by michael on Tue Mar 13 2001.
//  Copyright (c) 2001 Apple Computer, Inc. All rights reserved.
//

#include <Security/cssmspi.h>
#include <Security/pluginspi.h>

CSSM_SPI_MODULE_DECLARATION(AppleCSP);
CSSM_SPI_MODULE_DECLARATION(AppleCSPDL);
CSSM_SPI_MODULE_DECLARATION(AppleFileDL);
CSSM_SPI_MODULE_DECLARATION(AppleX509CL);
CSSM_SPI_MODULE_DECLARATION(AppleX509TP);

static void reference()
{
    AppleCSPCSSM_SPI_ModuleLoad(NULL, NULL, NULL, NULL);
    AppleCSPDLCSSM_SPI_ModuleLoad(NULL, NULL, NULL, NULL);
    AppleFileDLCSSM_SPI_ModuleLoad(NULL, NULL, NULL, NULL);
    AppleX509CLCSSM_SPI_ModuleLoad(NULL, NULL, NULL, NULL);
    AppleX509TPCSSM_SPI_ModuleLoad(NULL, NULL, NULL, NULL);
}
