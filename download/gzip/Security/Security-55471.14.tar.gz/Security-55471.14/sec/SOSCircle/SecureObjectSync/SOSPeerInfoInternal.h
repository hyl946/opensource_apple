//
//  SOSPeerInfoInternal.h
//  sec
//
//  Created by Richard Murphy on 6/24/13.
//
//

#ifndef sec_SOSPeerInfoInternal_h
#define sec_SOSPeerInfoInternal_h

CFStringRef kPIUserDefinedDeviceName;
CFStringRef kPIDeviceModelName;


#endif
