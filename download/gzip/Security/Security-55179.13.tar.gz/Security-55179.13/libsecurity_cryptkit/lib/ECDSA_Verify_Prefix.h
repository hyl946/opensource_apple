/*
 * Prefix file for ECDSA Verify build.
 *
 * This symbol disables features not needed for ECDSA verify.
 */
#define ECDSA_VERIFY_ONLY	1
