//
//  HIDDisplayPrivate.h
//  IOHIDFamily
//
//  Created by AB on 1/16/19.
//

#ifndef HIDDisplayPrivate_h
#define HIDDisplayPrivate_h

#import <os/log.h>

os_log_t HIDDisplayLog (void);

#endif /* HIDDisplayPrivate_h */
