//
//  HIDDisplay.h
//  HIDDisplay
//
//  Created by AB on 1/10/19.
//

#import <Foundation/Foundation.h>


FOUNDATION_EXPORT double HIDDisplayVersionNumber;
FOUNDATION_EXPORT const unsigned char HIDDisplayVersionString[];


#import <HIDDisplay/HIDDisplayCAPI.h>
#import <HIDDisplay/HIDDisplayIOReportingCAPI.h>

