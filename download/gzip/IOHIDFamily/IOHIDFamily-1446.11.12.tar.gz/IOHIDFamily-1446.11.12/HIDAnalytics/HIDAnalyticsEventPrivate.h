//
//  HIDAnalyticsEventPrivate.h
//  IOHIDFamily
//
//  Created by AB on 5/1/19.
//



#import "HIDAnalyticsEvent.h"

@interface HIDAnalyticsEvent (HIDAnalyticsEventPrivate)

@property(nullable) id value;

@end

