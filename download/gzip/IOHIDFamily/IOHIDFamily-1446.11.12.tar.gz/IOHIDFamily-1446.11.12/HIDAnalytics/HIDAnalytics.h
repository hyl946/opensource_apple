//
//  HIDAnalytics.h
//  HIDAnalytics
//
//  Created by AB on 11/26/18.
//

#import <Foundation/Foundation.h>


FOUNDATION_EXPORT double HIDAnalyticsVersionNumber;
FOUNDATION_EXPORT const unsigned char HIDAnalyticsVersionString[];


#import <HIDAnalytics/HIDAnalyticsCAPI.h>
#import <HIDAnalytics/HIDAnalyticsEvent.h>
