//
//  RemoteHIDPrivate.h
//  IOHIDFamily
//
//  Created by yg on 2/8/18.
//

#ifndef RemoteHIDPrivate_h
#define RemoteHIDPrivate_h

#import <os/log.h>

os_log_t RemoteHIDLog (void);
os_log_t RemoteHIDLogPackets (void);

#endif /* RemoteHIDPrivate_h */
