//
//  RemoteHID.h
//  RemoteHID
//
//  Created by yg on 1/14/18.
//

#import <Foundation/Foundation.h>

//! Project version number for RemoteHID.
FOUNDATION_EXPORT double RemoteHIDVersionNumber;

//! Project version string for RemoteHID.
FOUNDATION_EXPORT const unsigned char RemoteHIDVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <RemoteHID/PublicHeader.h>

#import  <RemoteHID/HIDRemoteDeviceServer.h>
#import  <RemoteHID/HIDRemoteSimpleProtocol.h>
#import  <RemoteHID/HIDRemoteDeviceAACPServer.h>

