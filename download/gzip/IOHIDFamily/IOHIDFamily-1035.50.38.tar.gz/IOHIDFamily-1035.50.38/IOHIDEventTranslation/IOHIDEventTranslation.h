//
//  IOHIDEventTranslation.h
//  IOHIDEventTranslation
//
//  Created by yg on 12/4/15.
//
//

#include "IOHIDKeyboardEventTranslation.h"
#include "IOHIDPointerEventTranslation.h"


//! Project version number for IOHIDEventTranslation.
//FOUNDATION_EXPORT double IOHIDEventTranslationVersionNumber;

//! Project version string for IOHIDEventTranslation.
//FOUNDATION_EXPORT const unsigned char IOHIDEventTranslationVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <IOHIDEventTranslation/PublicHeader.h>




