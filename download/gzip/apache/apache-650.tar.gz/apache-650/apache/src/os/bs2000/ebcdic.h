#ifndef EBCDIC_H
#define EBCDIC_H  "$Id: ebcdic.h,v 1.1.1.4 2001/07/18 23:44:57 zarzycki Exp $"

#include <ap_ebcdic.h>

#endif /*EBCDIC_H*/
