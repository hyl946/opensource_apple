#ifndef EBCDIC_H
#define EBCDIC_H  "$Id: ebcdic.h,v 1.1.1.2 2001/07/18 23:45:01 zarzycki Exp $"

#include <ap_ebcdic.h>

#endif /*EBCDIC_H*/
