#ifndef EBCDIC_H
#define EBCDIC_H  "$Id: ebcdic.h,v 1.1.1.3 2001/07/18 23:45:02 zarzycki Exp $"

#include <ap_ebcdic.h>

#endif /*EBCDIC_H*/
