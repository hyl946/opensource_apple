int mpe_dl_stub(void) { return 0; };
