/*
 * Copyright (C) 2010 Nokia Corporation and/or its subsidiary(-ies).
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public License
 * along with this library; see the file COPYING.LIB.  If not, write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
 * Boston, MA 02110-1301, USA.
 *
 */

#ifndef AccessibilityProgressIndicator_h
#define AccessibilityProgressIndicator_h

#include "AccessibilityRenderObject.h"

namespace WebCore {

#if ENABLE(METER_ELEMENT)
class HTMLMeterElement;
class RenderMeter;
#endif

class HTMLProgressElement;
class RenderProgress;
    
class AccessibilityProgressIndicator final : public AccessibilityRenderObject {
public:
    static Ref<AccessibilityProgressIndicator> create(RenderProgress*);
#if ENABLE(METER_ELEMENT)
    static Ref<AccessibilityProgressIndicator> create(RenderMeter*);
#endif
    Element* element() const override;

private:
    AccessibilityRole roleValue() const override { return ProgressIndicatorRole; }

    bool isProgressIndicator() const override { return true; }

    String valueDescription() const override;
    float valueForRange() const override;
    float maxValueForRange() const override;
    float minValueForRange() const override;

    explicit AccessibilityProgressIndicator(RenderProgress*);
    HTMLProgressElement* progressElement() const;

#if ENABLE(METER_ELEMENT)
    explicit AccessibilityProgressIndicator(RenderMeter*);
    HTMLMeterElement* meterElement() const;
#endif
    
    bool computeAccessibilityIsIgnored() const override;
};


} // namespace WebCore

#endif // AccessibilityProgressIndicator_h
