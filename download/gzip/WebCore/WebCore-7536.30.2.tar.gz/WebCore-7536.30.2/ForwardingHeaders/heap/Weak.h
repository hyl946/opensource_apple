#ifndef WebCore_FWD_Weak_h
#define WebCore_FWD_Weak_h
#include <JavaScriptCore/Weak.h>
#endif
