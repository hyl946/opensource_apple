#ifndef WebCore_FWD_InternalFunction_h
#define WebCore_FWD_InternalFunction_h
#include <JavaScriptCore/InternalFunction.h>
#endif
