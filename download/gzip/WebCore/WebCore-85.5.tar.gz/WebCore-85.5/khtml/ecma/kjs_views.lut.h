/* Automatically generated from kjs_views.cpp using ../../../JavaScriptCore/kjs/create_hash_table. DO NOT EDIT ! */

namespace KJS {

const struct HashEntry DOMAbstractViewTableEntries[] = {
   { "getComputedStyle", DOMAbstractView::GetComputedStyle, DontDelete|Function, 2, 0 },
   { "document", DOMAbstractView::Document, DontDelete|ReadOnly, 0, 0 }
};

const struct HashTable DOMAbstractViewTable = { 2, 2, DOMAbstractViewTableEntries, 2 };

}; // namespace
