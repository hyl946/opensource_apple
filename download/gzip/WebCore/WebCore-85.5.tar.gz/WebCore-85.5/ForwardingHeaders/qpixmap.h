#include "KWQPixmap.h"
