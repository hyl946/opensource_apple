#include "KWQKStaticDeleter.h"
