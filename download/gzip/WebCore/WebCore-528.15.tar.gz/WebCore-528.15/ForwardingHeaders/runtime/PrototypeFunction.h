#include <JavaScriptCore/PrototypeFunction.h>
