#ifndef WebCore_FWD_JSCell_h
#define WebCore_FWD_JSCell_h
#include <JavaScriptCore/JSCell.h>
#endif
