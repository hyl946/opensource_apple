#ifndef WebCore_FWD_Structure_h
#define WebCore_FWD_Structure_h
#include <JavaScriptCore/Structure.h>
#endif
