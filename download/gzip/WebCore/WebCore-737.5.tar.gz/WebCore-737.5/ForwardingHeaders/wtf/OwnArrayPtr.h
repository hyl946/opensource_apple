#ifndef WebCore_FWD_OwnArrayPtr_h
#define WebCore_FWD_OwnArrayPtr_h
#include <JavaScriptCore/OwnArrayPtr.h>
#endif
