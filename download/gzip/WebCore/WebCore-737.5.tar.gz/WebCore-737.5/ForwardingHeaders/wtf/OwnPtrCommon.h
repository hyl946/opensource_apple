#ifndef WebCore_FWD_PassOwnPtr_h
#define WebCore_FWD_PassOwnPtr_h
#include <JavaScriptCore/PassOwnPtr.h>
#endif
