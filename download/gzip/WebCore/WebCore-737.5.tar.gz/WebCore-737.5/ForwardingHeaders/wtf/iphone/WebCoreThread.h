#ifndef WebCore_FWD_WebCoreThread_h
#define WebCore_FWD_WebCoreThread_h
#include <JavaScriptCore/WebCoreThread.h>
#endif
