#ifndef WebCore_FWD_ValueCheck_h
#define WebCore_FWD_ValueCheck_h
#include <JavaScriptCore/ValueCheck.h>
#endif
