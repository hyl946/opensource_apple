#ifndef WebCore_FWD_TypeTraits_h
#define WebCore_FWD_TypeTraits_h
#include <JavaScriptCore/TypeTraits.h>
#endif
