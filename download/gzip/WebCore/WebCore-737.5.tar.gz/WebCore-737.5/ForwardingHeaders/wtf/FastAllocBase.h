#ifndef WebCore_FWD_FastAllocBase_h
#define WebCore_FWD_FastAllocBase_h
#include <JavaScriptCore/FastAllocBase.h>
#endif
