#ifndef WebCore_FWD_PtrAndFlags_h
#define WebCore_FWD_PtrAndFlags_h
#include <JavaScriptCore/PtrAndFlags.h>
#endif

