#ifndef WebCore_FWD_OwnPtr_h
#define WebCore_FWD_OwnPtr_h
#include <JavaScriptCore/OwnPtr.h>
#endif
