#ifndef WebCore_FWD_Platform_h
#define WebCore_FWD_Platform_h
#include <JavaScriptCore/Platform.h>
#endif
