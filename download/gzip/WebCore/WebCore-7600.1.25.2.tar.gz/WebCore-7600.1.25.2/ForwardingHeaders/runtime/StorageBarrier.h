#ifndef WebCore_FWD_StorageBarrier_h
#define WebCore_FWD_StorageBarrier_h
#include <JavaScriptCore/StorageBarrier.h>
#endif
