#ifndef WebCore_FWD_JSFunction_h
#define WebCore_FWD_JSFunction_h
#include <JavaScriptCore/JSFunction.h>
#endif
