#ifndef WebCore_FWD_Float32Array_h
#define WebCore_FWD_Float32Array_h
#include <JavaScriptCore/Float32Array.h>
#endif
