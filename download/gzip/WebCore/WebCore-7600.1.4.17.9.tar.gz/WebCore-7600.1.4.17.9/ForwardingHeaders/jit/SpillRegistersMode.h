#ifndef WebCore_FWD_JITCode_h
#define WebCore_FWD_JITCode_h
#include <JavaScriptCore/SpillRegistersMode.h>
#endif
