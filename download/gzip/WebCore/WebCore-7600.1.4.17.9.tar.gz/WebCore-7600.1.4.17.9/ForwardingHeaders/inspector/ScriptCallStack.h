#ifndef WebCore_FWD_ScriptCallStack_h
#define WebCore_FWD_ScriptCallStack_h
#include <JavaScriptCore/ScriptCallStack.h>
#endif
