#ifndef WebCore_FWD_ObjectPrototype_h
#define WebCore_FWD_ObjectPrototype_h
#include <JavaScriptCore/ObjectPrototype.h>
#endif
