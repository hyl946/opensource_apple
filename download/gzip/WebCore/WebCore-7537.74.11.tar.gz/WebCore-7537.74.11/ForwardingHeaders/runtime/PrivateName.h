#ifndef WebCore_FWD_PrivateName_h
#define WebCore_FWD_PrivateName_h
#include <JavaScriptCore/PrivateName.h>
#endif
