#ifndef WebCore_FWD_DebuggerActivation_h
#define WebCore_FWD_DebuggerActivation_h
#include <JavaScriptCore/DebuggerActivation.h>
#endif
