#ifndef WebCore_FWD_SourceProviderCache_h
#define WebCore_FWD_SourceProviderCache_h
#include <JavaScriptCore/SourceProviderCache.h>
#endif
