#ifndef WebCore_FWD_StructureChain_h
#define WebCore_FWD_StructureChain_h
#include <JavaScriptCore/StructureChain.h>
#endif

