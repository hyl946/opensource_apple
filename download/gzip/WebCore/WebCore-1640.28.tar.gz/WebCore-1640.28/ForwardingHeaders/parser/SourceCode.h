#ifndef WebCore_FWD_SourceCode_h
#define WebCore_FWD_SourceCode_h
#include <JavaScriptCore/SourceCode.h>
#endif
