#ifndef WebCore_FWD_Yarr_h
#define WebCore_FWD_Yarr_h
#include <JavaScriptCore/Yarr.h>
#endif

