#ifndef WebCore_FWD_ConsoleMessage_h
#define WebCore_FWD_ConsoleMessage_h
#include <JavaScriptCore/ConsoleMessage.h>
#endif
