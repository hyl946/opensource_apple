#ifndef WebCore_FWD_CodeBlock_h
#define WebCore_FWD_CodeBlock_h
#include <JavaScriptCore/CodeBlock.h>
#endif
