#ifndef WebCore_FWD_JSProxy_h
#define WebCore_FWD_JSProxy_h
#include <JavaScriptCore/JSProxy.h>
#endif
