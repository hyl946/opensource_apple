#ifndef WebCore_FWD_EncodedValue_h
#define WebCore_FWD_EncodedValue_h
#include <JavaScriptCore/EncodedValue.h>
#endif
