#ifndef WebCore_FWD_MapDataInliines_h
#define WebCore_FWD_MapDataInliines_h
#include <JavaScriptCore/MapDataInlines.h>
#endif
