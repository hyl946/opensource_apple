#ifndef WebCore_FWD_ErrorHandlingScope_h
#define WebCore_FWD_ErrorHandlingScope_h
#include <JavaScriptCore/ErrorHandlingScope.h>
#endif
