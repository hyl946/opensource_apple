#ifndef WebCore_FWD_YarrPattern_h
#define WebCore_FWD_YarrPattern_h
#include <JavaScriptCore/YarrPattern.h>
#endif

