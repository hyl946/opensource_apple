#ifndef WebCore_FWD_InspectorRuntimeAgent_h
#define WebCore_FWD_InspectorRuntimeAgent_h
#include <JavaScriptCore/InspectorRuntimeAgent.h>
#endif
