#ifndef WebCore_FWD_Uint8Array_h
#define WebCore_FWD_Uint8Array_h
#include <JavaScriptCore/Uint8Array.h>
#endif
