#ifndef WebCore_FWD_JSCJSValueInlines_h
#define WebCore_FWD_JSCJSValueInlines_h
#include <JavaScriptCore/JSCJSValueInlines.h>
#endif
