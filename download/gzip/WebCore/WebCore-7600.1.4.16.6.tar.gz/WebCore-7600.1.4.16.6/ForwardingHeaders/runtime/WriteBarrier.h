#ifndef WebCore_FWD_WriteBarrier_h
#define WebCore_FWD_WriteBarrier_h
#include <JavaScriptCore/WriteBarrier.h>
#endif
