#ifndef WebCore_FWD_JSAPIValueWrapper_h
#define WebCore_FWD_JSAPIValueWrapper_h
#include <JavaScriptCore/JSAPIValueWrapper.h>
#endif
