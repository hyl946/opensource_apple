#ifndef WebCore_FWD_Uint32Array_h
#define WebCore_FWD_Uint32Array_h
#include <JavaScriptCore/Uint32Array.h>
#endif
