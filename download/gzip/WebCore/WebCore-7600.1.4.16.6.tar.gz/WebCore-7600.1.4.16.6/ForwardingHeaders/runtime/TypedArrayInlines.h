#ifndef WebCore_FWD_TypedArrayInliness_h
#define WebCore_FWD_TypedArrayInliness_h
#include <JavaScriptCore/TypedArrayInlines.h>
#endif
