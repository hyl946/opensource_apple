#ifndef WebCore_FWD_Int32Array_h
#define WebCore_FWD_Int32Array_h
#include <JavaScriptCore/Int32Array.h>
#endif
