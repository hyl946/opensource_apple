#ifndef WebCore_FWD_ScriptCallFrame_h
#define WebCore_FWD_ScriptCallFrame_h
#include <JavaScriptCore/ScriptCallFrame.h>
#endif
