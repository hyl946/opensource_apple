#ifndef WebCore_FWD_RegularExpression_h
#define WebCore_FWD_RegularExpression_h
#include <JavaScriptCore/RegularExpression.h>
#endif
