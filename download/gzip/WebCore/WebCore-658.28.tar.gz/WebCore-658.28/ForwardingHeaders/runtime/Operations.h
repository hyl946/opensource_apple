#ifndef WebCore_FWD_Operations_h
#define WebCore_FWD_Operations_h
#include <JavaScriptCore/Operations.h>
#endif
