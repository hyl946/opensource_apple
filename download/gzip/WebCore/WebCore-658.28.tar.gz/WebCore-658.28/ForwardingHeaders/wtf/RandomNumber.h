#ifndef WebCore_FWD_RandomNumber_h
#define WebCore_FWD_RandomNumber_h
#include <JavaScriptCore/RandomNumber.h>
#endif

