#ifndef WebCore_FWD_Parser_h
#define WebCore_FWD_Parser_h
#include <JavaScriptCore/Parser.h>
#endif
