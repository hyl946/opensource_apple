#ifndef WebCore_FWD_Profiler_h
#define WebCore_FWD_Profiler_h
#include <JavaScriptCore/Profiler.h>
#endif

