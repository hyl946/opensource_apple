#ifndef WebCore_FWD_Profile_h
#define WebCore_FWD_Profile_h
#include <JavaScriptCore/Profile.h>
#endif

