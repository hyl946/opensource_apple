#import "KWQKStaticDeleter.h"
