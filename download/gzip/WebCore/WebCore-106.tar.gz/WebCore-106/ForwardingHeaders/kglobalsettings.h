#include "KWQKGlobalSettings.h"
