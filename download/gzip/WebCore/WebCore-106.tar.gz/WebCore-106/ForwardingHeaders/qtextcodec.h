#include "KWQTextCodec.h"
