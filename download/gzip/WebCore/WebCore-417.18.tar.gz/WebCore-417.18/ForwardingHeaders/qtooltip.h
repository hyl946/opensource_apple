#define QT_NO_TOOLTIP
