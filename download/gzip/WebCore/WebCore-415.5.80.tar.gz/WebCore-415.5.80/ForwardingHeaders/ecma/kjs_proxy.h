#import <kjs_proxy.h>
