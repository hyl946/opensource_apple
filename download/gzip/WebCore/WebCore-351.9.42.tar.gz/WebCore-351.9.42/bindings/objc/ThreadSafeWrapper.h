//
//  WebThreadSafeWrapper.h
//  WebCore
//
//  Copyright (C) 2006, 2007, Apple Inc.  All rights reserved.
//

#define USE_THREADSADE_NODES 0

