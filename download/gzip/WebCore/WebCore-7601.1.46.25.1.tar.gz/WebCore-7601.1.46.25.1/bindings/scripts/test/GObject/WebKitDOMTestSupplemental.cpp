/*
    This file is generated just to tell build scripts that WebKitDOMTestSupplemental.h and
    WebKitDOMTestSupplemental.cpp are created for TestSupplemental.idl, and thus
    prevent the build scripts from trying to generate WebKitDOMTestSupplemental.h and
    WebKitDOMTestSupplemental.cpp at every build. This file must not be tried to compile.
*/
