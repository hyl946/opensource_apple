#ifndef WebCore_FWD_ScriptArguments_h
#define WebCore_FWD_ScriptArguments_h
#include <JavaScriptCore/ScriptArguments.h>
#endif
