#ifndef WebCore_FWD_Heap_h
#define WebCore_FWD_Heap_h
#include <JavaScriptCore/Heap.h>
#endif
