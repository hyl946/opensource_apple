#ifndef WebCore_FWD_PropertyNameArray_h
#define WebCore_FWD_PropertyNameArray_h
#include <JavaScriptCore/PropertyNameArray.h>
#endif

