#ifndef WebCore_FWD_JSObject_h
#define WebCore_FWD_JSObject_h
#include <JavaScriptCore/JSObject.h>
#endif
