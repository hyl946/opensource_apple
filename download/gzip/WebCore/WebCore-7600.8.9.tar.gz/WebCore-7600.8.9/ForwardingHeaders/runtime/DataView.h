#ifndef WebCore_FWD_DataView_h
#define WebCore_FWD_DataView_h
#include <JavaScriptCore/DataView.h>
#endif
