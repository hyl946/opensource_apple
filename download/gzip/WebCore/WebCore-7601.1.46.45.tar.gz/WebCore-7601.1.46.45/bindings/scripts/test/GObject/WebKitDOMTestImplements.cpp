/*
    This file is generated just to tell build scripts that WebKitDOMTestImplements.h and
    WebKitDOMTestImplements.cpp are created for TestImplements.idl, and thus
    prevent the build scripts from trying to generate WebKitDOMTestImplements.h and
    WebKitDOMTestImplements.cpp at every build. This file must not be tried to compile.
*/
