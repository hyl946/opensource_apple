#include <JavaScriptCore/StringPrototype.h>
