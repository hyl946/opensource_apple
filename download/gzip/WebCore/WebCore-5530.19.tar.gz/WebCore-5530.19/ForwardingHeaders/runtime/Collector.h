#ifndef WebCore_FWD_Collector_h
#define WebCore_FWD_Collector_h
#include <JavaScriptCore/Collector.h>
#endif
