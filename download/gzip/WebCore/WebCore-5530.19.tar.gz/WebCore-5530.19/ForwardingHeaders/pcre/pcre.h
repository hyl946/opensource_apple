#ifndef WebCore_FWD_pcre_h
#define WebCore_FWD_pcre_h
#include <JavaScriptCore/pcre.h>
#endif

