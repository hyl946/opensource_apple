#ifndef WebCore_FWD_UnicodeIcu_h
#define WebCore_FWD_UnicodeIcu_h
#include <JavaScriptCore/UnicodeIcu.h>
#endif
