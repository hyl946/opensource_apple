#ifndef WebCore_FWD_HashCountedSet_h
#define WebCore_FWD_HashCountedSet_h
#include <JavaScriptCore/HashCountedSet.h>
#endif
