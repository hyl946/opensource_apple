#ifndef WebCore_FWD_HashTable_h
#define WebCore_FWD_HashTable_h
#include <JavaScriptCore/HashTable.h>
#endif
