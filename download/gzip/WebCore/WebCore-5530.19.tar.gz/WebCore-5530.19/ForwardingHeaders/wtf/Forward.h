#ifndef WebCore_FWD_Forward_h
#define WebCore_FWD_Forward_h
#include <JavaScriptCore/Forward.h>
#endif
