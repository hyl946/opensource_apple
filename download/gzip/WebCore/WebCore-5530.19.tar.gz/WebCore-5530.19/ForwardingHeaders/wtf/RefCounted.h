#ifndef WebCore_FWD_RefCounted_h
#define WebCore_FWD_RefCounted_h
#include <JavaScriptCore/RefCounted.h>
#endif
