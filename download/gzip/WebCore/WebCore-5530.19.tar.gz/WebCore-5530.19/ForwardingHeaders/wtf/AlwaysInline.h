#ifndef WebCore_FWD_AlwaysInline_h
#define WebCore_FWD_AlwaysInline_h
#include <JavaScriptCore/AlwaysInline.h>
#endif
