#ifndef WebCore_FWD_Locker_h
#define WebCore_FWD_Locker_h
#include <JavaScriptCore/Locker.h>
#endif
