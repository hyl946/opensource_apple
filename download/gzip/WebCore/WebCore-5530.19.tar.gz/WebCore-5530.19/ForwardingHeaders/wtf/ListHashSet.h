#ifndef WebCore_FWD_ListHashSet_h
#define WebCore_FWD_ListHashSet_h
#include <JavaScriptCore/ListHashSet.h>
#endif
