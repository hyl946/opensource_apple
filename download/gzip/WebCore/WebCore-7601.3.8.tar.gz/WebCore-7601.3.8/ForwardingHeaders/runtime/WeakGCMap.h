#ifndef WebCore_FWD_WeakGCMap_h
#define WebCore_FWD_WeakGCMap_h
#include <JavaScriptCore/WeakGCMap.h>
#endif
