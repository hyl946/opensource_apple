#ifndef WebCore_FWD_IteratorOperations_h
#define WebCore_FWD_IteratorOperations_h
#include <JavaScriptCore/IteratorOperations.h>
#endif
