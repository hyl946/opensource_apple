#ifndef WebCore_FWD_Microtask_h
#define WebCore_FWD_Microtask_h
#include <JavaScriptCore/Microtask.h>
#endif
