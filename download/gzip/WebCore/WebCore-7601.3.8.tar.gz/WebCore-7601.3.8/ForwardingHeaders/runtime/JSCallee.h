#ifndef WebCore_FWD_JSCallee_h
#define WebCore_FWD_JSCallee_h
#include <JavaScriptCore/JSCallee.h>
#endif
