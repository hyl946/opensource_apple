#ifndef WebCore_FWD_JSMapIterator_h
#define WebCore_FWD_JSMapIterator_h
#include <JavaScriptCore/JSMapIterator.h>
#endif
