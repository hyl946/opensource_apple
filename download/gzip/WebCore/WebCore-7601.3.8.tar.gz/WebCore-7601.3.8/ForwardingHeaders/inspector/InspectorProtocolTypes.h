#ifndef WebCore_FWD_InspectorProtocolTypes_h
#define WebCore_FWD_InspectorProtocolTypes_h
#include <JavaScriptCore/InspectorProtocolTypes.h>
#endif
