#include <xbl_binding_manager.h>

