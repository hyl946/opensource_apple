#include "KWQPalette.h"
