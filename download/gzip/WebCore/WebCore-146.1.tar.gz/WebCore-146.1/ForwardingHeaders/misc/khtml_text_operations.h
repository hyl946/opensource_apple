#include <khtml_text_operations.h>
