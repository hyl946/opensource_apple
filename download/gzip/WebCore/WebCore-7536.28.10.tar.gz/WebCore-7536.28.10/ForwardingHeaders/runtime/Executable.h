#ifndef WebCore_FWD_Executable_h
#define WebCore_FWD_Executable_h
#include <JavaScriptCore/Executable.h>
#endif
