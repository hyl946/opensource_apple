#ifndef WebCore_FWD_ArgList_h
#define WebCore_FWD_ArgList_h
#include <JavaScriptCore/ArgList.h>
#endif
