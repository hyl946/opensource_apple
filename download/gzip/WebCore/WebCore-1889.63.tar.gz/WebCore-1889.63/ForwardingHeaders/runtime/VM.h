#ifndef WebCore_FWD_VM_h
#define WebCore_FWD_VM_h
#include <JavaScriptCore/VM.h>
#endif
