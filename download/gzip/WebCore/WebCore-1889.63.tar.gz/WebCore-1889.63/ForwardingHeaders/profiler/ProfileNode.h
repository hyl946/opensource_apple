#ifndef WebCore_FWD_ProfileNode_h
#define WebCore_FWD_ProfileNode_h
#include <JavaScriptCore/ProfileNode.h>
#endif

