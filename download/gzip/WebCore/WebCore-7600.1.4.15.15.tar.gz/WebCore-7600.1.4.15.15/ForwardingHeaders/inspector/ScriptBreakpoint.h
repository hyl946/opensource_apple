#ifndef WebCore_FWD_ScriptBreakpoint_h
#define WebCore_FWD_ScriptBreakpoint_h
#include <JavaScriptCore/ScriptBreakpoint.h>
#endif
