#ifndef WebCore_FWD_Float64Array_h
#define WebCore_FWD_Float64Array_h
#include <JavaScriptCore/Float64Array.h>
#endif
