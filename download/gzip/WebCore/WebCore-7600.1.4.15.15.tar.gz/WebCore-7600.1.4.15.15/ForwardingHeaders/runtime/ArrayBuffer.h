#ifndef WebCore_FWD_ArrayBuffer_h
#define WebCore_FWD_ArrayBuffer_h
#include <JavaScriptCore/ArrayBuffer.h>
#endif
