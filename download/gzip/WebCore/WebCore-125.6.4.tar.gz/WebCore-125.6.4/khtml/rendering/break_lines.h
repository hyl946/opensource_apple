#include <qstring.h>

namespace khtml {
    bool isBreakable( const QChar *str, int pos, int len );
};
