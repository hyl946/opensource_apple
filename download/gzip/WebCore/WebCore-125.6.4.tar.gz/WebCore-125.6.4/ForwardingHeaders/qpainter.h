#include "KWQPainter.h"
