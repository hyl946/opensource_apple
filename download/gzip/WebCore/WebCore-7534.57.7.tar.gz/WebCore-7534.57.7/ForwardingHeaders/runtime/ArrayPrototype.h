#ifndef WebCore_FWD_ArrayPrototype_h
#define WebCore_FWD_ArrayPrototype_h
#include <JavaScriptCore/ArrayPrototype.h>
#endif
