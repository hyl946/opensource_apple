#ifndef WebCore_FWD_Complex_h
#define WebCore_FWD_Complex_h
#include <JavaScriptCore/Complex.h>
#endif
