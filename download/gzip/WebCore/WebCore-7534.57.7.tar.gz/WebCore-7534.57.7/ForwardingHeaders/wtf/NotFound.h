#ifndef WebCore_FWD_NotFound_h
#define WebCore_FWD_NotFound_h
#include <JavaScriptCore/NotFound.h>
#endif
