#ifndef WebCore_FWD_PossiblyNull_h
#define WebCore_FWD_PossiblyNull_h
#include <JavaScriptCore/PossiblyNull.h>
#endif
