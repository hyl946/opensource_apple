#ifndef WebCore_FWD_ThreadingPrimitives_h
#define WebCore_FWD_ThreadingPrimitives_h
#include <JavaScriptCore/ThreadingPrimitives.h>
#endif
