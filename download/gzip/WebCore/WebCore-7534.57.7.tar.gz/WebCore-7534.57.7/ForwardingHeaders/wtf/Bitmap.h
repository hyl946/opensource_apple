#ifndef WebCore_FWD_Bitmap_h
#define WebCore_FWD_Bitmap_h
#include <JavaScriptCore/Bitmap.h>
#endif
