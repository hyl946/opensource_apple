#ifndef WebCore_FWD_double_conversion_h
#define WebCore_FWD_double_conversion_h
#include <JavaScriptCore/double-conversion.h>
#endif
