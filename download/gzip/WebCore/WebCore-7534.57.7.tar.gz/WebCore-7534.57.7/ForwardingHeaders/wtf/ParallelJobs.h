#ifndef WebCore_FWD_ParallelJobs_h
#define WebCore_FWD_ParallelJobs_h
#include <JavaScriptCore/ParallelJobs.h>
#endif
