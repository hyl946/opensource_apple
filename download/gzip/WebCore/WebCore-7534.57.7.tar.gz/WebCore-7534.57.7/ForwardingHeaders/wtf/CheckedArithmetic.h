#ifndef WebCore_FWD_CheckedArithmetic_h
#define WebCore_FWD_CheckedArithmetic_h
#include <JavaScriptCore/CheckedArithmetic.h>
#endif
