#ifndef WebCore_FWD_StackBounds_h
#define WebCore_FWD_StackBounds_h
#include <JavaScriptCore/StackBounds.h>
#endif
