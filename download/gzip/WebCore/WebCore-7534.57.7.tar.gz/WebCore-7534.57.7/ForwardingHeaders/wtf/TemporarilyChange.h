#ifndef WebCore_FWD_TemporarilyChange_h
#define WebCore_FWD_TemporarilyChange_h
#include <JavaScriptCore/TemporarilyChange.h>
#endif
