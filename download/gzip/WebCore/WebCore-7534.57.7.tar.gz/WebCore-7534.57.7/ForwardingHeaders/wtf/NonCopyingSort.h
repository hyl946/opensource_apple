#ifndef WebCore_FWD_NonCopyingSort_h
#define WebCore_FWD_NonCopyingSort_h
#include <JavaScriptCore/NonCopyingSort.h>
#endif
