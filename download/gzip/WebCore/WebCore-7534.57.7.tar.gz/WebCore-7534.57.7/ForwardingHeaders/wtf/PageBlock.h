#ifndef WebCore_FWD_PageBlock_h
#define WebCore_FWD_PageBlock_h
#include <JavaScriptCore/PageBlock.h>
#endif
