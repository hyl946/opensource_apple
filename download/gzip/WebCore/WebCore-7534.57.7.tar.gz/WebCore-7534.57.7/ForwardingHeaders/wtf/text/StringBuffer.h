#ifndef WebCore_FWD_StringBuffer_h
#define WebCore_FWD_StringBuffer_h
#include <JavaScriptCore/StringBuffer.h>
#endif
