#ifndef WebCore_FWD_TextPosition_h
#define WebCore_FWD_TextPosition_h
#include <JavaScriptCore/TextPosition.h>
#endif
