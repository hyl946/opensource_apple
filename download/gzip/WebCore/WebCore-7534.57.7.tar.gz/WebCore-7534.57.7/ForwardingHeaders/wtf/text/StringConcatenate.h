#ifndef WebCore_FWD_StringConcatenate_h
#define WebCore_FWD_StringConcatenate_h
#include <JavaScriptCore/StringConcatenate.h>
#endif
