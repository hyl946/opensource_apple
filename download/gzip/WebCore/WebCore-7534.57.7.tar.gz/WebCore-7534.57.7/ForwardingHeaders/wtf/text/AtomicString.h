#ifndef WebCore_FWD_AtomicString_h
#define WebCore_FWD_AtomicString_h
#include <JavaScriptCore/AtomicString.h>
#endif
