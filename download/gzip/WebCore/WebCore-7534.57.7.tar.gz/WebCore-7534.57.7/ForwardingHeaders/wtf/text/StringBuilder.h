#ifndef WebCore_FWD_StringBuilder_h
#define WebCore_FWD_StringBuilder_h
#include <JavaScriptCore/StringBuilder.h>
#endif
