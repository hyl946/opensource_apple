#ifndef WebCore_FWD_AtomicStringImpl_h
#define WebCore_FWD_AtomicStringImpl_h
#include <JavaScriptCore/AtomicStringImpl.h>
#endif
