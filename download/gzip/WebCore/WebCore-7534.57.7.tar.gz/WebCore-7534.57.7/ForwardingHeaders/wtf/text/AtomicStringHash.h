#ifndef WebCore_FWD_AtomicStringHash_h
#define WebCore_FWD_AtomicStringHash_h
#include <JavaScriptCore/AtomicStringHash.h>
#endif
