#ifndef WebCore_FWD_PageAllocationAligned_h
#define WebCore_FWD_PageAllocationAligned_h
#include <JavaScriptCore/PageAllocationAligned.h>
#endif
