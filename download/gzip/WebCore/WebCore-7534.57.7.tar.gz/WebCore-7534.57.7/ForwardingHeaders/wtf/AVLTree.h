#ifndef WebCore_FWD_AVLTree_h
#define WebCore_FWD_AVLTree_h
#include <JavaScriptCore/AVLTree.h>
#endif
