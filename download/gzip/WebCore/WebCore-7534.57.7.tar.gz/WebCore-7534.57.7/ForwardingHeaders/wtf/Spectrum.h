#include <JavaScriptCore/Spectrum.h>
