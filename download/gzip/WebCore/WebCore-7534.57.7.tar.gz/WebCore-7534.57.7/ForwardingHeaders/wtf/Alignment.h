#ifndef WebCore_FWD_Alignment_h
#define WebCore_FWD_Alignment_h
#include <JavaScriptCore/Alignment.h>
#endif
