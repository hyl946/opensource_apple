#ifndef WebCore_FWD_BloomFilter_h
#define WebCore_FWD_BloomFilter_h
#include <JavaScriptCore/BloomFilter.h>
#endif
