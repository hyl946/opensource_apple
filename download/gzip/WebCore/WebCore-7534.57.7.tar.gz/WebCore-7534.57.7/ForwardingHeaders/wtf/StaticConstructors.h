#ifndef WebCore_FWD_StaticConstructors_h
#define WebCore_FWD_StaticConstructors_h
#include <JavaScriptCore/StaticConstructors.h>
#endif
