#ifndef WebCore_FWD_Int8Array_h
#define WebCore_FWD_Int8Array_h
#include <JavaScriptCore/Int8Array.h>
#endif
