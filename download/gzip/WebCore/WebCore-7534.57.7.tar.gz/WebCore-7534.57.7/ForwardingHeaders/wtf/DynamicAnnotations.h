#ifndef WebCore_FWD_DynamicAnnotations_h
#define WebCore_FWD_DynamicAnnotations_h
#include <JavaScriptCore/DynamicAnnotations.h>
#endif
