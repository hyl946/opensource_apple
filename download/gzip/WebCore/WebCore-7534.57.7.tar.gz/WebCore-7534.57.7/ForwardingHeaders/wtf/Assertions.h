#ifndef WebCore_FWD_Assertions_h
#define WebCore_FWD_Assertions_h
#include <JavaScriptCore/Assertions.h>
#endif
