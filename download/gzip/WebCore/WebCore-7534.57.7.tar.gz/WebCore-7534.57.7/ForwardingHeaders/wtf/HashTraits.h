#ifndef WebCore_FWD_HashTraits_h
#define WebCore_FWD_HashTraits_h
#include <JavaScriptCore/HashTraits.h>
#endif
