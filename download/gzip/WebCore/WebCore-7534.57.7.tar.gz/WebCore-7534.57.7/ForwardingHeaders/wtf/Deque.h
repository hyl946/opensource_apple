#ifndef WebCore_FWD_Deque_h
#define WebCore_FWD_Deque_h
#include <JavaScriptCore/Deque.h>
#endif
