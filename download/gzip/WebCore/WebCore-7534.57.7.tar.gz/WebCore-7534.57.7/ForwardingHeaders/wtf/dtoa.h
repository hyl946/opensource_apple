#ifndef WebCore_FWD_dtoa_h
#define WebCore_FWD_dtoa_h
#include <JavaScriptCore/dtoa.h>
#endif
