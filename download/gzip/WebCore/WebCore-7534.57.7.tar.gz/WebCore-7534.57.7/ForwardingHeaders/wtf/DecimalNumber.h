#ifndef WebCore_FWD_DecimalNumber_h
#define WebCore_FWD_DecimalNumber_h
#include <JavaScriptCore/DecimalNumber.h>
#endif
