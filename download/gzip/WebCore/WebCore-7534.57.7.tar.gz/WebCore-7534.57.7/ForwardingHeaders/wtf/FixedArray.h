#ifndef WebCore_FWD_FixedArray_h
#define WebCore_FWD_FixedArray_h
#include <JavaScriptCore/FixedArray.h>
#endif
