#ifndef WebCore_FWD_BumpPointerAllocator_h
#define WebCore_FWD_BumpPointerAllocator_h
#include <JavaScriptCore/BumpPointerAllocator.h>
#endif
