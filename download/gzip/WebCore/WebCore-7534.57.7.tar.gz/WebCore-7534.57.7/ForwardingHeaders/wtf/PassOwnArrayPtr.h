#ifndef WebCore_FWD_PassOwnArrayPtr_h
#define WebCore_FWD_PassOwnArrayPtr_h
#include <JavaScriptCore/PassOwnArrayPtr.h>
#endif
