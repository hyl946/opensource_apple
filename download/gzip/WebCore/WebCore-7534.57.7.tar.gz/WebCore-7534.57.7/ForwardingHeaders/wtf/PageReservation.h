#ifndef WebCore_FWD_PageReservation_h
#define WebCore_FWD_PageReservation_h
#include <JavaScriptCore/PageReservation.h>
#endif
