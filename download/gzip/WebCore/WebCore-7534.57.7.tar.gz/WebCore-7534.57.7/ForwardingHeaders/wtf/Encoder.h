#ifndef WebCore_FWD_Encoder_h
#define WebCore_FWD_Encoder_h
#include <JavaScriptCore/Encoder.h>
#endif
