#ifndef WebCore_FWD_StringHasher_h
#define WebCore_FWD_StringHasher_h
#include <JavaScriptCore/StringHasher.h>
#endif
