#ifndef WebCore_FWD_DoublyLinkedList_h
#define WebCore_FWD_DoublyLinkedList_h
#include <JavaScriptCore/DoublyLinkedList.h>
#endif
