#ifndef WebCore_FWD_Unicode_h
#define WebCore_FWD_Unicode_h
#include <JavaScriptCore/Unicode.h>
#endif
