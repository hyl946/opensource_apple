#ifndef WebCore_FWD_CharacterNames_h
#define WebCore_FWD_CharacterNames_h
#include <JavaScriptCore/CharacterNames.h>
#endif
