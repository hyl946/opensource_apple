#ifndef WebCore_FWD_UnicodeWince_h
#define WebCore_FWD_UnicodeWince_h
#include <JavaScriptCore/UnicodeWince.h>
#endif
