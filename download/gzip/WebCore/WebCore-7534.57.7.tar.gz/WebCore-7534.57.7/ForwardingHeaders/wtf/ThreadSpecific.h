#ifndef WebCore_FWD_ThreadSpecific_h
#define WebCore_FWD_ThreadSpecific_h
#include <JavaScriptCore/ThreadSpecific.h>
#endif
