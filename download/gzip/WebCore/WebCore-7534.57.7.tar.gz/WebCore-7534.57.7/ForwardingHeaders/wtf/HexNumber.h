#ifndef WebCore_FWD_HexNumber_h
#define WebCore_FWD_HexNumber_h
#include <JavaScriptCore/HexNumber.h>
#endif
