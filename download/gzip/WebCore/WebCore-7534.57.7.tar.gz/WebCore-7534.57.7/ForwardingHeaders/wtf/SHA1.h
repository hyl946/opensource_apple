#ifndef WebCore_FWD_SHA1_h
#define WebCore_FWD_SHA1_h
#include <JavaScriptCore/SHA1.h>
#endif
