#ifndef WebCore_FWD_Compiler_h
#define WebCore_FWD_Compiler_h
#include <JavaScriptCore/Compiler.h>
#endif
