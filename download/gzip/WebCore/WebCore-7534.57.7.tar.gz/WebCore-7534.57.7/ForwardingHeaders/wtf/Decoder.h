#ifndef WebCore_FWD_Decoder_h
#define WebCore_FWD_Decoder_h
#include <JavaScriptCore/Decoder.h>
#endif
