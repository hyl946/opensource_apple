#ifndef WebCore_FWD_DateMath_h
#define WebCore_FWD_DateMath_h
#include <JavaScriptCore/DateMath.h>
#endif
