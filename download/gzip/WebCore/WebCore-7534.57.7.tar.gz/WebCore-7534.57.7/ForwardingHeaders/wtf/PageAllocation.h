#ifndef WebCore_FWD_PageAllocation_h
#define WebCore_FWD_PageAllocation_h
#include <JavaScriptCore/PageAllocation.h>
#endif
