#ifndef WebCore_FWD_Functional_h
#define WebCore_FWD_Functional_h
#include <JavaScriptCore/Functional.h>
#endif
