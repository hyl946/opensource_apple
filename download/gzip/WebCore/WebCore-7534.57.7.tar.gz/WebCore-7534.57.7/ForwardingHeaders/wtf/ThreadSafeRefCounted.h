#ifndef WebCore_FWD_ThreadSafeRefCounted_h
#define WebCore_FWD_ThreadSafeRefCounted_h
#include <JavaScriptCore/ThreadSafeRefCounted.h>
#endif
