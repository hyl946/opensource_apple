#ifndef WebCore_FWD_ObjectConstructor_h
#define WebCore_FWD_ObjectConstructor_h
#include <JavaScriptCore/ObjectConstructor.h>
#endif
