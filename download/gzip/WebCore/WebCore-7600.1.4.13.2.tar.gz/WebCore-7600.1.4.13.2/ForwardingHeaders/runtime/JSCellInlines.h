#ifndef WebCore_FWD_JSCellInlines_h
#define WebCore_FWD_JSCellInlines_h
#include <JavaScriptCore/JSCellInlines.h>
#endif
