#ifndef WebCore_FWD_MatchResult_h
#define WebCore_FWD_MatchResult_h
#include <JavaScriptCore/MatchResult.h>
#endif
