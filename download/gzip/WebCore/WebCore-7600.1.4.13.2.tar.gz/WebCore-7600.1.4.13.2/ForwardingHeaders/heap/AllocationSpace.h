#ifndef WebCore_FWD_AllocationSpace_h
#define WebCore_FWD_AllocationSpace_h
#include <JavaScriptCore/AllocationSpace.h>
#endif
