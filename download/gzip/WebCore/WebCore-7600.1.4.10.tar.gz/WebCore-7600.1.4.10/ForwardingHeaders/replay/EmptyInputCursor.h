#ifndef WebCore_FWD_EmptyInputCursor_h
#define WebCore_FWD_EmptyInputCursor_h
#include <JavaScriptCore/EmptyInputCursor.h>
#endif
