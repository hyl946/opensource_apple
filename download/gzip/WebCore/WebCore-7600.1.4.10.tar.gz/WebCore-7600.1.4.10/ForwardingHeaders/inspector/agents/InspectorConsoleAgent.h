#ifndef WebCore_FWD_InspectorConsoleAgent_h
#define WebCore_FWD_InspectorConsoleAgent_h
#include <JavaScriptCore/InspectorConsoleAgent.h>
#endif
