#ifndef WebCore_FWD_StructureInlines_h
#define WebCore_FWD_StructureInlines_h
#include <JavaScriptCore/StructureInlines.h>
#endif
