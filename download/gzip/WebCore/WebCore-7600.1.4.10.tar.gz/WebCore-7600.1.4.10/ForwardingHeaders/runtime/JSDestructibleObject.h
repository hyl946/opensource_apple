#ifndef WebCore_FWD_JSDestructibleObject_h
#define WebCore_FWD_JSDestructibleObject_h
#include <JavaScriptCore/JSDestructibleObject.h>
#endif
