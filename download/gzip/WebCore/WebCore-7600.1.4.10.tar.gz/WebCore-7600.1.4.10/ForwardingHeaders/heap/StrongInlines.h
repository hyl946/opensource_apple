#ifndef WebCore_FWD_StrongInlines_h
#define WebCore_FWD_StrongInlines_h
#include <JavaScriptCore/StrongInlines.h>
#endif
