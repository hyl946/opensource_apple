#ifndef WebCore_FWD_JSArray_h
#define WebCore_FWD_JSArray_h
#include <JavaScriptCore/JSArray.h>
#endif
