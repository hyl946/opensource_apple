#ifndef WebCore_FWD_InspectorAgent_h
#define WebCore_FWD_InspectorAgent_h
#include <JavaScriptCore/InspectorAgent.h>
#endif
