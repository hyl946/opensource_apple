#ifndef WebCore_FWD_Uint16Array_h
#define WebCore_FWD_Uint16Array_h
#include <JavaScriptCore/Uint16Array.h>
#endif
