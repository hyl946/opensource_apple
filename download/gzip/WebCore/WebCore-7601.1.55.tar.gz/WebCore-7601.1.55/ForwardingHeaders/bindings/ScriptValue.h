#ifndef WebCore_FWD_ScriptValue_h
#define WebCore_FWD_ScriptValue_h
#include <JavaScriptCore/ScriptValue.h>
#endif
