#ifndef WebCore_FWD_ScriptDebugServer_h
#define WebCore_FWD_ScriptDebugServer_h
#include <JavaScriptCore/ScriptDebugServer.h>
#endif
