#ifndef WebCore_FWD_JSArrayBuffer_h
#define WebCore_FWD_JSArrayBuffer_h
#include <JavaScriptCore/JSArrayBuffer.h>
#endif
