#ifndef WebCore_FWD_JSGlobalObject_h
#define WebCore_FWD_JSGlobalObject_h
#include <JavaScriptCore/JSGlobalObject.h>
#endif
