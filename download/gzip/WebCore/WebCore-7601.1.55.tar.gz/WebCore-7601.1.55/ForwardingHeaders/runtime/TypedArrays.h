#ifndef WebCore_FWD_TypedArrays_h
#define WebCore_FWD_TypedArrays_h
#include <JavaScriptCore/TypedArrays.h>
#endif
