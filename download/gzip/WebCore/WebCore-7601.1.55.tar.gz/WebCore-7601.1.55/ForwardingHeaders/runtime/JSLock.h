#ifndef WebCore_FWD_JSLock_h
#define WebCore_FWD_JSLock_h
#include <JavaScriptCore/JSLock.h>
#endif
