#ifndef WebCore_FWD_JSTypedArrays_h
#define WebCore_FWD_JSTypedArrays_h
#include <JavaScriptCore/JSTypedArrays.h>
#endif
