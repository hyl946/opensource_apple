#ifndef WebCore_FWD_MapData_h
#define WebCore_FWD_MapData_h
#include <JavaScriptCore/MapData.h>
#endif
