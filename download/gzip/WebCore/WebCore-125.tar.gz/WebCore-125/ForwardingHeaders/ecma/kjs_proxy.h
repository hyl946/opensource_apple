#include <kjs_proxy.h>
