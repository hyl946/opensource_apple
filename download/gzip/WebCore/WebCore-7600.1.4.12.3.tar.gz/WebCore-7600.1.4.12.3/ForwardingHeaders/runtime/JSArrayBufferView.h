#ifndef WebCore_FWD_JSArrayBufferView_h
#define WebCore_FWD_JSArrayBufferView_h
#include <JavaScriptCore/JSArrayBufferView.h>
#endif
