#ifndef WebCore_FWD_StackVisitor_h
#define WebCore_FWD_StackVisitor_h
#include <JavaScriptCore/StackVisitor.h>
#endif
