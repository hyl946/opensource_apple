#ifndef WebCore_FWD_Uint8ClampedArray_h
#define WebCore_FWD_Uint8ClampedArray_h
#include <JavaScriptCore/Uint8ClampedArray.h>
#endif
