#ifndef WebCore_FWD_WeakGCMapInlines_h
#define WebCore_FWD_WeakGCMapInlines_h
#include <JavaScriptCore/WeakGCMapInlines.h>
#endif
