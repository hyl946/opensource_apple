#ifndef WebCore_FWD_InputCursor_h
#define WebCore_FWD_InputCursor_h
#include <JavaScriptCore/InputCursor.h>
#endif
