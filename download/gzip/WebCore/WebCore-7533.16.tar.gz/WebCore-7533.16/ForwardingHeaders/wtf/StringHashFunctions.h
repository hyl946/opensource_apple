#ifndef WebCore_FWD_StringHashFunctions_h
#define WebCore_FWD_StringHashFunctions_h
#include <JavaScriptCore/StringHashFunctions.h>
#endif
