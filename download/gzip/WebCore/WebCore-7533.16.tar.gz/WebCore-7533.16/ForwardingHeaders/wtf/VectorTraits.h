#ifndef WebCore_FWD_VectorTraits_h
#define WebCore_FWD_VectorTraits_h
#include <JavaScriptCore/VectorTraits.h>
#endif
