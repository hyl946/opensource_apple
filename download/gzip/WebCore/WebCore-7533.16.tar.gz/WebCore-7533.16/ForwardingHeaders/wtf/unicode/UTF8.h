#ifndef WebCore_FWD_UTF8_h
#define WebCore_FWD_UTF8_h
#include <JavaScriptCore/UTF8.h>
#endif
