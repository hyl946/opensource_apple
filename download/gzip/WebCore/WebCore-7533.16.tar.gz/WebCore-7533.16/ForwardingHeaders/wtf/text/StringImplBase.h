#ifndef WebCore_FWD_StringImplBase_h
#define WebCore_FWD_StringImplBase_h
#include <JavaScriptCore/StringImplBase.h>
#endif
