#ifndef WebCore_FWD_WTFString_h
#define WebCore_FWD_WTFString_h
#include <JavaScriptCore/WTFString.h>
#endif
