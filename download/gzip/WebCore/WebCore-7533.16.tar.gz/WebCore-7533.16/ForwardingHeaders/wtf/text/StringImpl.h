#ifndef WebCore_FWD_StringImpl_h
#define WebCore_FWD_StringImpl_h
#include <JavaScriptCore/StringImpl.h>
#endif
