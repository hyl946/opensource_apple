#ifndef WebCore_FWD_Lookup_h
#define WebCore_FWD_Lookup_h
#include <JavaScriptCore/Lookup.h>
#endif
