#ifndef WebCore_FWD_WeakGCPtr_h
#define WebCore_FWD_WeakGCPtr_h
#include <JavaScriptCore/WeakGCPtr.h>
#endif
