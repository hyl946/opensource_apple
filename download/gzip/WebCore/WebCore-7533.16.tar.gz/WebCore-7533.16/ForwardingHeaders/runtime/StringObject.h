#ifndef WebCore_FWD_StringObject_h
#define WebCore_FWD_StringObject_h
#include <JavaScriptCore/StringObject.h>
#endif
