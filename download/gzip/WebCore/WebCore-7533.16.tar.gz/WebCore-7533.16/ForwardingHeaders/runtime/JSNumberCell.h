#ifndef WebCore_FWD_JSNumberCell_h
#define WebCore_FWD_JSNumberCell_h
#include <JavaScriptCore/JSNumberCell.h>
#endif
