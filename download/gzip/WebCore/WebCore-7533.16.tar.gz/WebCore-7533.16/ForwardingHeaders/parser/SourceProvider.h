#ifndef WebCore_FWD_SourceProvider_h
#define WebCore_FWD_SourceProvider_h
#include <JavaScriptCore/SourceProvider.h>
#endif
