#include "KWQPaintDevice.h"
