/* Automatically generated from xmlserializer.cpp using ../../../JavaScriptCore/kjs/create_hash_table. DO NOT EDIT ! */

namespace KJS {

const struct HashEntry XMLSerializerProtoTableEntries[] = {
   { "serializeToString", XMLSerializer::SerializeToString, DontDelete|Function, 1, 0 }
};

const struct HashTable XMLSerializerProtoTable = { 2, 1, XMLSerializerProtoTableEntries, 1 };

} // namespace

namespace KJS {

const struct HashEntry XMLSerializerTableEntries[] = {
};

const struct HashTable XMLSerializerTable = { 2, 0, XMLSerializerTableEntries, 0 };

} // namespace
