#include "KWQColor.h"
