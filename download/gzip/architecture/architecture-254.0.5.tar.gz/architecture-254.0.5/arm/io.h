/*
 * Copyright (c) 2000-2007 Apple Computer, Inc. All rights reserved.
 */

typedef unsigned short		io_addr_t;
typedef unsigned short		io_len_t;
