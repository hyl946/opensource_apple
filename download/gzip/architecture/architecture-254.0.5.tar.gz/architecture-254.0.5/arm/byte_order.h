/*
 * Copyright (c) 2007 Apple Computer, Inc. All rights reserved.
 */

#ifndef _ARCH_ARM_BYTE_ORDER_H_
#define _ARCH_ARM_BYTE_ORDER_H_

#include <architecture/byte_order.h>

#endif /* _ARCH_ARM_BYTE_ORDER_H_ */
